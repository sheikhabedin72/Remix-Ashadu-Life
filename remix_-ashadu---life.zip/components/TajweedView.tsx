import React, { useState, useEffect, useRef } from 'react';
import { Mic, MicOff, Sparkles, CheckCircle, AlertCircle, Quote, Trophy } from 'lucide-react';

interface TajweedViewProps {
  onSuccess: (bonusPoints: number) => void;
}

const VERSES = [
  { id: 1, arabic: "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ", transliteration: "Bismillāhir-raḥmānir-raḥīm", keywords: ["بسم", "الله"] },
  { id: 2, arabic: "الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ", transliteration: "Al-ḥamdu lillāhi rabbil-ʿālamīn", keywords: ["الحمد", "لله"] }
];

const TajweedView: React.FC<TajweedViewProps> = ({ onSuccess }) => {
  const [isRecording, setIsRecording] = useState(false);
  const [currentVerse, setCurrentVerse] = useState(VERSES[0]);
  const [volume, setVolume] = useState(0);

  const toggleRecording = () => {
    setIsRecording(!isRecording);
    // Simulate audio polling for visualizer
    if(!isRecording) {
      const interval = setInterval(() => setVolume(Math.random() * 100), 100);
      setTimeout(() => { clearInterval(interval); setVolume(0); setIsRecording(false); onSuccess(10); }, 3000);
    }
  };

  return (
    <div className="flex-1 flex flex-col bg-[#FDFBF7] p-8 animate-in fade-in duration-700 relative overflow-hidden">
      <div className="py-8 text-center">
        <h2 className="text-2xl font-black text-[#0F172A] tracking-tighter uppercase">AI Articulation</h2>
        <p className="text-[10px] text-slate-400 uppercase tracking-[0.4em] mt-2">Refine your Prophetic voice</p>
      </div>

      <div className="flex-1 flex flex-col justify-center items-center">
        <div className="w-full bg-white border-2 border-[#0F172A] p-12 rounded-[3.5rem] shadow-[12px_12px_0px_#0F172A] mb-12 relative overflow-hidden text-center">
            <Quote size={64} className="absolute -top-4 -left-4 text-slate-50" />
            <p className="arabic text-5xl text-[#0F172A] leading-relaxed mb-8">{currentVerse.arabic}</p>
            <p className="text-[#C5A059] text-xs font-black uppercase tracking-widest italic">{currentVerse.transliteration}</p>
        </div>

        <div className="flex justify-center gap-2 h-20 mb-12 items-center">
          {[...Array(15)].map((_, i) => (
            <div key={i} className={`w-1.5 rounded-full transition-all duration-75 ${isRecording ? 'bg-[#C5A059]' : 'bg-[#0F172A]/10'}`}
              style={{ height: isRecording ? `${Math.max(10, volume * (0.5 + (i % 5) * 0.1))}px` : '6px' }}
            />
          ))}
        </div>

        <button 
          onClick={toggleRecording}
          className={`w-32 h-32 rounded-3xl border-4 flex items-center justify-center transition-all duration-500 shadow-2xl active:scale-95
            ${isRecording ? 'bg-red-500 border-[#0F172A] animate-pulse' : 'bg-[#0F172A] border-[#0F172A] shadow-[8px_8px_0px_#C5A059]'}`}
        >
          {isRecording ? <MicOff size={48} className="text-white" /> : <Mic size={48} className="text-[#FDFBF7]" />}
        </button>
      </div>
      
      <div className="mt-8 text-center">
        <p className="text-[9px] text-slate-300 font-black uppercase tracking-[0.5em]">Amanah Guard Encrypted Engine v3.0</p>
      </div>
    </div>
  );
};

export default TajweedView;