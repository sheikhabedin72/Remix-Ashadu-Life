import React, { useEffect, useState, useRef, useCallback } from 'react';
import { UserStats, GroupConfig } from '../types';
import { db } from '../services/databaseService';

interface SyncBridgeProps {
  userId: string;
  groupId: string;
  stats: UserStats;
  groupConfig: GroupConfig;
  onUpdateStats: (s: UserStats) => void;
  onAdminCommand: (command: string, payload?: any) => void;
}

/**
 * ASHADU AMANAH SYNC BRIDGE v3.8
 * Implements the 60-second "The Push" strategy.
 * Handles "is_synced = FALSE" row reconciliation.
 */
const SyncBridge: React.FC<SyncBridgeProps> = ({ 
  userId, 
  groupId, 
  stats, 
  onUpdateStats, 
  onAdminCommand 
}) => {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const lastCloudSyncCount = useRef(stats.totalCount);
  const syncInterval = useRef<number | null>(null);

  /**
   * THE PUSH: Cloud reconciliation for 'is_synced = FALSE'
   */
  const initiateCloudPush = useCallback(async () => {
    if (!navigator.onLine) return;

    try {
      // 1. Identify unsynced rows (Delta Fetch)
      const unsyncedRows = await db.getUnsyncedRows();
      if (unsyncedRows.length === 0 && stats.totalCount === lastCloudSyncCount.current) return;

      console.log(`SYNC_BRIDGE: Pushing ${unsyncedRows.length} unsynced rows to Cloud Ledger...`);

      // 2. Perform Cloud Handshake
      const syncedStats = await db.performSyncHandshake(stats);
      
      // 3. Mark rows as synced in local SQLite buffer
      const unsyncedIds = unsyncedRows.map(r => r.id);
      await db.markRowsAsSynced(unsyncedIds);

      lastCloudSyncCount.current = syncedStats.totalCount;
      onUpdateStats(syncedStats);
      
      console.log("SYNC_BRIDGE: Cloud Push Successful. Ledger is in stone.");
    } catch (e) {
      console.error("SYNC_BRIDGE: Cloud Tier Offline. Delta buffered locally.");
    }
  }, [stats, onUpdateStats]);

  // 1. DYNAMIC NETWORK SURVEILLANCE
  useEffect(() => {
    const handleStatus = () => {
      const currentlyOnline = navigator.onLine;
      setIsOnline(currentlyOnline);
      if (currentlyOnline) {
        initiateCloudPush();
      }
    };
    window.addEventListener('online', handleStatus);
    window.addEventListener('offline', handleStatus);
    return () => {
      window.removeEventListener('online', handleStatus);
      window.removeEventListener('offline', handleStatus);
    };
  }, [initiateCloudPush]);

  // 2. PERIODIC PUSH (60-second strategy)
  useEffect(() => {
    syncInterval.current = window.setInterval(() => {
      initiateCloudPush();
    }, 60000); // 60 Seconds

    return () => {
      if (syncInterval.current) window.clearInterval(syncInterval.current);
    };
  }, [initiateCloudPush]);

  // 3. BROADCAST: Pulse for UI Tickers
  useEffect(() => {
    if (stats.totalCount > lastCloudSyncCount.current) {
      const delta = stats.totalCount - lastCloudSyncCount.current;
      window.dispatchEvent(new CustomEvent('ashadu_stream_pulse', {
        detail: { userId, groupId, delta, timestamp: Date.now() }
      }));
    }
  }, [stats.totalCount, userId, groupId]);

  return null;
};

export default SyncBridge;