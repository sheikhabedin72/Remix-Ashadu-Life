import React, { useState, useEffect } from 'react';
import { 
  BarChart3, Users, ShieldAlert, Save, Search, Activity, 
  ShieldCheck, RefreshCw, Terminal, History, Radio, Lock, Eraser, ShieldX, Zap, Coins
} from 'lucide-react';
import { saveUserData } from '../services/supabaseService';
import { SystemSettings, UserStats, AdminRole, UserProfile, SystemLog, SystemHealth } from '../types';

interface AdminPanelProps {
  settings: SystemSettings;
  onUpdateSettings: (s: SystemSettings) => void;
  stats: UserStats;
  currentRole: AdminRole;
}

const AdminPanel: React.FC<AdminPanelProps> = ({ settings, onUpdateSettings, stats, currentRole }) => {
  const [activeSubView, setActiveSubView] = useState<'dashboard' | 'matrix' | 'amanah' | 'spine' | 'maintenance'>('dashboard');
  const [localSettings, setLocalSettings] = useState<SystemSettings>(settings);
  const [userSearch, setUserSearch] = useState('');
  const [isPurging, setIsPurging] = useState(false);
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [logs, setLogs] = useState<SystemLog[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  
  const health: SystemHealth = {
    dbLatency: '42ms',
    activeGuests: 1204,
    lastPurge: '3h ago',
    apiStatus: 'OPTIMAL'
  };

  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true);
      try {
        const [usersRes, logsRes] = await Promise.all([
          fetch('/api/admin/users').catch(() => ({ ok: false, status: 'Network Error' })),
          fetch('/api/admin/logs').catch(() => ({ ok: false, status: 'Network Error' }))
        ]);
        
        if (!usersRes.ok || !logsRes.ok) {
          console.warn("Admin server not reachable. Using local state.");
          return;
        }

        const usersData = await (usersRes as Response).json();
        const logsData = await (logsRes as Response).json();
        setUsers(usersData);
        setLogs(logsData);
      } catch (error: any) {
        console.error("Failed to fetch admin data:", error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchData();
  }, [activeSubView]);

  const handleToggleFreeze = async (email: string, currentStatus: boolean) => {
    try {
      const res = await fetch(`/api/admin/users/${email}/status`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isFrozen: !currentStatus })
      }).catch(() => ({ ok: false }));
      
      if (res.ok) {
        setUsers(prev => prev.map(u => u.email === email ? { ...u, isFrozen: !currentStatus } : u));
        const logsRes = await fetch('/api/admin/logs').catch(() => null);
        if (logsRes && logsRes.ok) {
          setLogs(await logsRes.json());
        }
      }
    } catch (error) {
      console.error("Failed to update user status:", error);
    }
  };

  const handleChangeRole = async (email: string, newRole: AdminRole) => {
    try {
      const res = await fetch(`/api/admin/users/${email}/role`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ role: newRole })
      }).catch(() => ({ ok: false }));
      
      if (res.ok) {
        setUsers(prev => prev.map(u => u.email === email ? { ...u, role: newRole } : u));
        const logsRes = await fetch('/api/admin/logs').catch(() => null);
        if (logsRes && logsRes.ok) {
          setLogs(await logsRes.json());
        }
      }
    } catch (error) {
      console.error("Failed to update user role:", error);
    }
  };

  const handlePromoteUser = (email: string) => {
    if (currentRole !== 'developer') {
      alert("UNAUTHORIZED: Only Developers can delegate Admin authority.");
      return;
    }
    if (window.confirm(`PROMOTE TO ADMIN: Are you sure you want to grant Admin access to ${email}?`)) {
      handleChangeRole(email, 'admin');
    }
  };

  const handlePurgeGuests = async () => {
    if (!window.confirm("CELESTIAL PURGE: Are you sure you want to remove all guest identities?")) return;
    setIsPurging(true);
    await new Promise(resolve => setTimeout(resolve, 2000));
    setIsPurging(false);
    alert("PURGE COMPLETE.");
  };

  const handleSave = async () => {
    // For admin settings, we might want to save to a different table or a global config
    // But the user asked for 'user_data' table. 
    // If this is an admin saving their own settings:
    const adminEmail = users.find(u => u.role === 'developer' || u.role === 'admin')?.email || 'admin@ashadu.com';
    
    await saveUserData(adminEmail, {
      system_settings: localSettings,
      last_sync: new Date().toISOString()
    });

    onUpdateSettings(localSettings);
    alert("⚡ System Core Synchronized.");
  };

  return (
    <div className={`h-full flex flex-col overflow-hidden animate-in fade-in duration-500 font-inter ${currentRole === 'developer' ? 'bg-[#010e0b]' : 'bg-[#022c22]'}`}>
      <div className="flex h-full">
        <aside className="w-20 lg:w-64 bg-black/40 border-r border-white/5 flex flex-col p-4 lg:p-6">
          <div className="mb-10 text-center">
             <div className="mt-4 px-3 py-1 bg-amber-500/10 border border-amber-500/20 rounded-lg inline-block">
                <span className="text-[7px] font-black uppercase tracking-widest text-amber-500">{currentRole}</span>
             </div>
          </div>
          
          <nav className="flex-1 space-y-3 overflow-y-auto no-scrollbar">
            <AdminNavBtn active={activeSubView === 'dashboard'} onClick={() => setActiveSubView('dashboard')} icon={<BarChart3 size={20} />} label="Foundry Dashboard" />
            <AdminNavBtn active={activeSubView === 'matrix'} onClick={() => setActiveSubView('matrix')} icon={<Users size={20} />} label="The Matrix" />
            {(currentRole === 'admin' || currentRole === 'developer') && (
              <AdminNavBtn active={activeSubView === 'amanah'} onClick={() => setActiveSubView('amanah')} icon={<ShieldCheck size={20} />} label="Amanah Oversight" />
            )}
            {currentRole === 'developer' && (
              <AdminNavBtn active={activeSubView === 'maintenance'} onClick={() => setActiveSubView('maintenance')} icon={<Terminal size={20} />} label="System Pulse" />
            )}
          </nav>

          <button onClick={handleSave} className="mt-auto w-full bg-amber-500 text-emerald-950 p-4 rounded-2xl font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-2 shadow-xl">
            <Save size={16} /> <span className="hidden lg:inline">SYNC CORE</span>
          </button>
        </aside>

        <main className="flex-1 overflow-y-auto p-6 lg:p-12 relative pb-40">
          <div className="absolute inset-0 celestial-grid opacity-5 pointer-events-none" />

          {isLoading ? (
            <div className="flex flex-col items-center justify-center h-full gap-4">
               <RefreshCw size={48} className="text-[#C5A059] animate-spin" />
               <p className="text-[10px] font-black text-[#C5A059] uppercase tracking-[0.4em]">Synchronizing Authority Matrix...</p>
            </div>
          ) : (
            <>
              <header className="flex flex-col lg:flex-row justify-between lg:items-center mb-10 gap-4 relative z-10">
                <div>
                  <h1 className="text-3xl lg:text-4xl font-black tracking-tighter uppercase text-white">
                    {activeSubView === 'matrix' ? 'AUTHORITY MATRIX' : 
                     activeSubView === 'maintenance' ? 'SYSTEM PULSE' : activeSubView.replace('-', ' ').toUpperCase()}
                  </h1>
                  <p className={`text-[10px] uppercase font-black tracking-[0.4em] mt-2 flex items-center gap-2 ${currentRole === 'developer' ? 'text-cyan-400' : 'text-[#C5A059]'}`}>
                    <ShieldAlert size={12} /> CELESTIAL AUTHORITY: {currentRole.toUpperCase()}
                  </p>
                </div>
              </header>

              {activeSubView === 'dashboard' && (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 animate-in slide-in-from-right-4">
                   <AdminStatCard icon={<Zap size={24} />} label="Global Zikr Count" value="12,450,200" delta="RPC: get_global_zikr_stats" color="text-[#C5A059]" />
                   <AdminStatCard icon={<Coins size={24} />} label="Global Amanah" value="£124,502.00" delta="Wealth Purified" color="text-emerald-400" />
                   <AdminStatCard icon={<Users size={24} />} label="Vibrating Souls" value="1,420" delta="Live Connections" color="text-cyan-400" />
                </div>
              )}

              {activeSubView === 'matrix' && (
                <div className="space-y-8 animate-in fade-in duration-700">
                   <div className="relative group max-w-xl">
                     <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-stone-500 group-focus-within:text-amber-500 transition-colors" size={20} />
                     <input 
                       type="text" 
                       placeholder="Search Profiles by Email..." 
                       value={userSearch}
                       onChange={e => setUserSearch(e.target.value)}
                       className="w-full bg-black/40 border border-white/5 rounded-3xl py-6 pr-8 pl-16 text-sm font-bold text-white outline-none focus:ring-4 focus:ring-amber-500/10 transition-all placeholder:text-stone-700 shadow-inner"
                     />
                   </div>

                   <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                     {users.filter(u => u.email.toLowerCase().includes(userSearch.toLowerCase())).map(u => (
                       <div key={u.email} className={`bg-black/30 border p-6 rounded-[2.5rem] flex items-center justify-between group transition-all ${u.isFrozen ? 'border-red-500/40 bg-red-500/5' : 'border-white/5 hover:border-white/10'}`}>
                          <div className="flex items-center gap-4">
                             <div className={`w-14 h-14 rounded-2xl ${u.avatarColor || 'bg-emerald-600'} flex items-center justify-center text-white font-black text-xl shadow-lg relative`}>
                                {u.firstName[0]}
                                {u.role === 'developer' && <div className="absolute -top-1 -right-1 bg-cyan-500 p-0.5 rounded border border-black"><Terminal size={8} /></div>}
                                {u.isFrozen && <div className="absolute -bottom-1 -right-1 bg-red-600 p-0.5 rounded border border-black"><Lock size={8} /></div>}
                             </div>
                             <div>
                                <h4 className="text-white font-black text-sm flex items-center gap-2">
                                  {u.firstName} {u.lastName}
                                  {u.isFrozen && <span className="text-[7px] bg-red-600 text-white px-1.5 py-0.5 rounded font-black uppercase tracking-widest">FROZEN</span>}
                                </h4>
                                <p className="text-[10px] text-stone-500 font-bold mt-0.5 uppercase tracking-widest">{u.email}</p>
                                <div className="flex gap-2 mt-2">
                                   <span className={`text-[7px] font-black uppercase px-2 py-0.5 rounded border ${u.role === 'developer' ? 'bg-cyan-500/10 text-cyan-400 border-cyan-500/20' : u.role === 'admin' ? 'bg-amber-500/10 text-amber-500 border-amber-500/20' : 'bg-emerald-950 text-emerald-500 border-emerald-900'}`}>
                                     {u.role}
                                   </span>
                                </div>
                             </div>
                          </div>
                          <div className="flex items-center gap-2">
                            {currentRole === 'developer' && (
                              <>
                                <button 
                                  onClick={() => handleToggleFreeze(u.email, !!u.isFrozen)}
                                  className={`px-4 py-2 rounded-xl text-[8px] font-black uppercase tracking-widest transition-all active:scale-90 shadow-xl ${u.isFrozen ? 'bg-emerald-500 text-emerald-950 hover:bg-emerald-400' : 'bg-red-600 text-white hover:bg-red-500'}`}
                                >
                                  {u.isFrozen ? 'UNFREEZE' : 'FREEZE'}
                                </button>
                                {u.role === 'servant' && (
                                  <button 
                                    onClick={() => handlePromoteUser(u.email)}
                                    className="bg-[#C5A059] text-emerald-950 px-4 py-2 rounded-xl text-[8px] font-black uppercase tracking-widest hover:bg-amber-400 transition-all active:scale-90 shadow-xl"
                                  >
                                    PROMOTE
                                  </button>
                                )}
                              </>
                            )}
                          </div>
                       </div>
                     ))}
                   </div>
                </div>
              )}

              {activeSubView === 'amanah' && (
                <div className="space-y-8 animate-in fade-in duration-700">
                   <div className="bg-emerald-950/40 border border-[#C5A059]/20 p-8 rounded-[3rem] backdrop-blur-md">
                      <h3 className="text-white font-black text-sm uppercase tracking-widest mb-6 flex items-center gap-2">
                        <ShieldCheck size={20} className="text-[#C5A059]" /> Pending Amanah Verifications
                      </h3>
                      <div className="space-y-4">
                         <p className="text-stone-500 text-[10px] uppercase tracking-widest text-center py-10">No pending verifications in the current cycle.</p>
                      </div>
                   </div>
                </div>
              )}

              {activeSubView === 'maintenance' && (
                <div className="max-w-4xl mx-auto space-y-10 animate-in slide-in-from-bottom-6">
                   <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      <HealthCard label="DB Latency" value={health.dbLatency} icon={<History size={16}/>} color="text-amber-500" />
                      <HealthCard label="Active Guests" value={health.activeGuests} icon={<Users size={16}/>} color="text-cyan-400" />
                      <HealthCard label="System Status" value={health.apiStatus} icon={<Radio size={16}/>} color="text-emerald-400" pulse />
                   </div>

                   <div className="bg-[#0c1a1a] border border-white/5 rounded-[3rem] overflow-hidden flex flex-col h-[400px] shadow-2xl">
                      <header className="p-6 bg-black/40 border-b border-white/5 flex justify-between items-center">
                         <div className="flex items-center gap-3">
                            <Terminal size={18} className="text-cyan-500" />
                            <h3 className="text-[10px] font-black text-white uppercase tracking-widest">Real-time System Logs</h3>
                         </div>
                      </header>
                      <div className="flex-1 overflow-y-auto p-6 font-mono text-[11px] space-y-3 custom-scrollbar">
                         {logs.map(log => (
                           <div key={log.id} className="flex gap-4 group">
                              <span className="text-stone-700 shrink-0">[{log.timestamp}]</span>
                              <span className={`shrink-0 font-black px-1.5 py-0.5 rounded text-[8px] ${
                                 log.type === 'SUCCESS' ? 'text-emerald-500 bg-emerald-500/10' :
                                 log.type === 'WARNING' ? 'text-amber-500 bg-amber-500/10' :
                                 log.type === 'CRITICAL' ? 'text-red-500 bg-red-500/10' : 'text-stone-500 bg-stone-500/10'
                              }`}>
                                {log.type}
                              </span>
                              <span className="text-stone-300 leading-relaxed">{log.message}</span>
                           </div>
                         ))}
                      </div>
                   </div>

                   <div className="bg-red-500/5 border border-red-500/20 p-8 rounded-[3rem] flex flex-col lg:flex-row items-center justify-between gap-6">
                      <div className="flex items-center gap-4 text-center lg:text-left">
                         <div className="w-14 h-14 bg-red-500/10 rounded-2xl flex items-center justify-center text-red-500 shadow-lg border border-red-500/20">
                            <Eraser size={28} />
                         </div>
                         <div>
                            <h4 className="text-lg font-black text-red-500 uppercase tracking-tight">The Celestial Purge</h4>
                            <p className="text-xs text-red-400/60 leading-relaxed max-w-sm">Wipes all guest identities older than 3 days.</p>
                         </div>
                      </div>
                      <button 
                        onClick={handlePurgeGuests}
                        disabled={isPurging}
                        className={`px-10 py-5 rounded-2xl font-black uppercase tracking-[0.3em] text-[10px] shadow-2xl transition-all active:scale-95 flex items-center justify-center gap-3
                          ${isPurging ? 'bg-red-500/20 text-red-500 border border-red-500/30' : 'bg-red-600 hover:bg-red-500 text-white'}`}
                      >
                        {isPurging ? <RefreshCw className="animate-spin" /> : <ShieldX size={18} />}
                        {isPurging ? 'PURGING...' : 'FORCE GUEST CLEANUP'}
                      </button>
                   </div>
                </div>
              )}
            </>
          )}
        </main>
      </div>
    </div>
  );
};

const AdminNavBtn = ({ active, onClick, icon, label }: any) => (
  <button onClick={onClick} className={`w-full flex items-center gap-4 p-4 rounded-2xl transition-all group ${active ? 'bg-amber-500 text-emerald-950 font-black shadow-xl' : 'text-emerald-500 hover:bg-emerald-900/40'}`}>
    <div className={`transition-transform group-hover:scale-110 ${active ? 'text-emerald-950' : 'text-emerald-400'}`}>{icon}</div>
    <span className="hidden lg:inline text-[9px] uppercase tracking-widest text-left">{label}</span>
  </button>
);

const AdminStatCard = ({ icon, label, value, delta, color = "text-amber-500" }: any) => (
  <div className="bg-black/20 border border-white/5 p-8 rounded-[2.5rem] relative overflow-hidden group hover:border-white/10 transition-all">
    <div className="flex justify-between items-start mb-6 relative z-10">
       <div className={`p-4 bg-emerald-950 rounded-2xl ${color} border border-white/5 transition-transform group-hover:rotate-6`}>{icon}</div>
    </div>
    <div className="relative z-10">
      <p className="text-[10px] font-black text-emerald-700 uppercase tracking-widest mb-1">{label}</p>
      <h4 className="text-3xl font-black text-white font-mono tracking-tighter">{value}</h4>
      <p className="text-[7px] text-emerald-900 font-black uppercase mt-3 tracking-widest">{delta}</p>
    </div>
  </div>
);

const HealthCard = ({ label, value, icon, color, pulse }: any) => (
   <div className="bg-black/40 border border-white/5 p-6 rounded-3xl flex items-center justify-between group hover:border-white/10 transition-all">
      <div className="flex items-center gap-4">
         <div className={`p-3 rounded-xl bg-black/40 ${color} border border-white/5`}>{icon}</div>
         <div>
            <p className="text-[8px] font-black text-stone-500 uppercase tracking-widest mb-0.5">{label}</p>
            <p className={`text-sm font-black uppercase ${pulse ? 'animate-pulse' : ''}`}>{value}</p>
         </div>
      </div>
      {pulse && <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 shadow-[0_0_8px_#10b981]" />}
   </div>
);

const AmanahVerificationRow = ({ name, amount, date, type }: any) => (
  <div className="bg-black/40 border border-white/5 p-5 rounded-2xl flex items-center justify-between group hover:border-amber-500/20 transition-all">
    <div className="flex items-center gap-4">
      <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-500 flex items-center justify-center">
        <Activity size={18} />
      </div>
      <div>
        <p className="text-sm font-black text-white leading-none">{name}</p>
        <p className="text-[8px] text-emerald-700 font-black uppercase mt-1.5">{type} • {date}</p>
      </div>
    </div>
    <div className="flex items-center gap-6">
      <p className="text-sm font-black text-amber-500 font-mono">£{amount.toFixed(2)}</p>
      <button className="bg-emerald-500 text-emerald-950 px-4 py-2 rounded-xl text-[8px] font-black uppercase tracking-widest hover:bg-emerald-400 transition-all active:scale-90">
        VERIFY
      </button>
    </div>
  </div>
);

export default AdminPanel;
