
import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  MapPin, User, Mail, Send, Loader2, Search, Users, Heart, Crown, Sparkles, Filter, X, Check, Info, Coins, Shield, ShieldCheck, ShieldOff, Eye, EyeOff, Sprout, Trees as TreeIcon, Flower2, Landmark, Zap, ChevronRight, BadgeCheck, LineChart, Palette, AlertCircle, Bell, FileText, Lock, BellOff, Camera, Image, Settings, Pencil, Save, Eye as ViewIcon, ExternalLink, History, Trophy, Scale
} from 'lucide-react';
import { fetchCurrentLocation, reverseGeocode } from '../services/locationService';
import { saveUserData, insertUserData, fetchLatestUserData, supabase } from '../services/supabaseService';
import { UserProfile, CommunityUser, Sponsorship, GardenPlant, SubscriptionTier, SystemSettings, UserStats } from '../types';

const MOCK_COMMUNITY: CommunityUser[] = [
  { id: '1', firstName: 'Jamal', lastName: 'Doe', city: 'London', zipcode: 'E1', distance: '2 miles', isLive: true, avatarColor: 'bg-blue-500', isRegistered: true, email: '', phone: '', milestoneReached: true, isAnonymous: false, role: 'servant' },
  { id: '2', firstName: 'Sara', lastName: 'Ahmed', city: 'London', zipcode: 'W1', distance: '5 miles', isLive: true, avatarColor: 'bg-amber-500', isRegistered: true, email: '', phone: '', milestoneReached: false, isAnonymous: false, role: 'servant' },
  { id: '3', firstName: 'Omar', lastName: 'Farooq', city: 'Birmingham', zipcode: 'B1', distance: '120 miles', isLive: false, avatarColor: 'bg-emerald-500', isRegistered: true, email: '', phone: '', milestoneReached: true, isAnonymous: false, role: 'servant' },
];

interface ProfileViewProps {
  gardenPlants: GardenPlant[];
  userProfile: UserProfile | null;
  onUpdateProfile: (p: UserProfile) => void;
  settings: SystemSettings;
  stats: UserStats;
  onUpdateStats: (s: UserStats) => void;
}

const ProfileView: React.FC<ProfileViewProps> = ({ gardenPlants, userProfile, onUpdateProfile, settings, stats, onUpdateStats }) => {
  const [activeTab, setActiveTab] = useState<'profile' | 'discovery' | 'circle' | 'garden' | 'settings'>('profile');
  const [isEditing, setIsEditing] = useState(false);
  const [isFetching, setIsFetching] = useState(false);
  const [viewAsPublic, setViewAsPublic] = useState(false);
  const [showImagePicker, setShowImagePicker] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [formData, setFormData] = useState({ 
    firstName: userProfile?.firstName || '', 
    lastName: userProfile?.lastName || '', 
    full_name: userProfile?.full_name || '',
    bio: userProfile?.bio || '',
    website_url: userProfile?.website_url || '',
    username: userProfile?.username || '',
    age: userProfile?.age || 25,
    aboutMe: userProfile?.aboutMe || 'Peace be upon you. I am on a spiritual journey of consistency.',
    email: userProfile?.email || '', 
    phone: userProfile?.phone || '', 
    city: userProfile?.city || '', 
    zipcode: userProfile?.zipcode || '', 
    isAnonymous: userProfile?.isAnonymous || false,
    profilePicture: userProfile?.profilePicture || ''
  });

  const [submitted, setSubmitted] = useState(false);
  const [notification, setNotification] = useState<{ type: 'success' | 'error', message: string } | null>(null);
  const [confirmingSponsor, setConfirmingSponsor] = useState<CommunityUser | null>(null);
  const [spendCap, setSpendCap] = useState(50);
  const [activeSponsorships, setActiveSponsorships] = useState<Sponsorship[]>(() => {
    const saved = localStorage.getItem('ashadu_active_sponsorships');
    return saved ? JSON.parse(saved) : [];
  });

  const lastSyncedProfile = useRef<UserProfile | null>(userProfile);

  useEffect(() => {
    const autoFillData = async () => {
      try {
        setIsFetching(true);
        // fetchLatestUserData now uses auth.uid() internally
        const latestData = await fetchLatestUserData();
        
        if (latestData) {
          setFormData(prev => ({
            ...prev,
            full_name: latestData.full_name || prev.full_name,
            bio: latestData.bio || prev.bio,
            website_url: latestData.website_url || prev.website_url,
            firstName: latestData.firstName || prev.firstName,
            lastName: latestData.lastName || prev.lastName,
            username: latestData.username || prev.username,
            aboutMe: latestData.aboutMe || prev.aboutMe,
            city: latestData.city || prev.city,
            zipcode: latestData.zipcode || prev.zipcode,
          }));
          
          // Sync with global state if needed
          const updated: UserProfile = { ...userProfile, ...latestData };
          onUpdateProfile(updated);
        }
      } catch (error) {
        console.error("Auto-fill failed:", error);
      } finally {
        setIsFetching(false);
      }
    };

    autoFillData();
  }, [userProfile, onUpdateProfile]); // Run when userProfile or update function changes

  useEffect(() => {
    if (userProfile && userProfile !== lastSyncedProfile.current) {
        lastSyncedProfile.current = userProfile;
        setFormData(prev => ({
            ...prev,
            firstName: userProfile.firstName,
            lastName: userProfile.lastName,
            username: userProfile.username || prev.username,
            age: userProfile.age || prev.age,
            aboutMe: userProfile.aboutMe || prev.aboutMe,
            email: userProfile.email,
            phone: userProfile.phone || prev.phone,
            city: userProfile.city,
            zipcode: userProfile.zipcode,
            isAnonymous: userProfile.isAnonymous,
            profilePicture: userProfile.profilePicture || prev.profilePicture
        }));
    }
  }, [userProfile]);

  const handleSave = async () => {
    try {
      setSubmitted(true);
      setNotification(null);
      const { full_name, email, bio, website_url } = formData;
      
      // Using .insert() as requested by the user
      // Note: insertUserData now handles user_id internally
      await insertUserData({ full_name, email, bio, website_url });
      
      setNotification({ type: 'success', message: 'Success! Celestial Identity Synchronized.' });
      
      // Also update local state
      const updated: UserProfile = { ...userProfile!, ...formData };
      onUpdateProfile(updated);
      localStorage.setItem('ashadu_user_profile', JSON.stringify(updated));
      
      setTimeout(() => {
        setIsEditing(false);
        setNotification(null);
      }, 3000);
    } catch (error: any) {
      // Handle errors like duplicate email
      setNotification({ type: 'error', message: `Error: ${error.message || "Please try again"}` });
      setTimeout(() => setNotification(null), 5000);
    } finally {
      setSubmitted(false);
    }
  };

  const saveProfile = async () => {
    if (!userProfile) return;
    const updated: UserProfile = { 
      ...userProfile, 
      ...formData, 
      isRegistered: true,
      role: userProfile.role || 'servant'
    };
    
    try {
      setSubmitted(true);
      setNotification(null);

      // Save to Supabase
      // Note: saveUserData now handles user_id and email internally
      await saveUserData({
        firstName: updated.firstName,
        lastName: updated.lastName,
        username: updated.username,
        age: updated.age,
        aboutMe: updated.aboutMe,
        phone: updated.phone,
        city: updated.city,
        zipcode: updated.zipcode,
        isAnonymous: updated.isAnonymous,
        profilePicture: updated.profilePicture
      });

      setNotification({ type: 'success', message: 'Success! Identity Anchored.' });
      onUpdateProfile(updated);
      localStorage.setItem('ashadu_user_profile', JSON.stringify(updated));
      
      setTimeout(() => { 
        setIsEditing(false);
        setNotification(null);
      }, 3000);
    } catch (error: any) {
      setNotification({ type: 'error', message: 'Error: Please try again' });
      setTimeout(() => setNotification(null), 5000);
    } finally {
      setSubmitted(false);
    }
  };

  const handleImageCapture = async (source: 'camera' | 'gallery') => {
    if (source === 'gallery') {
      fileInputRef.current?.click();
    } else {
      // Simulate camera intent/permissions
      alert("Activating Prophetic Lens (Camera)... [SIMULATED]");
      // For a real app, you'd use navigator.mediaDevices.getUserMedia
      const mockImg = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=1287&auto=format&fit=crop";
      setFormData({...formData, profilePicture: mockImg});
      setShowImagePicker(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData({...formData, profilePicture: reader.result as string});
        setShowImagePicker(false);
      };
      reader.readAsDataURL(file);
    }
  };

  // Gems Calculation: Visits + (Likes * 5)
  const gemsCount = (userProfile?.visits || 142) + ((userProfile?.likes || 24) * 5);

  if (!userProfile) {
    return (
      <div className="h-full flex flex-col items-center justify-center bg-emerald-950 p-8 text-center font-inter">
        <div className="w-32 h-32 bg-emerald-900 rounded-[3rem] border-4 border-[#C5A059]/20 flex items-center justify-center mb-8 shadow-2xl">
          {/* User icon removed */}
        </div>
        <h2 className="text-3xl font-black text-white uppercase tracking-tighter mb-4">Spirit Identity Required</h2>
        <p className="text-emerald-500 text-xs font-bold uppercase tracking-widest leading-relaxed mb-12 max-w-xs">
          To sponsor souls and access the collective missions, you must first establish your spirit identity.
        </p>
        <button 
          onClick={() => window.dispatchEvent(new CustomEvent('openIdentityPortal'))}
          className="w-full max-w-xs py-6 btn-gold rounded-[2rem] font-black uppercase tracking-widest text-[11px] shadow-2xl active:scale-95 transition-all"
        >
          Create Identity
        </button>
        <div className="absolute inset-0 celestial-grid opacity-10 pointer-events-none" />
      </div>
    );
  }

  const isPublicViewMode = viewAsPublic && !isEditing;

  return (
    <div className="h-full flex flex-col bg-emerald-950 animate-in fade-in duration-500 font-inter">
      
      {/* Notification Overlay */}
      <AnimatePresence>
        {notification && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed top-24 left-1/2 -translate-x-1/2 z-[1000] w-full max-w-xs px-4"
          >
            <div className={`flex items-center gap-3 p-4 rounded-2xl shadow-2xl border ${
              notification.type === 'success' 
                ? 'bg-emerald-500 border-emerald-400 text-white' 
                : 'bg-red-500 border-red-400 text-white'
            }`}>
              {notification.type === 'success' ? <Check size={20} /> : <AlertCircle size={20} />}
              <span className="text-[10px] font-black uppercase tracking-widest">{notification.message}</span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* 1. IMAGE PICKER MODAL */}
      {showImagePicker && (
        <div className="fixed inset-0 z-[600] flex items-center justify-center p-6 bg-black/90 backdrop-blur-2xl animate-in zoom-in-95 duration-300">
           <div className="bg-emerald-900 w-full max-w-sm rounded-[3.5rem] border border-amber-500/30 p-8 shadow-2xl">
              <h3 className="text-xl font-black text-white text-center mb-8 uppercase tracking-widest">Update Spirit Lens</h3>
              <div className="grid grid-cols-1 gap-4">
                 <button onClick={() => handleImageCapture('camera')} className="w-full py-6 bg-emerald-800 rounded-3xl flex items-center justify-center gap-4 text-white font-black uppercase text-[10px] tracking-widest active:scale-95 transition-all">
                    Camera
                 </button>
                 <button onClick={() => handleImageCapture('gallery')} className="w-full py-6 bg-emerald-800 rounded-3xl flex items-center justify-center gap-4 text-white font-black uppercase text-[10px] tracking-widest active:scale-95 transition-all">
                    Gallery
                 </button>
                 <button onClick={() => setShowImagePicker(false)} className="w-full py-4 text-emerald-500 font-black uppercase text-[9px] tracking-widest hover:text-white transition-colors">Cancel</button>
              </div>
              <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleFileChange} />
           </div>
        </div>
      )}

      {/* 2. PROFILE HEADER: NOOR CENTERED */}
      <div className="relative pt-12 pb-8 px-8 flex flex-col items-center">
         <div className="absolute top-0 right-0 p-8 opacity-[0.03] pointer-events-none">
            {/* Sparkles removed */}
         </div>

         {/* Profile Media Core */}
         <div className="relative group mb-6">
            <div className={`w-36 h-36 rounded-[3rem] bg-emerald-900 border-4 border-[#C5A059]/40 shadow-2xl flex items-center justify-center overflow-hidden transition-all duration-700 ${isEditing ? 'scale-105' : ''}`}>
               {formData.profilePicture ? (
                 <img src={formData.profilePicture} alt="Profile" className="w-full h-full object-cover" />
               ) : (
                 <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-emerald-800 to-emerald-950">
                   <span className="text-6xl font-black text-[#C5A059] uppercase">{formData.firstName[0]}</span>
                 </div>
               )}
            </div>
            
            {isEditing && (
              <button 
                onClick={() => setShowImagePicker(true)}
                className="absolute -bottom-2 -right-2 w-12 h-12 bg-amber-500 rounded-2xl flex items-center justify-center text-emerald-950 shadow-xl border-4 border-emerald-950 animate-in zoom-in-95 font-black"
              >
                +
              </button>
            )}

            {!isEditing && userProfile.isPremium && (
               <div className="absolute -top-3 -right-3 bg-amber-500 p-2 rounded-2xl border-4 border-emerald-950 shadow-lg">
                  <span className="text-emerald-950 font-black text-[8px]">PREMIUM</span>
               </div>
            )}
         </div>

         <div className="text-center">
            <h3 className="text-3xl font-black text-white tracking-tighter uppercase leading-none mb-2">
              {formData.firstName} {formData.lastName}, <span className="text-[#C5A059]">{formData.age}</span>
            </h3>
            <p className="text-emerald-500 text-[10px] font-black uppercase tracking-[0.3em]">@{formData.username}</p>
         </div>

         {/* Gems & Stats Bar */}
         <div className="flex gap-4 mt-8 w-full max-w-sm">
            <StatPill label="GEMS" value={gemsCount} icon={null} />
            <StatPill label="VISITS" value={userProfile.visits || 142} icon={null} />
            <StatPill label="LIKES" value={userProfile.likes || 24} icon={null} />
         </div>
      </div>

      {/* 3. NAVIGATION TABS */}
      <div className="flex-1 bg-stone-50 rounded-t-[3.5rem] p-6 pb-40 shadow-[0_-20px_50px_rgba(0,0,0,0.3)] overflow-y-auto no-scrollbar">
        <div className="flex gap-2 p-1.5 bg-stone-100 rounded-[2rem] mb-10 overflow-x-auto no-scrollbar">
          <NavBtn active={activeTab === 'profile'} onClick={() => setActiveTab('profile')} label="Profile Hub" />
          <NavBtn active={activeTab === 'discovery'} onClick={() => setActiveTab('discovery')} label="Souls" />
          <NavBtn active={activeTab === 'settings'} onClick={() => setActiveTab('settings')} label="Settings" />
        </div>

        {/* 4. TAB CONTENT */}
        <div className="max-w-md mx-auto space-y-8 pb-10">
          
          {isFetching ? (
            <div className="space-y-6 animate-pulse">
              <div className="h-32 bg-stone-200 rounded-[3rem]" />
              <div className="grid grid-cols-2 gap-4">
                <div className="h-24 bg-stone-100 rounded-[2.5rem]" />
                <div className="h-24 bg-stone-100 rounded-[2.5rem]" />
              </div>
              <div className="space-y-3">
                {[1, 2, 3, 4].map(i => (
                  <div key={i} className="h-20 bg-stone-100 rounded-[2rem]" />
                ))}
              </div>
            </div>
          ) : activeTab === 'profile' && (
            <div className="animate-in slide-in-from-bottom-4 duration-500 space-y-8">
               
               {/* Mode Switcher */}
               <div className="flex justify-between items-center px-2">
                  <div className="flex gap-3">
                     <button 
                        onClick={() => { setIsEditing(!isEditing); if(!isEditing) setViewAsPublic(false); }} 
                        className={`flex items-center gap-2 px-5 py-3 rounded-2xl font-black text-[10px] uppercase tracking-widest transition-all ${isEditing ? 'bg-amber-500 text-white shadow-lg' : 'bg-stone-200 text-stone-600 hover:bg-stone-300'}`}
                     >
                        {isEditing ? 'Anchor Identity' : 'Edit Profile'}
                     </button>
                     <button 
                        onClick={() => { setViewAsPublic(!viewAsPublic); if(!viewAsPublic) setIsEditing(false); }}
                        className={`p-3 rounded-2xl border transition-all ${viewAsPublic ? 'bg-emerald-100 border-emerald-200 text-emerald-700' : 'bg-white border-stone-200 text-stone-400 hover:bg-stone-50'}`}
                        title="Preview Public Profile"
                     >
                        VIEW
                     </button>
                  </div>
                  <button onClick={() => setActiveTab('settings')} className="p-3 bg-stone-100 rounded-2xl text-stone-400 hover:text-emerald-700 transition-colors font-black text-[10px]">SETTINGS</button>
               </div>

                {/* Spiritual Portfolio */}
                {!isEditing && (
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-white p-6 rounded-[2.5rem] border border-stone-100 shadow-sm flex flex-col items-center text-center group hover:border-emerald-200 transition-all">
                      <p className="text-2xl font-black text-emerald-950 font-mono tracking-tighter">{stats.totalCount.toLocaleString()}</p>
                      <p className="text-[8px] font-black text-stone-400 uppercase tracking-widest mt-1">Total Zikr</p>
                    </div>
                    <div className="bg-white p-6 rounded-[2.5rem] border border-stone-100 shadow-sm flex flex-col items-center text-center group hover:border-emerald-200 transition-all">
                      <p className="text-2xl font-black text-emerald-950 font-mono tracking-tighter">{stats.streak}</p>
                      <p className="text-[8px] font-black text-stone-400 uppercase tracking-widest mt-1">Day Streak</p>
                    </div>
                    <div className="bg-white p-6 rounded-[2.5rem] border border-stone-100 shadow-sm flex flex-col items-center text-center group hover:border-emerald-200 transition-all">
                      <p className="text-2xl font-black text-emerald-950 font-mono tracking-tighter">{stats.impactPoints || 0}</p>
                      <p className="text-[8px] font-black text-stone-400 uppercase tracking-widest mt-1">Impact Points</p>
                    </div>
                    <div className="bg-white p-6 rounded-[2.5rem] border border-stone-100 shadow-sm flex flex-col items-center text-center group hover:border-emerald-200 transition-all">
                      <p className="text-2xl font-black text-emerald-950 font-mono tracking-tighter">£{stats.totalProjectDonations.toLocaleString()}</p>
                      <p className="text-[8px] font-black text-stone-400 uppercase tracking-widest mt-1">Legacy Gifted</p>
                    </div>
                  </div>
                )}

               {/* Bio Section */}
               <div className="bg-white p-8 rounded-[3rem] border border-stone-100 shadow-sm relative group overflow-hidden">
                  <h4 className="text-[10px] font-black text-emerald-800 uppercase tracking-[0.3em] mb-4 flex items-center gap-2">
                     Spiritual Bio
                  </h4>
                  {isEditing ? (
                    <textarea 
                      value={formData.aboutMe} 
                      onChange={e => setFormData({...formData, aboutMe: e.target.value})}
                      className="w-full bg-stone-50 border border-stone-100 rounded-2xl p-5 text-sm text-stone-700 focus:border-[#C5A059] outline-none transition-all h-32 resize-none"
                      placeholder="Share your spiritual journey..."
                    />
                  ) : (
                    <p className="text-stone-600 text-sm leading-relaxed font-medium italic">"{formData.aboutMe}"</p>
                  )}
                  <Sparkles size={80} className="absolute -bottom-6 -right-6 text-emerald-500 opacity-[0.03] group-hover:scale-125 transition-transform" />
               </div>

               {/* Profile Info Fields */}
               <div className="space-y-3">
                  <InfoRow label="FULL NAME" value={formData.full_name} icon={null} editable={isEditing} onChange={(v: string) => setFormData({...formData, full_name: v})} />
                  <InfoRow label="WEBSITE" value={formData.website_url} icon={null} editable={isEditing} onChange={(v: string) => setFormData({...formData, website_url: v})} />
                  <InfoRow label="USERNAME" value={`@${formData.username}`} icon={null} editable={isEditing} onChange={(v: string) => setFormData({...formData, username: v.replace('@', '')})} />
                  <InfoRow label="AGE" value={`${formData.age} Years`} icon={null} editable={isEditing} type="number" onChange={(v: string) => setFormData({...formData, age: parseInt(v) || 0})} />
                  <InfoRow label="ESTABLISHMENT" value={formData.city} icon={null} editable={isEditing} onChange={(v: string) => setFormData({...formData, city: v})} />
                  <InfoRow label="CONTACT" value={formData.email} icon={null} editable={isEditing} onChange={(v: string) => setFormData({...formData, email: v})} />
               </div>

               {/* Status Shield */}
               {!isEditing && (
                 <div className="bg-emerald-950 p-8 rounded-[3rem] text-white relative overflow-hidden shadow-xl group">
                    <div className="flex items-center gap-4 relative z-10">
                       <div className="p-4 bg-emerald-900 rounded-2xl border border-[#C5A059]/20 shadow-inner group-hover:rotate-6 transition-transform">
                          {/* ShieldCheck removed */}
                       </div>
                       <div>
                          <h4 className="font-black text-lg uppercase tracking-tight">Ummah Verified</h4>
                          <p className="text-emerald-400 text-[10px] font-black uppercase tracking-widest">Amanah Guard Active</p>
                       </div>
                    </div>
                    <Sparkles size={140} className="absolute -bottom-10 -right-10 opacity-10" />
                 </div>
               )}

               {isEditing && (
                 <div className="space-y-4">
                   <button 
                     onClick={handleSave}
                     disabled={submitted || userProfile?.isGuest}
                     className="w-full bg-amber-500 hover:bg-amber-400 text-emerald-950 font-black py-6 rounded-[2rem] shadow-2xl transition-all active:scale-95 flex items-center justify-center gap-3 uppercase tracking-widest text-[11px] border-b-8 border-amber-700 disabled:opacity-50 disabled:cursor-not-allowed"
                   >
                     {submitted ? 'SAVING...' : 'Legacy Sync (Insert)'}
                   </button>
                   <button 
                     onClick={saveProfile}
                     disabled={submitted || userProfile?.isGuest}
                     className="w-full bg-emerald-800 hover:bg-emerald-700 text-white font-black py-6 rounded-[2rem] shadow-2xl transition-all active:scale-95 flex items-center justify-center gap-3 uppercase tracking-widest text-[11px] border-b-8 border-emerald-950 disabled:opacity-50 disabled:cursor-not-allowed"
                   >
                     {submitted ? 'SAVING...' : 'Anchoring Identity (Upsert)'}
                   </button>
                 </div>
               )}
            </div>
          )}

          {activeTab === 'discovery' && (
            <div className="space-y-4 animate-in slide-in-from-right-4 duration-500">
              <div className="relative group mb-6">
                <input type="text" placeholder="Search the Ummah..." className="w-full px-8 py-4 bg-stone-100 border border-stone-200 rounded-[2rem] outline-none text-sm font-bold text-stone-700 shadow-inner" />
              </div>
              {MOCK_COMMUNITY.map(u => (
                <div key={u.id} className="bg-white p-6 rounded-[2.5rem] border border-stone-100 shadow-sm flex items-center justify-between hover:border-emerald-200 transition-all group">
                  <div className="flex items-center gap-5">
                    <div className={`w-14 h-14 rounded-2xl ${u.avatarColor} flex items-center justify-center text-white font-black text-xl shadow-md group-hover:scale-105 transition-transform`}>{u.firstName[0]}</div>
                    <div>
                      <h4 className="font-black text-stone-800 text-sm tracking-tight">{u.firstName} {u.lastName}</h4>
                      <p className="text-[10px] text-stone-400 font-bold uppercase tracking-widest mt-1 flex items-center gap-1">{u.distance}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <button 
                      onClick={(e) => { e.stopPropagation(); alert(`Sponsoring ${u.firstName}'s spiritual journey...`); }}
                      className="px-4 py-2 bg-emerald-50 text-emerald-700 rounded-xl text-[8px] font-black uppercase tracking-widest border border-emerald-100 hover:bg-emerald-100 transition-all active:scale-95"
                    >
                      Sponsor
                    </button>
                    <span className="text-stone-300 group-hover:text-emerald-500 transition-colors font-black">GO</span>
                  </div>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'settings' && (
            <div className="animate-in slide-in-from-left-4 duration-500 space-y-6">
               <h3 className="text-xl font-black text-emerald-950 uppercase tracking-tighter px-2">App Config</h3>
               
               <div className="bg-white rounded-[2.5rem] border border-stone-100 overflow-hidden shadow-sm">
                  <div className="p-6 border-b border-stone-50 bg-stone-50/50">
                     <h4 className="text-[10px] font-black text-emerald-800 uppercase tracking-widest flex items-center gap-2">
                        Notification Protocols
                     </h4>
                  </div>
                  <SettingRow icon={null} label="Prayer Time Alerts" active />
                  <SettingRow icon={null} label="Zikr Reminders" active />
                  <SettingRow icon={null} label="Community Invites" active />
                  <SettingRow icon={null} label="Amanah Security Alerts" active />
                  <SettingRow icon={null} label="Proximity Alerts" last />
               </div>

               <div className="bg-white rounded-[2.5rem] border border-stone-100 overflow-hidden shadow-sm">
                  <div className="p-6 border-b border-stone-50 bg-stone-50/50">
                     <h4 className="text-[10px] font-black text-emerald-800 uppercase tracking-widest flex items-center gap-2">
                        Security & Privacy
                     </h4>
                  </div>
                  <SettingRow icon={null} label="Two-Factor Authentication" />
                  <SettingRow icon={null} label="Celestial Themes" />
                  <SettingRow icon={null} label="Privacy Controls" last />
               </div>
               
               <div className="bg-rose-50 p-6 rounded-[2rem] border border-rose-100 flex items-center justify-between group cursor-pointer hover:bg-rose-100 transition-all">
                  <div className="flex items-center gap-4">
                     <div className="w-10 h-10 bg-rose-500 text-white rounded-xl flex items-center justify-center shadow-lg">LOCK</div>
                     <span className="text-xs font-black text-rose-600 uppercase tracking-widest">Logout Session</span>
                  </div>
                  <span className="text-rose-300 font-black">X</span>
               </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};

const StatPill = ({ label, value, icon }: any) => (
  <div className="flex-1 bg-black/20 backdrop-blur-xl border border-white/5 p-4 rounded-3xl flex flex-col items-center shadow-lg transition-transform hover:-translate-y-1">
     <div className="mb-2">{icon}</div>
     <p className="text-xl font-black text-white font-mono leading-none tracking-tighter">{value}</p>
     <p className="text-[7px] font-black text-[#C5A059] uppercase tracking-widest mt-1.5">{label}</p>
  </div>
);

const NavBtn = ({ active, onClick, label }: any) => (
  <button onClick={onClick} className={`flex-none px-6 py-4 rounded-2xl text-[10px] font-black uppercase tracking-[0.2em] transition-all whitespace-nowrap ${active ? 'bg-white text-emerald-800 shadow-md scale-105' : 'text-stone-400 hover:text-stone-600'}`}>
    {label}
  </button>
);

const InfoRow = ({ label, value, icon, editable, type = "text", onChange }: any) => (
  <div className="bg-white p-5 rounded-[2rem] border border-stone-100 flex items-center justify-between group hover:border-emerald-200 transition-all">
    <div className="flex items-center gap-4">
      <div className="w-10 h-10 bg-stone-50 rounded-xl flex items-center justify-center text-emerald-800 border border-stone-100 group-hover:bg-stone-100 transition-colors">
        {icon}
      </div>
      <div>
        <p className="text-[8px] font-black text-stone-400 uppercase tracking-widest mb-0.5">{label}</p>
        {editable ? (
          <input 
            type={type} 
            value={value.replace(/ Years|@/g, '')} 
            onChange={e => onChange(e.target.value)}
            className="text-sm font-black text-emerald-950 bg-stone-50 px-3 py-1 rounded-lg outline-none border border-stone-100 focus:border-[#C5A059] transition-all w-32"
          />
        ) : (
          <p className="text-sm font-black text-emerald-950 tracking-tight">{value}</p>
        )}
      </div>
    </div>
    {!editable && <span className="text-stone-300 opacity-0 group-hover:opacity-100 transition-all font-black">GO</span>}
  </div>
);

const SettingRow = ({ icon, label, active, last }: any) => (
  <div className={`p-6 flex items-center justify-between group hover:bg-stone-50 transition-colors cursor-pointer ${!last ? 'border-b border-stone-50' : ''}`}>
    <div className="flex items-center gap-4">
       <div className="text-emerald-800">{icon}</div>
       <span className="text-xs font-black text-stone-600 uppercase tracking-widest">{label}</span>
    </div>
    <div className={`w-10 h-5 rounded-full p-1 transition-colors ${active ? 'bg-emerald-500' : 'bg-stone-200'}`}>
       <div className={`w-3 h-3 bg-white rounded-full transition-transform ${active ? 'translate-x-5' : 'translate-x-0'}`} />
    </div>
  </div>
);

export default ProfileView;
