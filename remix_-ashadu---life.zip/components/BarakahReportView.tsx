
import React, { useState, useMemo } from 'react';
import { 
  Download, 
  Share2, 
  Users, 
  Flame, 
  Heart,
  Sparkles,
  ChevronLeft,
  X,
  FileText,
  TrendingUp,
  Zap,
  Target,
  BadgeCheck,
  Crown,
  History,
  Coins,
  ArrowUpRight
} from 'lucide-react';
import { UserStats, UserProfile, SystemSettings, ZikrSessionRecord } from '../types';

interface BarakahReportViewProps {
  stats: UserStats;
  user: UserProfile | null;
  settings: SystemSettings;
  onClose: () => void;
}

const MOCK_ZIKR_HISTORY: ZikrSessionRecord[] = [
  { id: 'sh-1', groupName: 'Dawn Risers Collective', date: 'Oct 12, 2025', count: 12500, impact: 125.00, target: 50000, status: 'COMPLETED', isAdmin: false },
  { id: 'sh-2', groupName: 'Ramadan Global Noor', date: 'Sept 28, 2025', count: 45000, impact: 450.00, target: 100000, status: 'COMPLETED', isAdmin: true },
  { id: 'sh-3', groupName: 'Friday Salawat Circle', date: 'Sept 22, 2025', count: 3200, impact: 32.00, target: 10000, status: 'COMPLETED', isAdmin: false },
  { id: 'sh-4', groupName: 'Zakat Hub Mission', date: 'Aug 15, 2025', count: 8900, impact: 89.00, target: 20000, status: 'ARCHIVED', isAdmin: false },
  { id: 'sh-5', groupName: 'Hajj Prep Circle', date: 'July 04, 2025', count: 50000, impact: 500.00, target: 50000, status: 'COMPLETED', isAdmin: true },
];

const BarakahReportView: React.FC<BarakahReportViewProps> = ({ stats, user, settings, onClose }) => {
  const [selectedSession, setSelectedSession] = useState<ZikrSessionRecord | null>(null);
  const totalRaised = stats.totalCount * 0.01;
  const history = stats.zikrHistory || MOCK_ZIKR_HISTORY;

  // Penny Pulse Graph Logic (Simple SVG Timeline)
  const pulsePoints = [12, 45, 28, 62, 35, 84, 55, 92, 110, 142, 125, 150]; // Mock monthly £

  return (
    <div className="h-full flex flex-col bg-emerald-950 overflow-hidden animate-in fade-in duration-500 font-inter relative">
      {/* Dynamic Background */}
      <div className="absolute inset-0 celestial-map-grid opacity-5 pointer-events-none" />
      
      <header className="p-8 flex justify-between items-center z-10 shrink-0">
        <div className="flex items-center gap-3">
          <button onClick={onClose} className="p-3 bg-emerald-900 text-emerald-500 rounded-2xl hover:text-white transition-all"><ChevronLeft size={24}/></button>
          <div>
            <h2 className="text-2xl font-black text-white tracking-tighter uppercase leading-none">Spiritual Ledger</h2>
            <p className="text-[9px] text-emerald-500 font-black uppercase tracking-[0.4em] mt-2">Amanah Guard Analytics</p>
          </div>
        </div>
        <div className="flex gap-2">
           <button className="p-3 bg-white/5 rounded-2xl text-[#C5A059] border border-[#C5A059]/20 active:scale-90 transition-all"><Share2 size={20}/></button>
        </div>
      </header>

      <main className="flex-1 overflow-y-auto px-6 pb-40 space-y-8 custom-scrollbar">
         
         {/* 1. THE GOLDEN SUMMARY CARD */}
         <div className="bg-gradient-to-br from-[#C5A059] via-amber-400 to-[#C5A059] p-10 rounded-[3.5rem] shadow-[0_20px_60px_rgba(197,160,89,0.3)] relative overflow-hidden group">
            <div className="relative z-10">
               <div className="flex justify-between items-start mb-6">
                  <p className="text-[10px] font-black uppercase text-emerald-950 tracking-[0.4em]">Total Lifetime Noor</p>
                  <Crown size={24} className="text-emerald-950/40" />
               </div>
               <h3 className="text-6xl font-black text-emerald-950 font-mono tracking-tighter mb-8 leading-none">
                 {stats.totalCount.toLocaleString()}
               </h3>
               <div className="bg-emerald-950/10 backdrop-blur-md px-6 py-3 rounded-2xl inline-flex items-center gap-3 border border-white/20">
                  <Coins size={16} className="text-emerald-950" />
                  <span className="text-xs font-black text-emerald-950 uppercase tracking-widest">
                    £{totalRaised.toLocaleString(undefined, { minimumFractionDigits: 2 })} Raised to Date
                  </span>
               </div>
            </div>
            <Sparkles size={240} className="absolute -bottom-10 -right-10 opacity-10 group-hover:scale-110 transition-transform duration-1000 text-white" />
         </div>

         {/* 2. THE PENNY PULSE GRAPH */}
         <div className="bg-black/20 border border-emerald-900/50 p-8 rounded-[3rem] space-y-6">
            <div className="flex justify-between items-center px-2">
               <h3 className="text-[10px] font-black uppercase text-emerald-500 tracking-[0.4em]">The Penny Pulse</h3>
               <span className="text-[8px] font-black text-amber-500 uppercase tracking-widest bg-emerald-950 px-2 py-1 rounded-lg border border-[#C5A059]/20">12 Month Impact</span>
            </div>
            
            <div className="h-32 flex items-end justify-between gap-1.5 px-2 relative">
               {pulsePoints.map((val, i) => (
                 <div key={i} className="flex-1 flex flex-col items-center gap-2 group/bar">
                    <div 
                       className="w-full bg-[#C5A059]/20 border-t-2 border-[#C5A059] rounded-t-lg transition-all duration-700 group-hover/bar:bg-[#C5A059]/40" 
                       style={{ height: `${(val/150)*100}%` }}
                    />
                    <div className="absolute -top-6 left-1/2 -translate-x-1/2 opacity-0 group-hover/bar:opacity-100 transition-all bg-amber-500 text-emerald-950 text-[8px] font-black px-1.5 py-0.5 rounded">£{val}</div>
                 </div>
               ))}
               <div className="absolute inset-0 pointer-events-none border-b border-emerald-900/50" />
            </div>
         </div>

         {/* 3. SPIRITUAL MILESTONES GRID */}
         <div className="grid grid-cols-2 gap-4">
            <div className="bg-emerald-900/40 p-6 rounded-[2.5rem] border border-emerald-800 flex flex-col items-center justify-center text-center">
               <div className="p-3 bg-emerald-950 rounded-2xl text-[#C5A059] mb-3 shadow-inner"><Users size={20} /></div>
               <p className="text-2xl font-black text-white font-mono leading-none">48</p>
               <p className="text-[8px] font-black text-emerald-600 uppercase tracking-widest mt-2">Groups Joined</p>
            </div>
            <div className="bg-emerald-900/40 p-6 rounded-[2.5rem] border border-emerald-800 flex flex-col items-center justify-center text-center">
               <div className="p-3 bg-emerald-950 rounded-2xl text-[#C5A059] mb-3 shadow-inner"><Flame size={20} /></div>
               <p className="text-2xl font-black text-white font-mono leading-none">{stats.streak} Days</p>
               <p className="text-[8px] font-black text-emerald-600 uppercase tracking-widest mt-2">Longest Streak</p>
            </div>
         </div>

         {/* 4. THE ZIKR ARCHIVE */}
         <div className="space-y-6">
            <div className="flex justify-between items-center px-2">
               <h3 className="text-[10px] font-black uppercase text-emerald-500 tracking-[0.4em] flex items-center gap-2">
                  <History size={14} /> Session History
               </h3>
               <BadgeCheck size={16} className="text-[#C5A059]" />
            </div>

            <div className="space-y-4">
               {history.map((session) => (
                 <button 
                  key={session.id} 
                  onClick={() => setSelectedSession(session)}
                  className="w-full bg-emerald-900/20 border border-emerald-900/50 p-6 rounded-[2.5rem] flex items-center justify-between group hover:border-[#C5A059]/30 transition-all active:scale-[0.98]"
                 >
                    <div className="flex items-center gap-5 text-left">
                       <div className={`w-14 h-14 rounded-2xl flex items-center justify-center text-xl shadow-lg border ${session.isAdmin ? 'bg-amber-500/10 text-amber-500 border-amber-500/20' : 'bg-emerald-950 text-emerald-500 border-emerald-800'}`}>
                          {session.isAdmin ? <Crown size={28} /> : <Zap size={28} />}
                       </div>
                       <div>
                          <h4 className="font-black text-white text-sm uppercase tracking-tight flex items-center gap-2">
                            {session.groupName}
                            {session.isAdmin && <span className="text-[7px] bg-amber-500 text-emerald-950 px-1.5 py-0.5 rounded uppercase font-black">Founder</span>}
                          </h4>
                          <p className="text-[9px] text-emerald-700 font-black uppercase tracking-widest mt-1">{session.date}</p>
                       </div>
                    </div>
                    <div className="text-right">
                       <p className="text-sm font-black text-white font-mono">+{session.count.toLocaleString()}</p>
                       <p className="text-[10px] font-black text-amber-500 font-mono mt-0.5">£{session.impact.toFixed(2)}</p>
                    </div>
                 </button>
               ))}
            </div>
         </div>

         {/* 5. EXPORT BUTTON */}
         <button className="w-full bg-[#C5A059] text-emerald-950 font-black py-7 rounded-[2.5rem] shadow-xl flex items-center justify-center gap-4 transition-all active:scale-95 uppercase tracking-[0.3em] text-[10px] border-b-4 border-[#8c713b]">
            <FileText size={20} /> Export Detailed Ledger (PDF)
         </button>
      </main>

      {/* Session Resume Hook Overlay */}
      {selectedSession && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center p-6 bg-emerald-950/95 backdrop-blur-2xl animate-in fade-in duration-300">
          <div className="bg-emerald-900 w-full max-w-sm rounded-[3.5rem] border border-emerald-500/50 p-10 shadow-2xl relative overflow-hidden">
             <button onClick={() => setSelectedSession(null)} className="absolute top-6 right-6 p-2 text-emerald-500 hover:text-white"><X size={24}/></button>
             
             <div className="flex flex-col items-center text-center mb-10">
                <div className="w-20 h-20 bg-emerald-950 rounded-3xl flex items-center justify-center text-[#C5A059] mb-6 shadow-2xl border border-emerald-800">
                   <Target size={40} />
                </div>
                <h3 className="text-2xl font-black text-white uppercase tracking-tight mb-2">{selectedSession.groupName}</h3>
                <p className="text-[10px] text-emerald-400 font-black uppercase tracking-[0.4em]">Final Handshake: {selectedSession.date}</p>
             </div>

             <div className="space-y-6 mb-10">
                <div className="bg-black/20 p-6 rounded-3xl border border-emerald-800 flex justify-between items-center">
                   <div className="text-left">
                      <p className="text-[8px] font-black text-emerald-700 uppercase tracking-widest mb-1">Final Count</p>
                      <p className="text-xl font-black text-white font-mono">{selectedSession.count.toLocaleString()}</p>
                   </div>
                   <div className="text-right">
                      <p className="text-[8px] font-black text-emerald-700 uppercase tracking-widest mb-1">Impact Goal</p>
                      <p className="text-xl font-black text-amber-500 font-mono">£{selectedSession.impact.toFixed(2)}</p>
                   </div>
                </div>

                <div className="space-y-2">
                   <div className="flex justify-between px-2">
                      <span className="text-[8px] font-black text-emerald-700 uppercase">Target Achievement</span>
                      <span className="text-[8px] font-black text-white uppercase">{Math.min(100, (selectedSession.count / selectedSession.target)*100).toFixed(1)}%</span>
                   </div>
                   <div className="w-full h-3 bg-emerald-950 rounded-full overflow-hidden border border-emerald-800">
                      <div className="h-full bg-amber-500 shadow-[0_0_15px_rgba(197,160,89,0.4)]" style={{ width: `${Math.min(100, (selectedSession.count / selectedSession.target)*100)}%` }} />
                   </div>
                </div>
             </div>

             <button 
                onClick={() => setSelectedSession(null)}
                className="w-full py-5 bg-[#C5A059] text-emerald-950 rounded-2xl font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-2 shadow-xl active:scale-95 transition-all"
             >
                <ArrowUpRight size={16} /> Secure Handshake Verified
             </button>
          </div>
        </div>
      )}

      {/* Verified Transparency Footer */}
      <div className="fixed bottom-0 left-0 w-full p-6 text-center bg-gradient-to-t from-emerald-950 via-emerald-950/80 to-transparent pointer-events-none opacity-40">
        <div className="flex items-center justify-center gap-3">
           <BadgeCheck size={14} className="text-[#C5A059]" />
           <p className="text-[9px] font-black text-white uppercase tracking-[0.6em]">ASHADU AMANAH LEDGER v2.5</p>
        </div>
      </div>
    </div>
  );
};

export default BarakahReportView;
