
import React, { useState, useEffect, useMemo } from 'react';
import { 
  Moon, 
  ArrowRight, 
  Calendar, 
  Coins, 
  ShieldCheck, 
  Check, 
  Sparkles, 
  CalendarCheck, 
  ChevronDown, 
  ChevronUp, 
  X,
  AlertCircle
} from 'lucide-react';
import { saveUserData } from '../services/supabaseService';
import { UserStats, UserProfile, GlobalPricing } from '../types';
import DigitalLantern from './DigitalLantern';

interface RamadanTrackerProps {
  stats: UserStats;
  user: UserProfile | null;
  onUpdateStats: (newStats: UserStats) => void;
  pricing: GlobalPricing;
}

const RamadanTracker: React.FC<RamadanTrackerProps> = ({ stats, user, onUpdateStats, pricing }) => {
  const [timeLeft, setTimeLeft] = useState('00:00:00');
  const [startDate, setStartDate] = useState(() => {
    return localStorage.getItem('ashadu_ramadan_start_date') || '';
  });

  const fastingLog = useMemo(() => stats.fastingLog || {}, [stats.fastingLog]);
  const daysArray = Array.from({ length: 30 }, (_, i) => i + 1);

  useEffect(() => {
    localStorage.setItem('ashadu_ramadan_start_date', startDate);
    if (user?.email && startDate) {
      saveUserData(user.email, { ramadan_start_date: startDate });
    }
  }, [startDate, user?.email]);

  const getDayDate = (day: number) => {
    if (!startDate) return null;
    const date = new Date(startDate);
    date.setDate(date.getDate() + (day - 1));
    return date.toLocaleDateString('en-GB', { day: '2-digit', month: 'short' });
  };

  const completedCount = Object.values(fastingLog).filter(s => s === 'completed').length;
  const missedCount = Object.values(fastingLog).filter(s => typeof s === 'string' && s.startsWith('missed')).length;
  const totalFasts = 30;
  const remainingCount = Math.max(0, totalFasts - completedCount - missedCount);
  const progress = completedCount / totalFasts;
  const fidyahRate = pricing.fastMissedExcused || 10;
  const totalLiability = missedCount * fidyahRate;

  useEffect(() => {
    const timer = setInterval(() => {
      const now = new Date();
      const hour = now.getHours();
      const minutes = 59 - now.getMinutes();
      const h = (hour >= 19 || hour < 4) ? (hour < 4 ? 4 - hour : 28 - hour) : 19 - hour;
      setTimeLeft(`${h < 10 ? '0' + h : h}H ${minutes < 10 ? '0' + minutes : minutes}M`);
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const handleToggleStatus = async (day: number, targetStatus: 'completed' | 'missed-excused') => {
    const newLog = { ...fastingLog };
    if (newLog[day] === targetStatus) {
      delete newLog[day];
    } else {
      newLog[day] = targetStatus;
    }
    
    onUpdateStats({ ...stats, fastingLog: newLog });

    if (user?.email) {
      await saveUserData(user.email, { fasting_log: newLog });
    }
  };

  return (
    <div className="flex-1 flex flex-col bg-[#022c22] font-inter overflow-hidden">
      <div className="flex-1 overflow-y-auto custom-scrollbar">
        <div className="flex flex-col items-center py-8 relative shrink-0">
          <div className="mb-4"><DigitalLantern progress={progress} /></div>
          <div className="relative w-24 h-24 mb-4 flex items-center justify-center">
              <div className="absolute inset-0 rounded-full border border-[#C5A059]/20 shadow-[0_0_20px_rgba(197,160,89,0.1)]" />
              <Moon size={48} className="text-[#C5A059]" />
          </div>
          <h2 className="text-xl font-black text-white uppercase tracking-tighter">Ramadan Ledger</h2>
          <p className="text-[9px] font-black text-[#C5A059] uppercase tracking-[0.4em] mt-2 animate-pulse">{timeLeft} UNTIL IFTAR</p>
        </div>

        <div className="px-6 mb-6 shrink-0 space-y-4">
          {/* START DATE TAB */}
          <div className="bg-[#053131] border border-[#C5A059]/30 rounded-3xl p-5 shadow-xl">
            <label className="text-[9px] font-black uppercase text-emerald-500 tracking-[0.3em] ml-2 flex items-center gap-2 mb-3">
              <Calendar size={12} /> RAMADAN START DATE
            </label>
            <input 
              type="date" 
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="w-full bg-black/40 border border-[#0A4242] rounded-2xl p-4 text-white font-bold outline-none focus:border-[#C5A059] transition-all text-sm"
            />
          </div>

          <div className="bg-[#064e3b]/40 border border-[#C5A059]/20 rounded-3xl p-6 flex justify-around text-center shadow-2xl backdrop-blur-md">
             <div><p className="text-3xl font-black text-white font-mono leading-none">{completedCount}</p><p className="text-[7px] font-black text-emerald-500 uppercase mt-2 tracking-widest">Done</p></div>
             <div className="w-px h-8 bg-white/5" />
             <div><p className="text-3xl font-black text-red-400 font-mono leading-none">{missedCount}</p><p className="text-[7px] font-black text-emerald-500 uppercase mt-2 tracking-widest">Missed</p></div>
             <div className="w-px h-8 bg-white/5" />
             <div><p className="text-3xl font-black text-[#C5A059] font-mono leading-none">{remainingCount}</p><p className="text-[7px] font-black text-emerald-500 uppercase mt-2 tracking-widest">Wait</p></div>
          </div>
        </div>

        <div className="px-6 pb-40 space-y-4">
          <div className="flex justify-between items-center mb-4 px-1 shrink-0">
            <p className="text-[10px] font-black text-emerald-700 uppercase tracking-[0.4em]">30-Day Sequence</p>
            <div className="flex items-center gap-2">
               <Sparkles size={12} className="text-[#C5A059]" />
               <span className="text-[8px] font-black text-white/20 uppercase tracking-widest">Auto-Persist Active</span>
            </div>
          </div>
          
          <div className="space-y-2">
             {daysArray.map(day => {
                const status = fastingLog[day];
                const dayDate = getDayDate(day);
                return (
                  <div 
                    key={day} 
                    className={`flex items-center justify-between p-4 rounded-2xl border transition-all duration-300
                      ${status === 'completed' ? 'bg-emerald-900/40 border-[#C5A059]/30 shadow-lg shadow-emerald-950/20' : 
                        status === 'missed-excused' ? 'bg-red-950/20 border-red-500/20' : 'bg-black/20 border-white/5'}`}
                  >
                     <div className="flex items-center gap-4">
                        <div className={`w-10 h-10 rounded-xl flex flex-col items-center justify-center font-black border
                          ${status === 'completed' ? 'bg-[#C5A059] text-[#022c22] border-[#C5A059]' : 
                            status === 'missed-excused' ? 'bg-red-500/10 text-red-400 border-red-500/30' : 'bg-emerald-950 text-emerald-800 border-emerald-900'}`}>
                           <span className="text-xs leading-none">{day}</span>
                           {dayDate && <span className="text-[6px] mt-0.5 opacity-60">{dayDate}</span>}
                        </div>
                        <div className="flex flex-col">
                          <span className={`text-[10px] font-black uppercase tracking-widest ${status ? 'text-white' : 'text-emerald-700'}`}>
                            {status === 'completed' ? 'Fulfillment' : status === 'missed-excused' ? 'Compensatory' : 'Pending'}
                          </span>
                          {dayDate && (
                            <span className="text-[7px] font-bold text-[#C5A059]/60 uppercase tracking-widest mt-0.5">
                              {dayDate}
                            </span>
                          )}
                        </div>
                     </div>

                     <div className="flex gap-2">
                        <button 
                          onClick={() => handleToggleStatus(day, 'completed')}
                          className={`px-4 py-2 rounded-lg text-[8px] font-black uppercase tracking-widest transition-all border
                            ${status === 'completed' ? 'bg-emerald-500 border-emerald-400 text-white' : 'bg-black/40 border-white/5 text-emerald-800 hover:border-emerald-700'}`}
                        >
                          Done
                        </button>
                        <button 
                          onClick={() => handleToggleStatus(day, 'missed-excused')}
                          className={`px-4 py-2 rounded-lg text-[8px] font-black uppercase tracking-widest transition-all border
                            ${status === 'missed-excused' ? 'bg-red-500 border-red-400 text-white' : 'bg-black/40 border-white/5 text-emerald-800 hover:border-red-900/30'}`}
                        >
                          Missed
                        </button>
                     </div>
                  </div>
                )
             })}
          </div>
        </div>
      </div>

      <div className="shrink-0 px-6 py-4 space-y-3 bg-[#022c22] border-t border-white/5">
        {missedCount > 0 && (
          <button className="w-full py-4 bg-emerald-900/60 border border-red-500/30 text-white rounded-2xl font-black uppercase tracking-widest text-[9px] flex items-center justify-between px-6 active:scale-95 transition-all shadow-xl backdrop-blur-md">
             <div className="flex items-center gap-3"><Coins size={16} className="text-red-400"/><span>Liability: Fidya</span></div>
             <span className="text-lg font-mono">£{totalLiability.toFixed(2)}</span>
          </button>
        )}
        <button className="w-full py-5 btn-gold rounded-3xl font-black uppercase tracking-widest text-[10px] flex items-center justify-center gap-3 shadow-2xl">
           <ShieldCheck size={18} /> Seal Ramadan Amanah
        </button>
      </div>
      
      <div className="absolute inset-0 celestial-grid pointer-events-none opacity-10" />
    </div>
  );
};

export default RamadanTracker;
