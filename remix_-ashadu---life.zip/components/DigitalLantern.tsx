import React from 'react';
import { Sparkles } from 'lucide-react';

interface DigitalLanternProps {
  progress: number; 
}

const DigitalLantern: React.FC<DigitalLanternProps> = ({ progress }) => {
  const glowIntensity = 20 + (progress * 80); 
  const color = '#F59E0B'; // Warm Amber
  
  return (
    <div className="relative flex items-center justify-center w-24 h-24">
      <div 
        className="absolute inset-0 rounded-full blur-3xl transition-all duration-1000"
        style={{ 
          boxShadow: `0 0 ${glowIntensity}px ${color}`, 
          opacity: 0.15 + (progress * 0.4),
          backgroundColor: color 
        }} 
      />
      <div className="relative z-10 animate-pulse border border-[#C5A059]/30 p-5 rounded-3xl bg-[#064e3b] shadow-2xl shadow-black/50">
        <Sparkles 
          size={40} 
          className="text-[#C5A059]"
        />
      </div>
    </div>
  );
};

export default DigitalLantern;