import { Link, useLocation } from "react-router-dom";
const NAV_ITEMS = [
  { label: "Home", icon: "🏠", to: "/ummah/dashboard" },
  { label: "Wall", icon: "📱", to: "/ummah/wall" },
  { label: "Connect", icon: "🔥", to: "/ummah/connect" },
  { label: "Map", icon: "🕌", to: "/ummah/map" },
  { label: "Profile", icon: "👤", to: "/profile" },
];

export default function UmmahNav() {
  const location = useLocation();

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-[#022c22]/90 backdrop-blur-xl border-t border-[#C5A059]/20 px-6 py-4 z-[200]">
      <div className="max-w-lg mx-auto flex justify-between items-center">
        {NAV_ITEMS.map((item) => {
          const isActive = location.pathname === item.to;
          return (
            <Link
              key={item.to}
              to={item.to}
              className="flex flex-col items-center gap-1.5 group"
            >
              <span className={`text-xl transition-all duration-300 ${isActive ? 'scale-125 brightness-125' : 'opacity-60 group-hover:opacity-100 group-hover:scale-110'}`}>
                {item.icon}
              </span>
              <span className={`text-[8px] font-black uppercase tracking-[0.2em] transition-colors ${isActive ? 'text-[#C5A059]' : 'text-emerald-700 group-hover:text-emerald-500'}`}>
                {item.label}
              </span>
              {isActive && (
                <div className="w-1 h-1 bg-[#C5A059] rounded-full mt-0.5 shadow-[0_0_8px_#C5A059]" />
              )}
            </Link>
          );
        })}
      </div>
    </nav>
  );
}