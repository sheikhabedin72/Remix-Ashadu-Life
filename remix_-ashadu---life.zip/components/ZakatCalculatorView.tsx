import React, { useState, useMemo, useEffect } from 'react';
import { 
  Calculator, 
  Coins, 
  TrendingUp, 
  Info, 
  ShieldCheck, 
  ArrowRight, 
  Wallet, 
  Gem, 
  Briefcase, 
  MinusCircle, 
  Heart,
  ChevronDown,
  AlertCircle,
  Banknote,
  History,
  ClipboardList,
  Check,
  Plus,
  Trash2,
  FileText,
  Download,
  Scale,
  Users,
  UserPlus,
  BarChart3,
  LayoutDashboard,
  Sparkles,
  Award,
  Diamond,
  Zap,
  Lock,
  ChevronRight,
  RefreshCw,
  X,
  HandHeart,
  Save
} from 'lucide-react';
import { SystemSettings, ZakatRecord, ZakatFitrRecord } from '../types';
import { db } from '../services/databaseService';

interface ZakatCalculatorViewProps {
  settings: SystemSettings;
  onNavigateToLegacy: () => void;
}

const ZakatCalculatorView: React.FC<ZakatCalculatorViewProps> = ({ settings, onNavigateToLegacy }) => {
  const [activeTab, setActiveTab] = useState<'calculator' | 'mal-ledger' | 'fitr-tracker' | 'summary'>('calculator');
  const [assets, setAssets] = useState({
    cash: 0, 
    goldGrams: 0, 
    silverGrams: 0, 
    investments: 0, 
    moneyOwedToMe: 0, 
    debts: 0,
    alreadyPaid: 0
  });

  const [fitrData, setFitrData] = useState({
    familyMembers: 1,
    paidMembers: 0
  });

  const [records, setRecords] = useState<ZakatRecord[]>([]);
  const [fitrRecords, setFitrRecords] = useState<ZakatFitrRecord[]>([]);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    const loadLedgers = async () => {
      const savedMal = await db.getZakatRecords();
      setRecords(savedMal);
      const savedFitr = localStorage.getItem('ashadu_zakat_fitr');
      if (savedFitr) setFitrRecords(JSON.parse(savedFitr));
    };
    loadLedgers();
  }, []);

  const goldPrice = settings?.zakat?.goldPriceGram ?? 58.42;
  const silverPrice = settings?.zakat?.silverPriceGram ?? 0.72;
  const fitrRate = settings?.zakat?.fitrRatePerPerson ?? 5.00;
  const thresholdType = settings?.zakat?.nisabThresholdType ?? 'SILVER';

  const goldValue = assets.goldGrams * goldPrice;
  const silverValue = assets.silverGrams * silverPrice;
  
  const totalWealth = useMemo(() => {
    return (assets.cash || 0) + (goldValue || 0) + (silverValue || 0) + (assets.investments || 0) + (assets.moneyOwedToMe || 0);
  }, [assets, goldValue, silverValue]);
  
  const netWealth = Math.max(0, totalWealth - (assets.debts || 0));
  const nisabThreshold = thresholdType === 'GOLD' ? 87.48 * goldPrice : 612.36 * silverPrice;
  const isLiable = netWealth >= nisabThreshold;
  
  // Total Zakat before any deductions
  const grossZakatDue = isLiable ? netWealth * 0.025 : 0;
  // Final Zakat due after subtracting already paid amount
  const netZakatDue = Math.max(0, grossZakatDue - (assets.alreadyPaid || 0));

  const totalFitrDue = fitrData.familyMembers * fitrRate;
  const remainingFitrDue = Math.max(0, (fitrData.familyMembers - fitrData.paidMembers) * fitrRate);

  const handleSaveForLater = async () => {
    setIsSaving(true);
    const newRecord: ZakatRecord = {
      id: `Z-MAL-${Date.now()}`,
      date: new Date().toLocaleDateString('en-GB'),
      customName: 'Wealth Purification Draft',
      category: 'Hybrid Calculation',
      assetValue: netWealth,
      zakatDue: netZakatDue,
      amountPaid: assets.alreadyPaid,
      status: 'PENDING'
    };
    await db.upsertZakatRecord(newRecord);
    const updated = await db.getZakatRecords();
    setRecords(updated);
    setTimeout(() => {
      setIsSaving(false);
      setActiveTab('mal-ledger');
    }, 800);
  };

  const handleSaveFitr = () => {
    const newRecord: ZakatFitrRecord = {
      id: `Z-FITR-${Date.now()}`,
      year: new Date().getFullYear().toString(),
      familyCount: fitrData.familyMembers,
      amountPaid: fitrData.paidMembers * fitrRate,
      status: fitrData.paidMembers >= fitrData.familyMembers ? 'SETTLED' : 'PARTIAL'
    };
    const updated = [newRecord, ...fitrRecords];
    setFitrRecords(updated);
    localStorage.setItem('ashadu_zakat_fitr', JSON.stringify(updated));
    alert("Fitr Ledger Updated Successfully.");
  };

  const handleGeneratePaymentLink = () => {
    alert(`Initializing Amanah Payment Gateway...\nNet Zakat Remaining: £${netZakatDue.toFixed(2)}\n\nYour transaction will be encrypted and written to the Permanent Ledger.`);
  };

  return (
    <div className="h-full flex flex-col bg-[#022c22] animate-in fade-in duration-700 overflow-hidden relative font-inter">
      {/* Emerald Overlay Background */}
      <div className="absolute inset-0 celestial-grid opacity-10 pointer-events-none" />
      <div className="absolute inset-0 bg-emerald-950/40 backdrop-blur-[2px] pointer-events-none" />

      <header className="p-8 flex justify-between items-center bg-black/40 border-b border-[#C5A059]/20 backdrop-blur-xl z-20">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-emerald-950 rounded-2xl flex items-center justify-center border border-[#C5A059]/30 shadow-lg">
            <Calculator className="text-[#C5A059]" size={24} />
          </div>
          <div>
            <h2 className="text-xl font-black text-white tracking-tighter uppercase leading-none">Zakat <span className="text-[#C5A059]">Portal</span></h2>
            <p className="text-[9px] text-[#C5A059]/60 font-black uppercase tracking-[0.3em] mt-1.5">Fulfill your Amanah</p>
          </div>
        </div>
        <div className="flex gap-2 p-1 bg-emerald-900/40 rounded-xl border border-white/5">
            <TabBtn active={activeTab === 'calculator'} onClick={() => setActiveTab('calculator')} label="MAL" />
            <TabBtn active={activeTab === 'fitr-tracker'} onClick={() => setActiveTab('fitr-tracker')} label="FITR" />
            <TabBtn active={activeTab === 'mal-ledger'} onClick={() => setActiveTab('mal-ledger')} label="LEDGER" />
            <TabBtn active={activeTab === 'summary'} onClick={() => setActiveTab('summary')} label="STATS" />
        </div>
      </header>

      <div className="flex-1 overflow-y-auto p-6 pb-40 space-y-10 custom-scrollbar relative z-10">
        {activeTab === 'calculator' && (
          <div className="max-w-md mx-auto space-y-8 animate-in slide-in-from-bottom-4 duration-500">
            
            {/* INSTRUCTIONAL HEADER */}
            <div className="text-center space-y-2 mb-4">
               <h3 className="text-[#C5A059] font-black text-sm uppercase tracking-[0.2em]">Wealth Purification (Zakat al-Mal)</h3>
               <p className="text-emerald-500 text-[9px] font-bold uppercase tracking-widest">Amanah Verification Protocol v3.9</p>
            </div>

            <div className="space-y-4">
              <AmanahInput label="Cash on Hand & Bank" value={assets.cash} onChange={(v: number) => setAssets({...assets, cash: v})} />
              
              <div className="grid grid-cols-2 gap-4">
                <AmanahInput label="Gold (Grams)" value={assets.goldGrams} isNumeric onChange={(v: number) => setAssets({...assets, goldGrams: v})} />
                <AmanahInput label="Silver (Grams)" value={assets.silverGrams} isNumeric onChange={(v: number) => setAssets({...assets, silverGrams: v})} />
              </div>
 
              <AmanahInput label="Investment Stocks/Crypto" value={assets.investments} onChange={(v: number) => setAssets({...assets, investments: v})} />
              <AmanahInput label="Money Owed to You" value={assets.moneyOwedToMe} onChange={(v: number) => setAssets({...assets, moneyOwedToMe: v})} />
              
              <div className="h-px w-full bg-[#C5A059]/20 my-6 relative">
                 <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 bg-[#022c22] px-4">
                    <MinusCircle size={16} className="text-[#C5A059]/40" />
                 </div>
              </div>
              
              <AmanahInput label="Immediate Debts/Bills" value={assets.debts} onChange={(v: number) => setAssets({...assets, debts: v})} isDebt />
 
              {/* ZAKAT ALREADY PAID SECTION */}
              <div className="space-y-2">
                 <AmanahInput 
                   label="ZAKAT ALREADY PAID" 
                   value={assets.alreadyPaid} 
                   onChange={(v: number) => setAssets({...assets, alreadyPaid: v})} 
                   isDeduction
                 />
                 <p className="text-[8px] text-emerald-600 font-bold uppercase tracking-widest px-6">This amount will be deducted from your total obligation.</p>
              </div>
            </div>

            {/* RESULT BOX WITH CIRCUIT WATERMARK */}
            <div className={`p-10 rounded-[3.5rem] border-2 transition-all duration-700 relative overflow-hidden group shadow-[0_30px_100px_rgba(0,0,0,0.6)]
              ${isLiable ? 'bg-emerald-900 border-[#C5A059] shadow-[0_0_50px_rgba(197,160,89,0.15)]' : 'bg-emerald-900/30 border-emerald-800'}`}>
              
              <div className="relative z-10 text-center">
                <p className="text-[10px] uppercase font-black tracking-[0.4em] text-[#C5A059] mb-4">REMAINING ZAKAT DUE</p>
                <h1 className={`text-6xl font-black font-mono tracking-tighter mb-8 leading-none ${isLiable ? 'text-white' : 'text-emerald-950'}`}>
                  £{netZakatDue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </h1>
                
                {assets.alreadyPaid > 0 && isLiable && (
                   <div className="mb-4 bg-black/20 py-2 px-4 rounded-xl inline-block border border-white/5">
                      <p className="text-[8px] font-black text-emerald-500 uppercase tracking-widest">
                         Gross: £{grossZakatDue.toFixed(2)} | Paid: £{assets.alreadyPaid.toFixed(2)}
                      </p>
                   </div>
                )}

                <div className="flex items-center justify-center gap-3">
                   <div className={`w-2 h-2 rounded-full ${isLiable ? 'bg-[#C5A059] animate-pulse shadow-[0_0_15px_#C5A059]' : 'bg-emerald-950'}`} />
                   <span className={`text-[9px] font-black uppercase tracking-[0.4em] ${isLiable ? 'text-white' : 'text-emerald-800'}`}>
                     {isLiable ? 'OBLIGATION ACTIVE' : 'BELOW NISAB THRESHOLD'}
                   </span>
                </div>
              </div>
              <Sparkles size={220} className="absolute -bottom-16 -right-16 opacity-5 rotate-12 group-hover:scale-125 transition-transform duration-[3000ms] text-[#C5A059]" />
            </div>

            {/* ACTION BUTTONS */}
            <div className="space-y-4">
              <button 
                onClick={handleGeneratePaymentLink}
                disabled={!isLiable}
                className={`w-full py-8 rounded-[2.5rem] font-black uppercase tracking-[0.3em] text-[11px] shadow-2xl transition-all flex items-center justify-center gap-4 active:scale-95 border-b-4 
                  ${isLiable ? 'btn-gold border-[#8c713b]' : 'bg-emerald-900/40 text-emerald-800 border-emerald-950 cursor-not-allowed opacity-50'}`}
              >
                <Banknote size={20} /> GENERATE PAYMENT LINK
              </button>
              
              <button 
                onClick={handleSaveForLater}
                disabled={isSaving}
                className="w-full bg-emerald-900/40 border border-[#C5A059]/30 text-[#C5A059] py-5 rounded-3xl font-black uppercase tracking-widest text-[9px] flex items-center justify-center gap-3 hover:bg-emerald-800 transition-all"
              >
                <Save size={16} /> {isSaving ? 'SECURING DRAFT...' : 'Save for Later'}
              </button>
            </div>
          </div>
        )}

        {activeTab === 'fitr-tracker' && (
          <div className="max-w-md mx-auto space-y-8 animate-in slide-in-from-bottom-4 duration-500">
            <div className="text-center space-y-2 mb-4">
               <h3 className="text-[#C5A059] font-black text-sm uppercase tracking-[0.2em]">Zakat al-Fitr Tracker</h3>
               <p className="text-emerald-500 text-[9px] font-bold uppercase tracking-widest">Ramadan Completion Protocol</p>
            </div>

            <div className="bg-emerald-900/30 p-8 rounded-[3rem] border border-[#C5A059]/20 space-y-6">
              <div className="flex justify-between items-center">
                <span className="text-[10px] font-black text-emerald-500 uppercase tracking-widest">Rate per Person</span>
                <span className="text-xl font-black text-white font-mono">£{fitrRate.toFixed(2)}</span>
              </div>

              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-[9px] font-black uppercase text-amber-500 tracking-widest ml-1">Family Members</label>
                  <div className="flex items-center gap-4 bg-black/40 p-4 rounded-2xl border border-emerald-800">
                    <button onClick={() => setFitrData(d => ({...d, familyMembers: Math.max(1, d.familyMembers - 1)}))} className="p-2 text-emerald-500"><MinusCircle size={20} /></button>
                    <span className="flex-1 text-center text-2xl font-black text-white font-mono">{fitrData.familyMembers}</span>
                    <button onClick={() => setFitrData(d => ({...d, familyMembers: d.familyMembers + 1}))} className="p-2 text-emerald-500"><Plus size={20} /></button>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-[9px] font-black uppercase text-emerald-500 tracking-widest ml-1">Members Paid For</label>
                  <div className="flex items-center gap-4 bg-black/40 p-4 rounded-2xl border border-emerald-800">
                    <button onClick={() => setFitrData(d => ({...d, paidMembers: Math.max(0, d.paidMembers - 1)}))} className="p-2 text-emerald-500"><MinusCircle size={20} /></button>
                    <span className="flex-1 text-center text-2xl font-black text-white font-mono">{fitrData.paidMembers}</span>
                    <button onClick={() => setFitrData(d => ({...d, paidMembers: Math.min(fitrData.familyMembers, d.paidMembers + 1)}))} className="p-2 text-emerald-500"><Plus size={20} /></button>
                  </div>
                </div>
              </div>

              <div className="pt-6 border-t border-emerald-800 flex justify-between items-center">
                <div>
                  <p className="text-[9px] font-black text-emerald-600 uppercase tracking-widest">Remaining Due</p>
                  <p className="text-3xl font-black text-white font-mono">£{remainingFitrDue.toFixed(2)}</p>
                </div>
                <button 
                  onClick={handleSaveFitr}
                  className="bg-amber-500 text-emerald-950 px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest shadow-lg active:scale-95 transition-all"
                >
                  Update Ledger
                </button>
              </div>
            </div>

            <div className="space-y-4">
              <h4 className="text-[10px] font-black text-emerald-800 uppercase tracking-[0.4em] px-2">Fitr History</h4>
              {fitrRecords.length === 0 ? (
                <div className="p-10 text-center bg-black/20 rounded-[2rem] border border-dashed border-emerald-900">
                  <p className="text-[9px] text-emerald-800 font-black uppercase tracking-widest">No Fitr history recorded</p>
                </div>
              ) : (
                fitrRecords.map(r => (
                  <div key={r.id} className="bg-emerald-900/20 border border-emerald-800/30 p-5 rounded-2xl flex justify-between items-center">
                    <div>
                      <p className="text-[10px] font-black text-white uppercase tracking-tight">Ramadan {r.year}</p>
                      <p className="text-[8px] text-emerald-600 font-black uppercase tracking-widest mt-1">{r.familyCount} Members • {r.status}</p>
                    </div>
                    <p className="text-sm font-black text-amber-500 font-mono">£{r.amountPaid.toFixed(2)}</p>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {activeTab === 'mal-ledger' && (
          <div className="space-y-6 animate-in slide-in-from-right-4 duration-500">
             <div className="flex justify-between items-center px-4">
                <h3 className="text-[11px] font-black text-emerald-500 uppercase tracking-[0.4em]">Wealth Ledger</h3>
                <span className="bg-emerald-900 px-3 py-1 rounded-full text-[8px] font-black uppercase text-emerald-600 border border-white/5">{records.length} Records</span>
             </div>

             {records.length === 0 ? (
               <div className="p-20 text-center bg-black/20 rounded-[3.5rem] border border-dashed border-emerald-900">
                  <ClipboardList size={48} className="mx-auto text-emerald-900 mb-6 opacity-40" />
                  <p className="text-[10px] text-emerald-700 font-black uppercase tracking-widest">No spiritual drafts archived yet</p>
               </div>
             ) : (
               <div className="space-y-4">
                   {records.map(record => (
                    <div key={record.id} className="bg-emerald-900/30 border border-[#C5A059]/20 p-6 rounded-[2.5rem] flex items-center justify-between group hover:bg-emerald-900/50 transition-all">
                       <div className="flex items-center gap-5">
                          <div className={`w-12 h-12 rounded-xl flex items-center justify-center bg-emerald-950 text-[#C5A059] border border-white/5`}>
                             <FileText size={20} />
                          </div>
                          <div>
                             <h4 className="font-black text-white text-sm uppercase">{record.customName}</h4>
                             <p className="text-[8px] text-emerald-600 font-black uppercase tracking-widest mt-1">{record.date} • {record.status}</p>
                          </div>
                       </div>
                       <div className="text-right">
                          <p className="text-lg font-black text-white font-mono leading-none">£{record.zakatDue.toFixed(2)}</p>
                          <button className="mt-2 text-[8px] font-black uppercase text-amber-500 tracking-widest flex items-center gap-1.5 ml-auto opacity-0 group-hover:opacity-100 transition-opacity">
                             RESUME <ChevronRight size={10} />
                          </button>
                       </div>
                    </div>
                  ))}
               </div>
             )}
          </div>
        )}

        {activeTab === 'summary' && (
          <div className="space-y-8 animate-in slide-in-from-bottom-4 duration-500 max-w-md mx-auto">
            <div className="bg-[#011a14] border-2 border-[#C5A059]/40 p-10 rounded-[4rem] shadow-[0_40px_100px_rgba(0,0,0,0.7)] relative overflow-hidden backdrop-blur-3xl">
                <div className="relative z-10 text-center">
                   <h3 className="text-3xl font-black text-white uppercase tracking-tighter leading-none">Purity Report</h3>
                   <p className="text-[10px] text-emerald-500 font-black uppercase tracking-[0.5em] mt-4 italic">Permanent Spiritual Status</p>
                   
                   <div className="mt-12 space-y-6">
                      <div className="bg-emerald-950/60 p-8 rounded-[2.5rem] border border-emerald-800">
                         <p className="text-[9px] font-black text-emerald-600 uppercase tracking-widest mb-2">Total Wealth Purified</p>
                         <h4 className="text-4xl font-black text-white font-mono">£{records.reduce((acc, r) => acc + (r.status === 'SETTLED' ? r.zakatDue : 0), 0).toFixed(2)}</h4>
                      </div>

                      <div className="bg-emerald-950/60 p-8 rounded-[2.5rem] border border-emerald-800">
                         <p className="text-[9px] font-black text-emerald-600 uppercase tracking-widest mb-2">Pending Obligations</p>
                         <h4 className="text-4xl font-black text-amber-500 font-mono">£{records.reduce((acc, r) => acc + (r.status === 'PENDING' ? r.zakatDue : 0), 0).toFixed(2)}</h4>
                      </div>

                      <div className="bg-emerald-950/60 p-8 rounded-[2.5rem] border border-emerald-800">
                         <p className="text-[9px] font-black text-emerald-600 uppercase tracking-widest mb-2">Fitr Contributions</p>
                         <h4 className="text-4xl font-black text-cyan-400 font-mono">£{fitrRecords.reduce((acc, r) => acc + r.amountPaid, 0).toFixed(2)}</h4>
                      </div>
                   </div>

                   <button 
                    onClick={onNavigateToLegacy}
                    className="w-full btn-gold py-7 rounded-[2.5rem] mt-10 flex items-center justify-center gap-4 uppercase tracking-[0.4em] text-[10px] shadow-xl border-b-4 border-[#8c713b]"
                   >
                      <HandHeart size={18} /> View Legacy Impact
                   </button>
                </div>
             </div>
          </div>
        )}
      </div>

      {/* FOOTER SEAL */}
      <footer className="shrink-0 p-8 border-t border-white/5 bg-black/20 backdrop-blur-md flex justify-center items-center gap-3">
         <p className="text-[9px] font-black text-[#C5A059]/40 uppercase tracking-[0.6em]">SECURE AMANAH HANDSHAKE VERIFIED</p>
      </footer>
    </div>
  );
};

const TabBtn = ({ active, onClick, label }: any) => (
  <button onClick={onClick} className={`p-4 rounded-xl transition-all relative group flex items-center justify-center font-black text-[8px] uppercase tracking-widest
    ${active ? 'bg-[#C5A059] text-[#022c22] shadow-lg scale-110' : 'text-emerald-700 hover:text-white'}`}>
    {label}
  </button>
);

const AmanahInput = ({ label, value, onChange, isNumeric = false, isDebt = false, isDeduction = false }: any) => (
  <div className={`p-6 rounded-[2.5rem] border transition-all flex items-center justify-between group bg-black/30 backdrop-blur-md 
    ${isDebt ? 'border-red-900/30 hover:border-red-500/50' : 
      isDeduction ? 'border-cyan-900/30 hover:border-cyan-500/50 shadow-[0_0_20px_rgba(34,211,238,0.05)]' :
      'border-[#C5A059]/30 hover:border-[#C5A059] shadow-[0_0_20px_rgba(197,160,89,0.05)]'}`}>
     <div className="flex items-center gap-6 w-full">
        <div className="flex-1">
           <label className={`text-[9px] font-black uppercase block mb-1 tracking-widest 
             ${isDebt ? 'text-red-900' : isDeduction ? 'text-cyan-700' : 'text-emerald-700'}`}>{label}</label>
           <div className="flex items-center gap-2">
              {!isNumeric && <span className="text-xl font-black text-white/20 font-mono">£</span>}
              <input 
                type="number" 
                value={value || ''} 
                onChange={e => {
                  const val = e.target.value === '' ? 0 : parseFloat(e.target.value);
                  onChange(isNaN(val) ? 0 : val);
                }} 
                className="bg-transparent text-2xl font-black text-white outline-none w-full placeholder:text-white/5 font-mono tracking-tighter" 
                placeholder="0" 
              />
           </div>
        </div>
     </div>
  </div>
);

export default ZakatCalculatorView;