
import React, { useState, useMemo, useCallback } from 'react';
import { Phrase } from '../types';
import { Check, ChevronRight, BookOpen, Plus, Pencil, Trash2, X, Save, RefreshCw, Search, Sparkles } from 'lucide-react';
import { ALLAH_NAMES } from '../constants';

interface LibraryProps {
  phrases: Phrase[];
  activeId: string;
  onSelect: (p: Phrase) => void;
  onUpdatePhrases: (newPhrases: Phrase[]) => void;
}

const Library: React.FC<LibraryProps> = ({ phrases, activeId, onSelect, onUpdatePhrases }) => {
  const [activeTab, setActiveTab] = useState<'99NAMES' | 'CUSTOM'>('99NAMES');
  const [editingPhrase, setEditingPhrase] = useState<Phrase | null>(null);
  const [isAdding, setIsAdding] = useState(false);
  const [formData, setFormData] = useState({ arabic: '', transliteration: '', translation: '' });
  const [isSyncing, setIsSyncing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const filteredNames = useMemo(() => {
    return ALLAH_NAMES.filter(n => 
      n.transliteration.toLowerCase().includes(searchQuery.toLowerCase()) || 
      n.translation.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [searchQuery]);

  const filteredCustom = useMemo(() => {
    return phrases.filter(p => 
      p.transliteration.toLowerCase().includes(searchQuery.toLowerCase()) || 
      p.translation.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [phrases, searchQuery]);

  const handleDelete = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    if (window.confirm("CELESTIAL REMOVAL: Are you sure you want to remove this frequency from your ZIKR NAME list?")) {
      const updated = phrases.filter(p => p.id !== id);
      onUpdatePhrases(updated);
    }
  };

  const handleEdit = (e: React.MouseEvent, p: Phrase) => {
    e.stopPropagation();
    setEditingPhrase(p);
    setFormData({ arabic: p.arabic, transliteration: p.transliteration, translation: p.translation });
  };

  const closeModal = useCallback(() => {
    setEditingPhrase(null);
    setIsAdding(false);
    setFormData({ arabic: '', transliteration: '', translation: '' });
  }, []);

  const handleSave = useCallback(() => {
    if (!formData.arabic || !formData.transliteration) return;

    if (editingPhrase) {
      const updated = phrases.map(p => 
        p.id === editingPhrase.id ? { ...p, ...formData } : p
      );
      onUpdatePhrases(updated);
    } else if (isAdding) {
      const newPhrase: Phrase = {
        id: `custom-${Date.now()}`,
        ...formData
      };
      onUpdatePhrases([newPhrase, ...phrases]);
    }

    closeModal();
  }, [formData, editingPhrase, isAdding, phrases, onUpdatePhrases, closeModal]);

  const handleSync = async () => {
    setIsSyncing(true);
    await new Promise(resolve => setTimeout(resolve, 1500));
    setIsSyncing(false);
    alert("ZIKR NAME LIST SYNCHRONIZED: All spiritual frequencies aligned with the Permanent Ledger.");
  };

  return (
    <div className="flex-1 flex flex-col bg-[#022c22] font-inter overflow-hidden">
      <div className="flex-1 overflow-y-auto custom-scrollbar">
        {/* HEADER SECTION */}
        <div className="px-6 py-10 flex justify-between items-center shrink-0">
          <div>
            <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 bg-[#064e3b] rounded-xl flex items-center justify-center text-[#C5A059] border border-[#C5A059]/20 shadow-lg">
                    <BookOpen size={20} />
                </div>
                <h2 className="text-2xl font-black text-white tracking-tight uppercase leading-none">ZIKR NAME</h2>
            </div>
            <p className="text-emerald-600 text-[10px] font-bold uppercase tracking-widest">Ummah Spiritual Frequencies</p>
          </div>
          <button 
            onClick={handleSync}
            className="p-3 bg-emerald-900/40 rounded-xl text-emerald-500 border border-emerald-800 active:scale-90 transition-all group"
          >
            <RefreshCw size={20} className={isSyncing ? 'animate-spin' : 'group-hover:rotate-180 transition-transform duration-500'} />
          </button>
        </div>

        {/* SEARCH & TAB CONTROLS */}
        <div className="px-6 space-y-6 shrink-0">
          <div className="relative group">
            <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-emerald-900 group-focus-within:text-[#C5A059] transition-colors" size={20} />
            <input 
              type="text" 
              placeholder="Search frequencies..." 
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full bg-black/20 border border-emerald-900 rounded-[2.5rem] py-6 pl-16 pr-8 text-sm font-bold text-white outline-none focus:border-[#C5A059] transition-all placeholder:text-emerald-950 shadow-inner"
            />
          </div>

          <div className="flex gap-2 p-1.5 bg-[#053131] rounded-2xl border border-[#0A4242] shadow-inner mb-2">
            <button 
              onClick={() => setActiveTab('99NAMES')}
              className={`flex-1 py-4 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all flex items-center justify-center gap-2 ${activeTab === '99NAMES' ? 'bg-[#C5A059] text-[#021F1F] shadow-lg' : 'text-[#4D6B6B]'}`}
            >
              <Sparkles size={14} /> 99 Names of Allah
            </button>
            <button 
              onClick={() => setActiveTab('CUSTOM')}
              className={`flex-1 py-4 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all flex items-center justify-center gap-2 ${activeTab === 'CUSTOM' ? 'bg-[#C5A059] text-[#021F1F] shadow-lg' : 'text-[#4D6B6B]'}`}
            >
              <Plus size={14} /> Custom Frequencies
            </button>
          </div>
        </div>

        {/* CONTENT LIST */}
        <div className="px-6 pt-6 pb-40 space-y-4">
          {activeTab === 'CUSTOM' && (
            <button 
              onClick={() => setIsAdding(true)}
              className="w-full mb-4 bg-gradient-to-r from-emerald-900 to-emerald-950 border border-[#C5A059]/30 p-8 rounded-[2.5rem] flex items-center justify-center gap-4 group transition-all hover:bg-emerald-900 shadow-2xl active:scale-[0.98]"
            >
              <div className="w-12 h-12 bg-[#C5A059] text-emerald-950 rounded-2xl flex items-center justify-center shadow-[0_0_20px_rgba(197,160,89,0.3)] group-hover:scale-110 transition-transform">
                <Plus size={24} />
              </div>
              <div className="text-left">
                 <p className="text-xs font-black text-white uppercase tracking-widest">Add New Frequency</p>
                 <p className="text-[9px] text-[#C5A059] font-bold uppercase mt-1">Expansion of the Ledger</p>
              </div>
            </button>
          )}

          {(activeTab === '99NAMES' ? filteredNames : filteredCustom).map((p) => {
            const isActive = p.id === activeId;
            return (
              <div
                key={p.id}
                onClick={() => onSelect(p)}
                className={`w-full text-left p-8 rounded-[2.5rem] transition-all border relative overflow-hidden group cursor-pointer animate-in fade-in slide-in-from-bottom-2
                  ${isActive ? 'bg-emerald-900/60 border-[#C5A059] shadow-[0_0_30px_rgba(197,160,89,0.1)]' : 'bg-black/20 border-emerald-900/50 hover:bg-black/40 hover:border-emerald-800'}`}
              >
                <div className="flex justify-between items-start mb-4 relative z-10">
                  <span className={`arabic text-5xl transition-colors duration-500 ${isActive ? 'text-[#C5A059]' : 'text-emerald-700'}`}>{p.arabic}</span>
                  <div className="flex gap-2">
                     {activeTab === 'CUSTOM' && (
                       <>
                          <button 
                           onClick={(e) => handleEdit(e, p)}
                           className="p-3 bg-emerald-950/80 rounded-xl text-emerald-500 opacity-0 group-hover:opacity-100 transition-all border border-emerald-800 hover:text-white"
                          >
                            <Pencil size={16} />
                          </button>
                          <button 
                           onClick={(e) => handleDelete(e, p.id)}
                           className="p-3 bg-red-950/20 rounded-xl text-red-500 opacity-0 group-hover:opacity-100 transition-all border border-red-900/30 hover:bg-red-500 hover:text-white"
                          >
                            <Trash2 size={16} />
                          </button>
                       </>
                     )}
                     {isActive && <Check size={28} className="text-[#C5A059] ml-2" />}
                  </div>
                </div>
                <div className="relative z-10">
                  <h4 className={`text-xl font-black tracking-tighter uppercase ${isActive ? 'text-white' : 'text-emerald-600'}`}>{p.transliteration}</h4>
                  <p className={`text-xs font-bold mt-1 uppercase tracking-widest ${isActive ? 'text-[#C5A059]' : 'text-emerald-800'}`}>{p.translation}</p>
                </div>
                {isActive && (
                  <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-[#C5A059]/10 rounded-full blur-[60px] animate-pulse" />
                )}
              </div>
            );
          })}

          {(activeTab === '99NAMES' ? filteredNames : filteredCustom).length === 0 && (
            <div className="py-20 text-center opacity-30">
              <Search size={48} className="mx-auto mb-4" />
              <p className="text-[10px] font-black uppercase tracking-widest">No frequencies matched your search</p>
            </div>
          )}
        </div>
      </div>

      {/* Editor Modal */}
      {(isAdding || editingPhrase) && (
        <div className="fixed inset-0 z-[1000] flex items-center justify-center p-6 bg-emerald-950/90 backdrop-blur-2xl animate-in fade-in duration-300">
           <div className="bg-[#053131] w-full max-w-sm rounded-[3.5rem] border border-[#C5A059]/30 p-10 shadow-2xl relative overflow-hidden flex flex-col gap-8">
              <header className="flex justify-between items-center">
                 <h3 className="text-2xl font-black text-white uppercase tracking-tighter">
                   {isAdding ? 'New Frequency' : 'Modify Frequency'}
                 </h3>
                 <button onClick={closeModal} className="p-3 bg-black/20 text-[#C5A059] rounded-xl hover:text-white transition-colors"><X size={24} /></button>
              </header>

              <div className="space-y-6">
                 <div className="space-y-2">
                    <label className="text-[9px] font-black uppercase text-[#C5A059] tracking-widest ml-1">Arabic Text</label>
                    <input 
                      type="text" 
                      placeholder="e.g. سُبْحَانَ ٱللَّٰهِ" 
                      value={formData.arabic}
                      onChange={e => setFormData({...formData, arabic: e.target.value})}
                      className="w-full arabic bg-black/40 border border-emerald-800 rounded-2xl p-6 text-3xl text-white outline-none focus:border-[#C5A059] transition-all text-center placeholder:text-emerald-950"
                    />
                 </div>
                 <div className="space-y-2">
                    <label className="text-[9px] font-black uppercase text-[#C5A059] tracking-widest ml-1">Transliteration</label>
                    <input 
                      type="text" 
                      placeholder="e.g. SubhanAllah" 
                      value={formData.transliteration}
                      onChange={e => setFormData({...formData, transliteration: e.target.value})}
                      className="w-full bg-black/40 border border-emerald-800 rounded-2xl p-5 text-sm font-bold text-white outline-none focus:border-[#C5A059] transition-all"
                    />
                 </div>
                 <div className="space-y-2">
                    <label className="text-[9px] font-black uppercase text-[#C5A059] tracking-widest ml-1">Translation</label>
                    <input 
                      type="text" 
                      placeholder="e.g. Glory be to Allah" 
                      value={formData.translation}
                      onChange={e => setFormData({...formData, translation: e.target.value})}
                      className="w-full bg-black/40 border border-emerald-800 rounded-2xl p-5 text-xs font-medium text-emerald-100 outline-none focus:border-[#C5A059] transition-all"
                    />
                 </div>
              </div>

              <button 
                onClick={handleSave}
                className="w-full bg-[#C5A059] hover:bg-white text-emerald-950 font-black py-7 rounded-3xl shadow-xl active:scale-95 transition-all flex items-center justify-center gap-3 uppercase tracking-[0.3em] text-xs"
              >
                <Save size={18} /> ANCHOR TO ZIKR NAME LIST
              </button>
              
              <div className="absolute inset-0 celestial-grid opacity-5 pointer-events-none" />
           </div>
        </div>
      )}
    </div>
  );
};

export default Library;
