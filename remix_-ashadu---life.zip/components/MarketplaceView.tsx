import React, { useState, useEffect } from 'react';
import { ShoppingCart, ShoppingBag, Heart, Star, Sparkles, ChevronRight, X, Minus, Plus, CreditCard, ShieldCheck, PackagePlus, Tag, Info, Coins, Save } from 'lucide-react';
import { Product, CartItem, UserStats, SystemSettings } from '../types';
import { INITIAL_PRODUCTS } from '../constants';

interface MarketplaceViewProps {
  stats: UserStats;
  cart: CartItem[];
  onAddToCart: (p: Product) => void;
  onUpdateCartQuantity: (id: string, delta: number) => void;
  onCheckout: (useCredits: boolean) => void;
  systemSettings: SystemSettings;
}

const MarketplaceView: React.FC<MarketplaceViewProps> = ({ stats, cart, onAddToCart, onUpdateCartQuantity, onCheckout, systemSettings }) => {
  const [activeCategory, setActiveCategory] = useState('All');
  const [showCart, setShowCart] = useState(false);
  const [isAddingItem, setIsAddingItem] = useState(false);
  
  // Persist marketplace products locally to allow user-generated entries
  const [products, setProducts] = useState<Product[]>(() => {
    const saved = localStorage.getItem('ashadu_marketplace_products');
    return saved ? JSON.parse(saved) : INITIAL_PRODUCTS;
  });

  const [newItem, setNewItem] = useState({
    name: '',
    description: '',
    price: 0,
    category: '📿 Zikr Tools',
    icon: '📦',
    sadaqahPercent: 10
  });

  useEffect(() => {
    localStorage.setItem('ashadu_marketplace_products', JSON.stringify(products));
  }, [products]);

  const categories = ['All', ...Array.from(new Set(products.map(p => p.category)))];
  const filteredProducts = activeCategory === 'All' 
    ? products 
    : products.filter(p => p.category === activeCategory);

  const cartTotal = cart.reduce((acc, item) => acc + (item.price * item.quantity), 0);
  const creditDiscount = stats.educationCredits / 2;
  const finalPrice = Math.max(0, cartTotal - (stats.educationCredits > 0 ? creditDiscount : 0));
  
  const commissionPercent = systemSettings.revenue.marketplaceCommission;
  const estimatedSadaqah = cart.reduce((acc, item) => acc + (item.price * item.quantity * (item.sadaqahPercent / 100)), 0);
  const platformSupport = cartTotal * (commissionPercent / 100);

  const handleAddItem = () => {
    if (!newItem.name || newItem.price <= 0) {
      alert("Please provide a valid name and price.");
      return;
    }
    const product: Product = {
      ...newItem,
      id: `p-${Date.now()}`,
      isSme: true
    };
    setProducts([product, ...products]);
    setIsAddingItem(false);
    setNewItem({ name: '', description: '', price: 0, category: '📿 Zikr Tools', icon: '📦', sadaqahPercent: 10 });
  };

  return (
    <div className="flex-1 overflow-y-auto px-6 pb-40 bg-emerald-950 animate-in fade-in duration-700 font-inter">
      <div className="py-8 flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-black text-amber-500 tracking-tight">Pay Sadaqa</h2>
          <p className="text-[10px] text-emerald-400 uppercase tracking-[0.3em] mt-1">Ethical Barakah Marketplace</p>
        </div>
        <div className="flex gap-3">
          <button 
            onClick={() => setIsAddingItem(true)}
            className="w-14 h-14 bg-emerald-900/40 border border-emerald-800 rounded-2xl flex items-center justify-center text-amber-500 active:scale-95 transition-all shadow-lg"
            title="Add Item"
          >
            <PackagePlus size={24} />
          </button>
          <button 
            onClick={() => setShowCart(true)}
            className="relative w-14 h-14 bg-emerald-900 rounded-2xl flex items-center justify-center border border-emerald-800 text-amber-500 active:scale-95 transition-all shadow-lg"
          >
            <ShoppingCart size={24} />
            {cart.length > 0 && (
              <span className="absolute -top-2 -right-2 w-6 h-6 bg-amber-500 text-emerald-950 rounded-full flex items-center justify-center text-[10px] font-black animate-in zoom-in border-2 border-emerald-950">
                {cart.reduce((a, b) => a + b.quantity, 0)}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Category Scroller */}
      <div className="flex gap-4 overflow-x-auto pb-4 no-scrollbar mb-8 -mx-2 px-2">
        {categories.map(cat => (
          <button 
            key={cat}
            onClick={() => setActiveCategory(cat)}
            className={`px-6 py-3 rounded-full text-[10px] font-black uppercase tracking-widest whitespace-nowrap transition-all border
              ${activeCategory === cat ? 'bg-amber-500 border-amber-500 text-emerald-950 shadow-lg shadow-amber-500/20' : 'bg-emerald-900 border-emerald-800 text-emerald-500 hover:border-emerald-700'}`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Products Grid */}
      <div className="grid grid-cols-2 gap-6">
        {filteredProducts.map(product => (
          <div key={product.id} className="bg-emerald-900/30 rounded-[2.5rem] border border-emerald-800/50 p-4 flex flex-col group hover:border-amber-500/30 transition-all duration-500 shadow-xl">
            <div className="h-40 bg-emerald-800/40 rounded-3xl mb-4 flex items-center justify-center text-6xl group-hover:scale-110 transition-transform duration-700 relative overflow-hidden">
               {product.icon}
               {product.isSme && (
                 <div className="absolute top-3 left-3 bg-emerald-500 text-white text-[7px] font-black px-2 py-0.5 rounded-full uppercase tracking-widest flex items-center gap-1 shadow-sm">
                   <ShieldCheck size={8} /> Local SME
                 </div>
               )}
               <div className="absolute bottom-3 right-3 bg-black/40 backdrop-blur-md text-amber-500 text-[8px] font-black px-2 py-1 rounded-lg border border-white/5">
                 {product.sadaqahPercent}% Sadaqah
               </div>
            </div>
            
            <h4 className="text-white font-black text-sm tracking-tight mb-1 truncate">{product.name}</h4>
            <p className="text-[9px] text-emerald-500 font-bold uppercase tracking-widest mb-4 italic truncate opacity-70">
              {product.description}
            </p>
            
            <div className="mt-auto flex justify-between items-center">
               <span className="text-amber-500 font-black font-mono text-lg">£{product.price.toFixed(2)}</span>
               <button 
                onClick={() => onAddToCart(product)}
                className="w-10 h-10 bg-amber-500 hover:bg-amber-400 text-emerald-950 rounded-xl flex items-center justify-center transition-all active:scale-90 shadow-lg"
               >
                 <Plus size={20} />
               </button>
            </div>
          </div>
        ))}
      </div>

      {/* Add Item Modal */}
      {isAddingItem && (
        <div className="fixed inset-0 z-[300] flex items-center justify-center p-6 bg-emerald-950/95 backdrop-blur-2xl animate-in fade-in duration-300">
           <div className="bg-[#053131] w-full max-w-sm rounded-[3.5rem] border border-[#C5A059]/30 p-10 shadow-2xl relative overflow-hidden flex flex-col gap-6">
              <header className="flex justify-between items-center">
                 <div>
                    <h3 className="text-2xl font-black text-white uppercase tracking-tighter">Add Item</h3>
                    <p className="text-[8px] text-[#C5A059] font-black uppercase tracking-[0.3em] mt-1">SME Marketplace Entry</p>
                 </div>
                 <button onClick={() => setIsAddingItem(false)} className="p-3 bg-black/20 text-[#C5A059] rounded-xl hover:text-white transition-colors"><X size={24} /></button>
              </header>

              <div className="space-y-4 max-h-[60vh] overflow-y-auto pr-2 custom-scrollbar">
                 <div className="space-y-1.5">
                    <label className="text-[9px] font-black uppercase text-emerald-600 tracking-widest ml-1">Product Name</label>
                    <input 
                      type="text" 
                      placeholder="e.g. Premium Miswak" 
                      value={newItem.name}
                      onChange={e => setNewItem({...newItem, name: e.target.value})}
                      className="w-full bg-black/40 border border-emerald-800 rounded-2xl p-5 text-sm font-bold text-white outline-none focus:border-amber-500 transition-all shadow-inner"
                    />
                 </div>

                 <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                        <label className="text-[9px] font-black uppercase text-emerald-600 tracking-widest ml-1">Price (£)</label>
                        <input 
                            type="number" 
                            placeholder="0.00" 
                            value={newItem.price || ''}
                            onChange={e => setNewItem({...newItem, price: parseFloat(e.target.value) || 0})}
                            className="w-full bg-black/40 border border-emerald-800 rounded-2xl p-5 text-sm font-black text-white outline-none focus:border-amber-500 transition-all font-mono"
                        />
                    </div>
                    <div className="space-y-1.5">
                        <label className="text-[9px] font-black uppercase text-emerald-600 tracking-widest ml-1">Sadaqah %</label>
                        <input 
                            type="number" 
                            max="100"
                            value={newItem.sadaqahPercent}
                            onChange={e => setNewItem({...newItem, sadaqahPercent: Math.min(100, parseInt(e.target.value) || 0)})}
                            className="w-full bg-black/40 border border-emerald-800 rounded-2xl p-5 text-sm font-black text-white outline-none focus:border-amber-500 transition-all font-mono"
                        />
                    </div>
                 </div>

                 <div className="space-y-1.5">
                    <label className="text-[9px] font-black uppercase text-emerald-600 tracking-widest ml-1">Category</label>
                    <select 
                        value={newItem.category}
                        onChange={e => setNewItem({...newItem, category: e.target.value})}
                        className="w-full bg-black/40 border border-emerald-800 rounded-2xl p-5 text-xs font-black uppercase text-white outline-none focus:border-amber-500 transition-all appearance-none cursor-pointer"
                    >
                        <option>📿 Zikr Tools</option>
                        <option>🧴 Scents</option>
                        <option>📚 Knowledge</option>
                        <option>👕 Apparel</option>
                        <option>✨ Misc</option>
                    </select>
                 </div>

                 <div className="space-y-1.5">
                    <label className="text-[9px] font-black uppercase text-emerald-600 tracking-widest ml-1">Icon (Emoji)</label>
                    <input 
                        type="text" 
                        value={newItem.icon}
                        onChange={e => setNewItem({...newItem, icon: e.target.value})}
                        className="w-full bg-black/40 border border-emerald-800 rounded-2xl p-5 text-2xl text-center text-white outline-none focus:border-amber-500 transition-all"
                    />
                 </div>

                 <div className="space-y-1.5">
                    <label className="text-[9px] font-black uppercase text-emerald-600 tracking-widest ml-1">Brief Description</label>
                    <textarea 
                      placeholder="Share the Barakah story of this item..." 
                      value={newItem.description}
                      onChange={e => setNewItem({...newItem, description: e.target.value})}
                      className="w-full bg-black/40 border border-emerald-800 rounded-2xl p-5 text-xs text-white/70 outline-none focus:border-amber-500 h-24 resize-none shadow-inner"
                    />
                 </div>
              </div>

              <button 
                onClick={handleAddItem}
                className="w-full bg-amber-500 hover:bg-white text-emerald-950 font-black py-6 rounded-[2rem] shadow-xl active:scale-95 transition-all flex items-center justify-center gap-3 uppercase tracking-[0.3em] text-[10px] border-b-8 border-[#8c713b]"
              >
                <Save size={18} /> Publish to Market
              </button>
           </div>
        </div>
      )}

      {/* Cart Modal */}
      {showCart && (
        <div className="fixed inset-0 z-[400] flex flex-col justify-end bg-emerald-950/95 backdrop-blur-xl animate-in fade-in duration-300">
          <div className="bg-emerald-900 w-full max-h-[85vh] rounded-t-[3.5rem] p-8 shadow-2xl flex flex-col animate-in slide-in-from-bottom duration-500 border-t border-emerald-800">
             <div className="flex justify-between items-center mb-8">
               <h3 className="text-2xl font-black text-white flex items-center gap-3">
                 <ShoppingBag className="text-amber-500" /> Your Basket
               </h3>
               <button onClick={() => setShowCart(false)} className="text-emerald-500 p-2"><X size={24} /></button>
             </div>

             <div className="flex-1 overflow-y-auto space-y-6 mb-8 pr-2 custom-scrollbar">
               {cart.length === 0 ? (
                 <div className="py-20 text-center">
                    <ShoppingCart size={48} className="mx-auto text-emerald-800 mb-4 opacity-30" />
                    <p className="text-emerald-500 font-black uppercase tracking-widest text-[10px]">Your basket is empty</p>
                 </div>
               ) : (
                 cart.map(item => (
                   <div key={item.id} className="flex justify-between items-center bg-emerald-950/50 p-5 rounded-[2rem] border border-emerald-800 shadow-md">
                      <div className="flex items-center gap-4">
                        <div className="w-16 h-16 bg-emerald-900 rounded-2xl flex items-center justify-center text-3xl shadow-inner">{item.icon}</div>
                        <div>
                          <h4 className="text-white font-black text-sm">{item.name}</h4>
                          <p className="text-amber-500 font-mono font-black text-xs mt-1">£{item.price.toFixed(2)}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3 bg-emerald-900 rounded-xl p-1 border border-emerald-800">
                        <button onClick={() => onUpdateCartQuantity(item.id, -1)} className="p-2 text-emerald-500 hover:text-white"><Minus size={14} /></button>
                        <span className="text-white font-black font-mono text-sm w-4 text-center">{item.quantity}</span>
                        <button onClick={() => onUpdateCartQuantity(item.id, 1)} className="p-2 text-emerald-500 hover:text-white"><Plus size={14} /></button>
                      </div>
                   </div>
                 ))
               )}
             </div>

             {cart.length > 0 && (
               <div className="space-y-4 pt-6 border-t border-emerald-800">
                  <div className="p-4 bg-black/40 rounded-2xl border border-emerald-800/50 mb-4">
                    <p className="text-[9px] text-emerald-400 font-bold uppercase tracking-widest leading-relaxed flex items-center gap-2">
                      <Info size={12} className="text-amber-500" />
                      Transparency: {commissionPercent}% of this transaction (£{platformSupport.toFixed(2)}) supports ASHADU server costs & Islamic Relief.
                    </p>
                  </div>

                  {stats.educationCredits > 0 && (
                    <div className="bg-emerald-800/30 p-4 rounded-2xl border border-dashed border-amber-500/30 flex justify-between items-center">
                       <div className="flex items-center gap-2">
                          <Sparkles size={14} className="text-amber-500" />
                          <span className="text-[9px] font-black text-amber-500 uppercase tracking-widest">Barakah Credit Applied</span>
                       </div>
                       <span className="text-xs font-black text-amber-500">-£{creditDiscount.toFixed(2)}</span>
                    </div>
                  )}

                  <div className="flex justify-between items-center px-2">
                     <span className="text-emerald-500 text-[10px] font-black uppercase tracking-widest">Subtotal</span>
                     <span className="text-white font-black font-mono text-xl">£{cartTotal.toFixed(2)}</span>
                  </div>

                  <div className="flex justify-between items-center px-2 py-3 bg-emerald-950 rounded-2xl mb-4 border border-emerald-900 shadow-inner">
                     <div className="flex items-center gap-2">
                        <Heart size={14} className="text-emerald-500 fill-emerald-500" />
                        <span className="text-[10px] font-black text-emerald-500 uppercase tracking-widest">Estimated Sadaqah</span>
                     </div>
                     <span className="text-xs font-black text-emerald-400">£{estimatedSadaqah.toFixed(2)}</span>
                  </div>

                  <button 
                    onClick={() => onCheckout(stats.educationCredits > 0)}
                    className="w-full bg-amber-500 hover:bg-amber-400 text-emerald-950 font-black py-6 rounded-[2.5rem] shadow-xl shadow-amber-500/20 flex items-center justify-center gap-3 uppercase tracking-widest text-[10px] transition-all active:scale-95 border-b-4 border-[#8c713b]"
                  >
                    <CreditCard size={20} /> Checkout • £{finalPrice.toFixed(2)}
                  </button>
               </div>
             )}
          </div>
        </div>
      )}

      {/* Legacy Notice */}
      <div className="mt-16 text-center">
         <ShieldCheck size={24} className="text-emerald-800 mx-auto mb-4" />
         <p className="text-[9px] text-emerald-700 font-black uppercase tracking-[0.4em]">Barakah Verified Merchants • {commissionPercent}% Charity Guarantee</p>
      </div>
    </div>
  );
};

export default MarketplaceView;
