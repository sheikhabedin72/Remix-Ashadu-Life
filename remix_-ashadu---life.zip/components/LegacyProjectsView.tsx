import React, { useState, useCallback } from 'react';
import { 
  Target, 
  Sparkles, 
  TrendingUp, 
  Droplets, 
  BookOpen, 
  Trees, 
  Landmark, 
  ChevronRight, 
  Zap, 
  Plus, 
  Pencil, 
  Trash2, 
  X, 
  Save, 
  RefreshCw,
  Utensils,
  Snowflake,
  Baby,
  AlertTriangle,
  HeartHandshake,
  Stethoscope,
  Home,
  HandHeart,
  Wallet,
  CheckCircle2,
  Share2,
  Gift,
  Coins,
  ArrowUpRight
} from 'lucide-react';
import { LegacyProject, UserStats } from '../types';

interface LegacyProjectsViewProps {
  stats: UserStats;
  projects: LegacyProject[];
  onUpdateProjects: (projects: LegacyProject[]) => void;
  onAllocateCredits: (project: LegacyProject) => void;
  onGrantCredits?: (amount: number) => void;
}

const LegacyProjectsView: React.FC<LegacyProjectsViewProps> = ({ 
  stats, 
  projects, 
  onUpdateProjects, 
  onAllocateCredits,
  onGrantCredits 
}) => {
  const [isAdding, setIsAdding] = useState(false);
  const [editingProject, setEditingProject] = useState<LegacyProject | null>(null);
  const [isSyncing, setIsSyncing] = useState(false);
  
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    category: 'Water' as LegacyProject['category'],
    target: 0,
    icon: '💧'
  });

  const availableCredits = stats.educationCredits || 0;
  const totalUserContribution = stats.totalProjectDonations || 0;

  const handleDelete = (e: React.MouseEvent, id: string) => {
    e.preventDefault();
    e.stopPropagation();
    if (window.confirm("PERMANENT REMOVAL: This will wipe this mission from your local ledger. History will remain in the Permanent Cloud Archive.")) {
      const updatedList = projects.filter(p => p.id !== id);
      onUpdateProjects(updatedList);
    }
  };

  const handleEdit = (e: React.MouseEvent, p: LegacyProject) => {
    e.preventDefault();
    e.stopPropagation();
    setEditingProject(p);
    setFormData({
      name: p.name,
      description: p.description,
      category: p.category,
      target: p.target,
      icon: p.icon
    });
  };

  const handleShare = async (e: React.MouseEvent, project: LegacyProject) => {
    e.preventDefault();
    e.stopPropagation();
    const shareText = `Join my legacy mission on ASHADU: "${project.name}". We've raised £${project.raised.toLocaleString()} for ${project.category}. Fulfill your Amanah today!`;
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'ASHADU Legacy Mission',
          text: shareText,
          url: window.location.href,
        });
      } catch (err) {
        console.log('Share canceled');
      }
    } else {
      navigator.clipboard.writeText(shareText);
      alert("Mission link copied to clipboard!");
    }
  };

  const handleDonateDirect = (project: LegacyProject) => {
    const amountStr = prompt(`Recording External Donation for: ${project.name}\nThis adds to the mission ledger without using your Sabr Credits.\nEnter amount (£):`, "10.00");
    const amount = parseFloat(amountStr || "0");
    if (isNaN(amount) || amount <= 0) return;

    const updatedProjects = projects.map(p => 
      p.id === project.id ? { ...p, raised: p.raised + amount } : p
    );
    onUpdateProjects(updatedProjects);
    alert(`Barakah Recorded: £${amount.toFixed(2)} added to ${project.name} ledger.`);
  };

  const closeModal = useCallback(() => {
    setIsAdding(false);
    setEditingProject(null);
    setFormData({ name: '', description: '', category: 'Water', target: 0, icon: '💧' });
  }, []);

  const handleSave = useCallback(() => {
    if (!formData.name || !formData.target) {
        alert("Verification Failed: Mission name and target goal are required for ledger entry.");
        return;
    }

    const categoryIcons: Record<LegacyProject['category'], string> = {
      'Water': '💧',
      'Nature': '🌿',
      'Education': '📚',
      'Masjid': '🕌',
      'Food Pack': '🍱',
      'Winter Pack': '❄️',
      'Orphanage': '👶',
      'Disaster Appeal': '🆘',
      'Sponsorship': '🤝',
      'Medical': '🏥',
      'Build a Shelter': '🏠',
      'Sadaqa': '💖'
    };

    const finalData = {
      ...formData,
      icon: categoryIcons[formData.category] || '✨',
      lastUpdated: new Date().toISOString()
    };

    if (editingProject) {
      onUpdateProjects(projects.map(p => p.id === editingProject.id ? { ...p, ...finalData } : p));
    } else {
      const newProject: LegacyProject = {
        id: `project-${Date.now()}`,
        ...finalData,
        raised: 0
      };
      onUpdateProjects([newProject, ...projects]);
    }
    closeModal();
  }, [formData, editingProject, projects, onUpdateProjects, closeModal]);

  const handleSyncAll = async () => {
    setIsSyncing(true);
    await new Promise(resolve => setTimeout(resolve, 1500));
    setIsSyncing(false);
    alert("GLOBAL SYNCHRONIZATION COMPLETE: Your mission updates have been anchored to the Ashadu Permanent Cloud Ledger.");
  };

  return (
    <div className="flex-1 flex flex-col bg-emerald-950 font-inter relative overflow-hidden">
      <div className="flex-1 overflow-y-auto px-6 pb-40 animate-in fade-in duration-700 no-scrollbar">
        <div className="py-8 mb-4">
          <h2 className="text-3xl font-black text-amber-500 tracking-tight">Legacy Missions</h2>
          <p className="text-[10px] text-emerald-400 uppercase tracking-[0.3em] mt-1">Impact Jariyah Ledger</p>
        </div>

        {/* User Balance & Add Action */}
        <div className="grid grid-cols-2 gap-4 mb-8">
            <div className="bg-emerald-900/60 p-5 rounded-[2.5rem] border border-amber-500/40 shadow-xl flex flex-col justify-between relative overflow-hidden group">
               <div className="relative z-10">
                  <p className="text-[8px] font-black text-emerald-500 uppercase tracking-widest mb-1 flex items-center gap-1.5">
                     <Wallet size={10}/> SABR Wallet
                  </p>
                  <h4 className="text-2xl font-black text-white font-mono leading-none">£{availableCredits.toFixed(2)}</h4>
               </div>
               
               <button 
                onClick={() => onGrantCredits?.(10.00)}
                className="mt-3 w-full bg-amber-500 hover:bg-white text-emerald-950 py-3 rounded-2xl text-[8px] font-black uppercase tracking-widest transition-all flex items-center justify-center gap-1.5 shadow-lg active:scale-95 z-10"
               >
                 <Sparkles size={12} className="animate-pulse" /> Claim Divine Grant (£10)
               </button>
               
               <div className="absolute -bottom-4 -right-4 opacity-5 group-hover:scale-125 transition-transform">
                  <Wallet size={80} className="text-white" />
               </div>
            </div>
            
            <button 
              onClick={() => setIsAdding(true)}
              className="bg-amber-500 hover:bg-white text-emerald-950 p-6 rounded-[2.5rem] flex flex-col items-center justify-center gap-2 group transition-all shadow-2xl active:scale-95 border-b-4 border-[#8c713b]"
            >
              <Plus size={24} className="group-hover:scale-125 transition-transform" />
              <span className="text-[9px] font-black uppercase tracking-widest">New Mission</span>
            </button>
        </div>

        {/* Global Impact Summary */}
        <div className="p-8 bg-gradient-to-br from-emerald-900 to-emerald-950 rounded-[3rem] border border-amber-500/30 mb-10 shadow-2xl relative overflow-hidden group">
          <div className="relative z-10">
            <p className="text-[10px] font-black text-emerald-500 uppercase tracking-widest mb-1">Total Legacy Contribution</p>
            <h3 className="text-4xl font-black text-white font-mono">£{totalUserContribution.toFixed(2)}</h3>
            <div className="mt-6 flex items-center gap-3 bg-white/5 p-4 rounded-2xl border border-white/5">
               <Zap size={16} className="text-amber-500" />
               <p className="text-[9px] text-emerald-300 font-bold uppercase tracking-widest leading-relaxed">
                 Collective effort builds ongoing mercy for the Ummah.
               </p>
            </div>
          </div>
          <Sparkles size={140} className="absolute -bottom-8 -right-8 text-emerald-800 opacity-20 group-hover:scale-125 transition-transform duration-1000" />
        </div>

        {/* Active Missions List */}
        <div className="space-y-8">
          <div className="flex justify-between items-center px-2">
            <h3 className="text-[10px] font-black uppercase text-emerald-600 tracking-[0.4em]">Active Missions</h3>
            <span className="text-[8px] font-black text-amber-500/40 uppercase tracking-widest">Verified Alms Hub</span>
          </div>
          
          {projects.length === 0 ? (
            <div className="py-20 text-center border-2 border-dashed border-emerald-900 rounded-[3rem]">
               <p className="text-xs text-emerald-800 font-black uppercase tracking-widest">No active missions initialized</p>
            </div>
          ) : (
            projects.map((project) => {
              const progress = (project.raised / project.target) * 100;
              const canAllocate = availableCredits > 0;
              
              return (
                <div key={project.id} className="bg-emerald-900/40 rounded-[3rem] border border-amber-500/10 overflow-hidden group transition-all hover:border-amber-500/30 relative">
                   {/* Card Visual Header */}
                   <div className="h-40 bg-emerald-800/50 flex items-center justify-center relative overflow-hidden">
                      <span className="text-7xl transition-transform group-hover:scale-110 duration-700 select-none">{project.icon}</span>
                      
                      {/* Authority Controls Overlay */}
                      <div className="absolute top-6 right-6 flex gap-2 z-20">
                          <button 
                            onClick={(e) => handleShare(e, project)}
                            className="p-3 bg-emerald-950/80 rounded-xl text-cyan-400 border border-cyan-500/20 hover:bg-cyan-500 hover:text-emerald-950 transition-all active:scale-90"
                            title="Share Mission"
                          >
                            <Share2 size={14} />
                          </button>
                          <button 
                            onClick={(e) => handleEdit(e, project)}
                            className="p-3 bg-emerald-950/80 rounded-xl text-amber-500 border border-amber-500/20 hover:bg-amber-500 hover:text-emerald-950 transition-all active:scale-90"
                            title="Edit Mission"
                          >
                            <Pencil size={14} />
                          </button>
                          <button 
                            onClick={(e) => handleDelete(e, project.id)}
                            className="p-3 bg-red-950/40 rounded-xl text-red-500 border border-red-500/40 hover:bg-red-500 hover:text-white transition-all active:scale-90"
                            title="Delete Mission"
                          >
                            <Trash2 size={14} />
                          </button>
                      </div>

                      {project.isUrgent && (
                        <div className="absolute top-6 left-6 bg-red-500 text-white text-[9px] font-black px-4 py-1.5 rounded-full uppercase tracking-widest animate-pulse shadow-lg">
                            Urgent Appeal
                        </div>
                      )}
                      <div className="absolute inset-0 bg-gradient-to-t from-emerald-950/80 to-transparent" />
                   </div>

                   <div className="p-8">
                      <div className="flex justify-between items-start mb-2">
                         <h4 className="text-xl font-black text-white tracking-tight">{project.name}</h4>
                         <div className="p-2 bg-emerald-950 rounded-lg"><CategoryIcon category={project.category} /></div>
                      </div>
                      <p className="text-xs text-emerald-400 font-medium italic mb-6 leading-relaxed">
                        {project.description || `Ongoing jariyah mission in the ${project.category} sector.`}
                      </p>

                      <div className="space-y-2 mb-8">
                         <div className="w-full bg-emerald-950 h-4 rounded-full overflow-hidden border border-emerald-900 shadow-inner">
                            <div 
                              className="bg-amber-500 h-full shadow-[0_0_15px_rgba(245,158,11,0.5)] transition-all duration-1000"
                              style={{ width: `${Math.min(100, progress)}%` }} 
                            />
                         </div>
                         <div className="flex justify-between items-center px-1">
                            <span className="text-[10px] font-black text-emerald-500 uppercase tracking-widest">£{project.raised.toLocaleString()} RAISED</span>
                            <span className="text-[10px] font-black text-amber-500 uppercase tracking-widest">{progress.toFixed(0)}% FUNDED</span>
                         </div>
                      </div>

                      <div className="flex flex-col gap-3">
                         <button 
                           onClick={() => onAllocateCredits(project)}
                           disabled={!canAllocate}
                           className={`w-full py-5 rounded-[2.5rem] text-[10px] font-black uppercase tracking-widest transition-all flex items-center justify-center gap-2 active:scale-95 border-b-4 
                             ${canAllocate 
                               ? 'bg-emerald-800 hover:bg-emerald-700 border-emerald-600 text-white shadow-xl shadow-emerald-500/10' 
                               : 'bg-emerald-900/40 text-emerald-800 border-emerald-950 opacity-40 cursor-not-allowed'}`}
                         >
                           {canAllocate ? (
                               <><CheckCircle2 size={14} /> Allocate £{availableCredits.toFixed(2)} Sabr Balance</>
                           ) : (
                               <><Gift size={14} className="opacity-40" /> Insufficient Sabr Balance</>
                           )}
                         </button>

                         <button 
                           onClick={() => handleDonateDirect(project)}
                           className="w-full py-4 rounded-[2rem] bg-emerald-950/60 border border-emerald-800 text-amber-500 text-[9px] font-black uppercase tracking-widest hover:bg-emerald-900 transition-all flex items-center justify-center gap-2"
                         >
                           <Coins size={14} /> Direct Donation to Ledger
                         </button>
                      </div>
                   </div>
                </div>
              );
            })
          )}
        </div>

        <div className="mt-20 text-center pb-12">
           <Landmark size={24} className="text-emerald-800 mx-auto mb-4" />
           <p className="text-[9px] text-emerald-700 font-black uppercase tracking-[0.4em]">Ashadu Legacy Protocol • Verified Charitable Engine</p>
        </div>
      </div>

      {/* Global Sync Anchor Button */}
      <div className="absolute bottom-24 left-0 w-full px-6 z-[100] pb-6 bg-gradient-to-t from-emerald-950 via-emerald-950/90 to-transparent pt-12">
          <button 
            onClick={handleSyncAll}
            className="w-full bg-[#C5A059] hover:bg-white text-emerald-950 font-black py-7 rounded-[2.5rem] shadow-[0_20px_50px_rgba(0,0,0,0.4)] flex items-center justify-center gap-4 transition-all active:scale-95 uppercase tracking-[0.3em] text-[11px] border-b-4 border-[#8c713b] group"
          >
            <RefreshCw size={22} className={isSyncing ? 'animate-spin' : 'group-hover:rotate-180 transition-transform duration-700'} /> 
            {isSyncing ? 'SYNCING GLOBAL LEDGER...' : 'Update & Sync All Missions'}
          </button>
      </div>

      {/* Authority Control Modal (Add/Edit) */}
      {(isAdding || editingProject) && (
        <div className="fixed inset-0 z-[500] flex items-center justify-center p-6 bg-emerald-950/95 backdrop-blur-2xl animate-in fade-in duration-300">
           <div className="bg-[#053131] w-full max-w-sm rounded-[3.5rem] border border-amber-500/30 p-10 shadow-2xl relative overflow-hidden flex flex-col gap-8 animate-in zoom-in-95">
              <header className="flex justify-between items-center">
                 <h3 className="text-2xl font-black text-white uppercase tracking-tighter">
                   {isAdding ? 'New Mission' : 'Modify Mission'}
                 </h3>
                 <button onClick={closeModal} className="p-3 bg-black/20 text-amber-500 rounded-xl hover:text-white transition-colors"><X size={24} /></button>
              </header>

              <div className="space-y-5">
                 <div className="space-y-2">
                    <label className="text-[9px] font-black uppercase text-amber-500 tracking-widest ml-1">Mission Identifier</label>
                    <input 
                      type="text" 
                      placeholder="e.g. Gaza Winter Pack #12" 
                      value={formData.name}
                      onChange={e => setFormData({...formData, name: e.target.value})}
                      className="w-full bg-black/40 border border-emerald-800 rounded-2xl p-5 text-sm font-bold text-white outline-none focus:border-amber-500 transition-all"
                    />
                 </div>
                 <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                        <label className="text-[9px] font-black uppercase text-amber-500 tracking-widest ml-1">Target Goal (£)</label>
                        <input 
                            type="number" 
                            placeholder="5000" 
                            value={formData.target || ''}
                            onChange={e => setFormData({...formData, target: parseInt(e.target.value) || 0})}
                            className="w-full bg-black/40 border border-emerald-800 rounded-2xl p-5 text-sm font-bold text-white outline-none focus:border-amber-500 transition-all"
                        />
                    </div>
                    <div className="space-y-2">
                        <label className="text-[9px] font-black uppercase text-amber-500 tracking-widest ml-1">Category</label>
                        <select 
                            value={formData.category}
                            onChange={e => setFormData({...formData, category: e.target.value as LegacyProject['category']})}
                            className="w-full bg-black/40 border border-emerald-800 rounded-2xl p-5 text-[10px] font-black uppercase text-white outline-none focus:border-amber-500 transition-all appearance-none"
                        >
                            <option value="Water">Water Wells</option>
                            <option value="Food Pack">Food Packs</option>
                            <option value="Winter Pack">Winter Packs</option>
                            <option value="Orphanage">Orphanages</option>
                            <option value="Disaster Appeal">Disaster Relief</option>
                            <option value="Sponsorship">Sponsorship</option>
                            <option value="Medical">Medical Care</option>
                            <option value="Build a Shelter">Shelter Construction</option>
                            <option value="Sadaqa">Sadaqa Jariyah</option>
                            <option value="Education">Legacy Schools</option>
                            <option value="Nature">Nature/Trees</option>
                            <option value="Masjid">Masjid Hubs</option>
                        </select>
                    </div>
                 </div>
                 <div className="space-y-2">
                    <label className="text-[9px] font-black uppercase text-amber-500 tracking-widest ml-1">Mission Context</label>
                    <textarea 
                      placeholder="Briefly describe the eternal impact of this mission..." 
                      value={formData.description}
                      onChange={e => setFormData({...formData, description: e.target.value})}
                      className="w-full bg-black/40 border border-emerald-800 rounded-2xl p-5 text-xs text-white outline-none focus:border-amber-500 h-24 resize-none"
                    />
                 </div>
              </div>

              <button 
                onClick={handleSave}
                className="w-full bg-amber-500 hover:bg-white text-emerald-950 font-black py-7 rounded-3xl shadow-xl active:scale-95 transition-all flex items-center justify-center gap-3 uppercase tracking-[0.3em] text-xs border-b-4 border-[#8c713b]"
              >
                <Save size={18} /> Anchor to Ledger
              </button>
           </div>
        </div>
      )}
    </div>
  );
};

const CategoryIcon = ({ category }: { category: LegacyProject['category'] }) => {
  switch (category) {
    case 'Water': return <Droplets size={16} className="text-blue-400" />;
    case 'Education': return <BookOpen size={16} className="text-amber-400" />;
    case 'Nature': return <Trees size={16} className="text-emerald-400" />;
    case 'Masjid': return <Landmark size={16} className="text-stone-400" />;
    case 'Food Pack': return <Utensils size={16} className="text-orange-400" />;
    case 'Winter Pack': return <Snowflake size={16} className="text-cyan-300" />;
    case 'Orphanage': return <Baby size={16} className="text-pink-400" />;
    case 'Disaster Appeal': return <AlertTriangle size={16} className="text-red-500" />;
    case 'Sponsorship': return <HeartHandshake size={16} className="text-yellow-400" />;
    case 'Medical': return <Stethoscope size={16} className="text-red-400" />;
    case 'Build a Shelter': return <Home size={16} className="text-amber-700" />;
    case 'Sadaqa': return <HandHeart size={16} className="text-emerald-400" />;
    default: return <Sparkles size={16} className="text-white" />;
  }
};

export default LegacyProjectsView;