import React, { useState } from 'react';
import { 
  Shield, 
  Trash2, 
  Lock, 
  Bell, 
  ChevronRight, 
  LayoutDashboard, 
  User, 
  ShieldAlert,
  LogOut
} from 'lucide-react';
import { UserProfile, View } from '../types';

interface SettingsViewProps {
  user: UserProfile | null;
  onNavigate: (view: View) => void;
  onLogout: () => void;
}

const SettingsView: React.FC<SettingsViewProps> = ({ user, onNavigate, onLogout }) => {
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  const handleDeleteData = () => {
    alert("In a real app, this would trigger a Supabase function to delete your user_data records. For now, this is a placeholder.");
    setShowDeleteConfirm(false);
  };

  return (
    <div className="h-full bg-emerald-950 flex flex-col font-inter overflow-hidden relative animate-in fade-in duration-700">
      <div className="absolute inset-0 celestial-grid opacity-10 pointer-events-none" />
      
      {/* Top Navigation Bar */}
      <div className="px-6 py-4 flex items-center justify-between bg-emerald-900/20 border-b border-emerald-800/50 backdrop-blur-md z-20">
        <div className="flex items-center gap-2">
          <Lock size={18} className="text-[#C5A059]" />
          <span className="text-[10px] font-black uppercase tracking-widest text-white">Account Management</span>
        </div>
        <div className="flex items-center gap-4">
          <button onClick={() => onNavigate('dashboard')} className="text-[9px] font-black uppercase tracking-widest text-emerald-500 hover:text-white transition-colors">Dashboard</button>
          <button onClick={() => onNavigate('settings')} className="text-[9px] font-black uppercase tracking-widest text-[#C5A059]">Settings</button>
          <button onClick={() => onNavigate('privacy')} className="text-[9px] font-black uppercase tracking-widest text-emerald-500 hover:text-white transition-colors">Privacy</button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-6 py-10 pb-40 space-y-10 relative z-10 custom-scrollbar">
        
        <header className="space-y-2">
          <h1 className="text-4xl font-black text-white tracking-tighter uppercase">Settings</h1>
          <p className="text-[10px] text-emerald-500 font-black uppercase tracking-[0.4em]">Manage your digital Amanah & Privacy</p>
        </header>

        <div className="space-y-6">
          {/* Account Section */}
          <section className="space-y-4">
            <h3 className="text-[10px] font-black text-[#C5A059] uppercase tracking-widest px-2">Account Protocols</h3>
            <div className="bg-emerald-900/30 border border-emerald-800 rounded-[2.5rem] overflow-hidden">
              <SettingItem 
                icon={<User size={20} />} 
                label="Profile Configuration" 
                sub="Update your name, bio, and website"
                onClick={() => onNavigate('profile')}
              />
              <SettingItem 
                icon={<Bell size={20} />} 
                label="Notification Preferences" 
                sub="Control spiritual alerts and reminders"
                toggle
              />
              <SettingItem 
                icon={<Shield size={20} />} 
                label="Two-Factor Authentication" 
                sub="Enhanced security for your soul's data"
                toggle
                last
              />
            </div>
          </section>

          {/* Danger Zone */}
          <section className="space-y-4">
            <h3 className="text-[10px] font-black text-rose-500 uppercase tracking-widest px-2">Danger Zone</h3>
            <div className="bg-rose-500/5 border border-rose-500/20 rounded-[2.5rem] overflow-hidden">
              <div 
                onClick={() => setShowDeleteConfirm(true)}
                className="p-8 flex items-center justify-between group cursor-pointer hover:bg-rose-500/10 transition-all"
              >
                <div className="flex items-center gap-6">
                  <div className="p-4 bg-rose-500/20 rounded-2xl text-rose-500 group-hover:scale-110 transition-transform">
                    <Trash2 size={24} />
                  </div>
                  <div>
                    <h4 className="font-black text-white text-sm uppercase tracking-tight">Delete Account Data</h4>
                    <p className="text-[10px] text-rose-500/70 font-black uppercase tracking-widest mt-1">Permanently erase your user_data records</p>
                  </div>
                </div>
                <ChevronRight size={20} className="text-rose-500/30 group-hover:text-rose-500 transition-colors" />
              </div>
              
              <div 
                onClick={onLogout}
                className="p-8 flex items-center justify-between group cursor-pointer hover:bg-emerald-900/20 border-t border-rose-500/10"
              >
                <div className="flex items-center gap-6">
                  <div className="p-4 bg-emerald-800 rounded-2xl text-[#C5A059] group-hover:scale-110 transition-transform">
                    <LogOut size={24} />
                  </div>
                  <div>
                    <h4 className="font-black text-white text-sm uppercase tracking-tight">Terminate Session</h4>
                    <p className="text-[10px] text-emerald-500/70 font-black uppercase tracking-widest mt-1">Securely logout from this device</p>
                  </div>
                </div>
                <ChevronRight size={20} className="text-emerald-500/30 group-hover:text-emerald-500 transition-colors" />
              </div>
            </div>
          </section>
        </div>

        {/* Delete Confirmation Modal */}
        {showDeleteConfirm && (
          <div className="fixed inset-0 z-[1000] bg-black/90 backdrop-blur-xl flex items-center justify-center p-6 animate-in fade-in duration-300">
            <div className="w-full max-w-md bg-emerald-950 border border-rose-500/50 rounded-[3rem] p-10 shadow-[0_0_50px_rgba(244,63,94,0.2)] relative overflow-hidden">
              <div className="flex flex-col items-center text-center space-y-6">
                <div className="p-6 bg-rose-500/20 rounded-full text-rose-500 animate-pulse">
                  <ShieldAlert size={48} />
                </div>
                <h3 className="text-white text-2xl font-black uppercase tracking-tighter">Irreversible Action</h3>
                <p className="text-stone-400 text-sm leading-relaxed">
                  Are you absolutely certain you want to delete your spiritual data? This will permanently remove all records from the <span className="text-rose-500 font-mono">user_data</span> table. This action cannot be undone.
                </p>
                <div className="flex flex-col w-full gap-3 pt-4">
                  <button 
                    onClick={handleDeleteData}
                    className="w-full py-4 bg-rose-500 text-white font-black rounded-2xl uppercase tracking-widest text-[10px] hover:bg-rose-600 transition-all active:scale-95 shadow-lg shadow-rose-500/20"
                  >
                    Confirm Deletion
                  </button>
                  <button 
                    onClick={() => setShowDeleteConfirm(false)}
                    className="w-full py-4 bg-emerald-900 text-white font-black rounded-2xl uppercase tracking-widest text-[10px] hover:bg-emerald-800 transition-all"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

interface SettingItemProps {
  icon: React.ReactNode;
  label: string;
  sub: string;
  onClick?: () => void;
  toggle?: boolean;
  last?: boolean;
}

const SettingItem: React.FC<SettingItemProps> = ({ icon, label, sub, onClick, toggle, last }) => {
  const [isActive, setIsActive] = useState(false);

  return (
    <div 
      onClick={onClick || (toggle ? () => setIsActive(!isActive) : undefined)}
      className={`p-8 flex items-center justify-between group cursor-pointer hover:bg-emerald-900/40 transition-all ${!last ? 'border-b border-emerald-800/50' : ''}`}
    >
      <div className="flex items-center gap-6">
        <div className="p-4 bg-emerald-800 rounded-2xl text-[#C5A059] group-hover:scale-110 transition-transform">
          {icon}
        </div>
        <div>
          <h4 className="font-black text-white text-sm uppercase tracking-tight">{label}</h4>
          <p className="text-[10px] text-emerald-500/70 font-black uppercase tracking-widest mt-1">{sub}</p>
        </div>
      </div>
      {toggle ? (
        <div className={`w-12 h-6 rounded-full p-1 transition-colors ${isActive ? 'bg-emerald-500' : 'bg-emerald-900'}`}>
          <div className={`w-4 h-4 bg-white rounded-full transition-transform ${isActive ? 'translate-x-6' : 'translate-x-0'}`} />
        </div>
      ) : (
        <ChevronRight size={20} className="text-emerald-500/30 group-hover:text-[#C5A059] transition-colors" />
      )}
    </div>
  );
};

export default SettingsView;
