import React, { useState, useEffect } from 'react';
import { Phrase } from '../types';
import { getSpiritualInsight } from '../services/geminiService';
import { Sparkles, Loader2, Heart, BookOpen, Quote, ChevronRight } from 'lucide-react';

const InsightView: React.FC<{ phrase: Phrase }> = ({ phrase }) => {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchInsight = async () => {
      const res = await getSpiritualInsight(phrase.transliteration);
      setData(res);
      setLoading(false);
    };
    fetchInsight();
  }, [phrase]);

  if (loading) {
    return (
      <div className="h-full flex flex-col items-center justify-center p-12 text-center bg-[#022c22]">
        <div className="relative mb-8">
          <Loader2 size={64} className="text-[#C5A059] animate-spin opacity-40" />
          <div className="absolute inset-0 flex items-center justify-center">
            <Sparkles size={24} className="text-[#C5A059] animate-pulse" />
          </div>
        </div>
        <h3 className="font-black text-2xl text-white tracking-tighter uppercase">Seeking Wisdom...</h3>
        <p className="text-emerald-600 mt-2 text-[10px] font-black uppercase tracking-widest">Consulting the emerald core</p>
      </div>
    );
  }

  if (!data) return <div className="p-12 text-center text-emerald-800 bg-[#022c22] h-full flex items-center justify-center uppercase font-black tracking-widest text-xs">Wisdom Offline. Retry.</div>;

  return (
    <div className="flex-1 overflow-y-auto px-6 pb-40 animate-in fade-in slide-in-from-right-10 duration-700 bg-[#022c22] font-inter">
      <div className="py-12 text-center">
        <span className="text-[10px] font-black text-[#C5A059] uppercase tracking-[0.4em] mb-4 block">Celestial Reflection</span>
        <h2 className="text-4xl font-black text-white tracking-tighter mb-2 uppercase">{data.title}</h2>
        <div className="h-1 w-16 bg-[#C5A059]/20 mx-auto rounded-full mt-4" />
      </div>

      <div className="space-y-6">
        <div className="bg-[#064e3b]/40 border border-[#C5A059]/20 p-10 rounded-[3rem] shadow-2xl relative overflow-hidden group">
            <div className="flex items-center gap-3 mb-6 text-[#C5A059]">
                <BookOpen size={20} />
                <h4 className="font-black uppercase tracking-widest text-[10px]">The Essence</h4>
            </div>
            <p className="text-emerald-100 leading-relaxed text-lg font-medium tracking-tight relative z-10">{data.meaning}</p>
            <Sparkles size={120} className="absolute -bottom-8 -right-8 text-[#C5A059] opacity-10 group-hover:scale-125 transition-transform duration-[2000ms]" />
        </div>
        
        <div className="p-10 bg-black/30 border border-emerald-900 rounded-[3rem] relative overflow-hidden group">
          <Quote size={64} className="absolute -top-4 -left-4 text-[#C5A059] opacity-10 rotate-12 transition-transform group-hover:scale-110" />
          <h4 className="font-black text-[#C5A059] uppercase text-[10px] tracking-widest mb-6 flex items-center gap-2">
            <Heart size={14} className="fill-[#C5A059]" /> Spiritual Benefit
          </h4>
          <p className="text-white leading-relaxed font-bold italic relative z-10 text-xl tracking-tight">
            "{data.benefit}"
          </p>
        </div>

        {data.reflection && (
          <div className="p-8 bg-emerald-950/50 border border-emerald-900 rounded-[2.5rem]">
             <h4 className="font-black text-emerald-700 uppercase text-[9px] tracking-widest mb-4">Metaphysical Context</h4>
             <p className="text-emerald-400/80 leading-relaxed text-sm font-medium">{data.reflection}</p>
          </div>
        )}
      </div>

      <p className="text-center mt-16 text-[9px] text-emerald-900 font-black uppercase tracking-[0.5em]">
        Wisdom Verified by Ashadu Core v3.0
      </p>
    </div>
  );
};

export default InsightView;