import React from 'react';

interface LiveTickerProps {
  totalUsers: number;
  totalRaised: number;
  outstanding: number;
}

const LiveStreamTicker: React.FC<LiveTickerProps> = ({ totalUsers, totalRaised, outstanding }) => {
  const items = [
    { label: "CELESTIAL PULSE", value: `${totalUsers.toLocaleString()} SOULS VIBRATING`, color: 'text-white' },
    { label: "GAP TO DESTINY", value: `${outstanding.toLocaleString()} LOGS REMAINING`, color: 'text-[#C5A059]' },
    { label: "COLLECTIVE BARAKAH", value: `£${totalRaised.toLocaleString(undefined, { minimumFractionDigits: 2 })}`, color: 'text-emerald-400' },
    { label: "SYSTEM", value: "EMERALD-CORE NOMINAL", color: 'text-white' },
  ];

  return (
    <div className="w-full bg-[#011a14] border-b border-[#C5A059]/10 overflow-hidden h-12 flex items-center shrink-0 z-[100]">
      <div className="flex whitespace-nowrap animate-marquee">
        {[...items, ...items, ...items].map((item, idx) => (
          <div key={idx} className="flex items-center gap-4 mx-12">
            <span className="w-1.5 h-1.5 bg-[#C5A059] rounded-full shadow-[0_0_10px_#C5A059]" />
            <span className="text-[10px] font-black uppercase text-emerald-800 tracking-widest">{item.label}</span>
            <span className={`text-[10px] font-black uppercase tracking-widest ${item.color}`}>{item.value}</span>
          </div>
        ))}
      </div>
      <style>{`
        @keyframes marquee { 0% { transform: translateX(0); } 100% { transform: translateX(-33.33%); } }
        .animate-marquee { animation: marquee 40s linear infinite; }
      `}</style>
    </div>
  );
};

export default LiveStreamTicker;