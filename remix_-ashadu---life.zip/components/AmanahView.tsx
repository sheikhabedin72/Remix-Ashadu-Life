import React, { useState } from 'react';
import { 
  ShieldAlert, 
  Radio, 
  Zap, 
  Target, 
  Play, 
  RotateCcw, 
  ChevronLeft, 
  Save, 
  X, 
  Users, 
  MessageSquare, 
  Send, 
  Heart, 
  Medal, 
  Crown, 
  User, 
  History, 
  UserPlus, 
  Mail, 
  Trash2,
  Coins,
  ShieldCheck,
  Gift,
  HeartHandshake,
  CheckCircle2
} from 'lucide-react';
import { GroupConfig, DonationPillar, UserProfile } from '../types';
import { saveUserData } from '../services/supabaseService';
import FundraisingDashboard from './FundraisingDashboard';

interface AmanahViewProps {
  totalCount: number;
  groupTarget: number;
  setGroupTarget: (val: number) => void;
  donationRate: number;
  onUpdateGlobalZikr: (name: string | null) => void;
  isModerator?: boolean;
  user: UserProfile | null;
}

const AmanahView: React.FC<AmanahViewProps> = ({ totalCount, groupTarget, setGroupTarget, isModerator = true, user }) => {
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'mission' | 'impact' | 'members' | 'chat'>('mission');
  const [isLive, setIsLive] = useState(false);
  const [chatMessage, setChatMessage] = useState('');
  const [inviteInput, setInviteInput] = useState('');
  const [pendingDispatches, setPendingDispatches] = useState<string[]>(['bilal.t@example.com', '@sumayya_k']);
  
  const [config, setConfig] = useState<GroupConfig>(() => {
    const saved = localStorage.getItem('ashadu_group_config_v5');
    return saved ? JSON.parse(saved) : {
      name: 'Emerald Mission', 
      target: groupTarget, 
      deadline: '2026-12-31', 
      zikrType: 'SubhanAllah', 
      customZikrName: '', 
      selectedPillar: 'PENNY_PER_ZIKR' as DonationPillar, 
      notificationHistory: []
    };
  });

  const [members] = useState([
    { name: 'You', count: totalCount, rank: 'Moderator', role: 'admin' },
    { name: 'Jamal Doe', count: 45020, rank: 'Gold', role: 'member' },
    { name: 'Sara Ahmed', count: 8900, rank: 'Silver', role: 'member' },
    { name: 'Omar F.', count: 125000, rank: 'Elite', role: 'member' },
  ]);

  const [chatHistory] = useState([
    { user: 'Omar F.', msg: 'Alhamdulillah, just reached 100k for the group goal! 🚀', time: '2h ago' },
    { user: 'Sara Ahmed', msg: 'Ma sha Allah! Let\'s keep the momentum going brothers.', time: '1h ago' },
    { user: 'Moderator', msg: 'Zakat verification completed for last week\'s contributions.', time: '45m ago' },
  ]);

  const handleSendInvite = () => {
    if (!inviteInput.trim()) return;
    setPendingDispatches([...pendingDispatches, inviteInput.trim()]);
    setInviteInput('');
    alert(`Invitation dispatched to ${inviteInput}. They will see this in their Mission Hub.`);
  };

  const handleRemovePending = (identifier: string) => {
    setPendingDispatches(pendingDispatches.filter(d => d !== identifier));
  };

  const handlePillarSelect = async (pillar: DonationPillar) => {
    const updated = { ...config, selectedPillar: pillar };
    setConfig(updated);
    localStorage.setItem('ashadu_group_config_v5', JSON.stringify(updated));
    if (user?.email) {
      await saveUserData(user.email, { group_config: updated });
    }
  };

  const progress = Math.min((totalCount / config.target) * 100, 100);

  const PILLARS: { id: DonationPillar, label: string, desc: string, icon: React.ReactNode }[] = [
    { id: 'PENNY_PER_ZIKR', label: 'Penny Pulse', desc: '1p per recititation', icon: <Coins size={18}/> },
    { id: 'PROXY_ZIKR', label: 'Proxy Alms', desc: 'Recite for sponsors', icon: <ShieldCheck size={18}/> },
    { id: 'ZIKR_ONLY', label: 'Pure Spirit', desc: 'No financial link', icon: <Zap size={18}/> },
    { id: 'DIRECT', label: 'Direct Bridge', desc: 'Linked to projects', icon: <HeartHandshake size={18}/> },
    { id: 'PER_USER', label: 'Soul Density', desc: 'Donation per joiner', icon: <Users size={18}/> },
    { id: 'ZIKR_AND_DONATE', label: 'Hybrid Mercy', desc: 'Count + Voluntary', icon: <Gift size={18}/> }
  ];

  return (
    <div className="flex-1 flex flex-col bg-[#022c22] text-white font-inter">
      <header className="p-6 border-b border-[#C5A059]/20 flex justify-between items-center shrink-0 bg-black/20 backdrop-blur-md">
        <div>
          <h2 className="text-xl font-black tracking-tight uppercase leading-none">{config.name}</h2>
          <p className="text-[9px] text-[#C5A059] font-black uppercase tracking-[0.3em] mt-2 flex items-center gap-1.5">
            <Radio size={10} className={isLive ? 'animate-pulse' : 'opacity-20'} /> 
            {isLive ? 'CELESTIAL FEED ACTIVE' : 'MISSION IDLE'}
          </p>
        </div>
        {isModerator && (
          <button onClick={() => setIsAdminOpen(true)} className="p-3 bg-emerald-900 border border-[#C5A059]/30 text-[#C5A059] rounded-xl shadow-lg active:scale-95 transition-all">
            <ShieldAlert size={20} />
          </button>
        )}
      </header>

      <div className="px-6 pt-4 shrink-0 overflow-x-auto no-scrollbar">
         <div className="flex gap-2 p-1 bg-black/40 rounded-xl border border-white/5 min-w-max">
            <TabBtn active={activeTab === 'mission'} onClick={() => setActiveTab('mission')} label="ZIKR NAME" icon={<History size={12}/>}/>
            <TabBtn active={activeTab === 'impact'} onClick={() => setActiveTab('impact')} label="Impact" icon={<Heart size={12}/>}/>
            <TabBtn active={activeTab === 'members'} onClick={() => setActiveTab('members')} label="Ummah" icon={<Users size={12}/>}/>
            <TabBtn active={activeTab === 'chat'} onClick={() => setActiveTab('chat')} label="Chat" icon={<MessageSquare size={12}/>}/>
         </div>
      </div>

      <div className="flex-1 overflow-y-auto px-6 pt-8 pb-40 relative no-scrollbar">
        {activeTab === 'mission' && (
          <div className="space-y-8 animate-in fade-in duration-500">
            <div className="bg-black/20 p-10 rounded-[3rem] border border-[#C5A059]/20 shadow-2xl relative overflow-hidden backdrop-blur-md">
               <div className="flex justify-between items-center mb-8">
                  <h3 className="text-[10px] font-black uppercase text-emerald-500 tracking-[0.3em]">Collective Velocity</h3>
                  <span className="text-2xl font-black text-white font-mono">{progress.toFixed(1)}%</span>
               </div>
               <div className="w-full h-4 bg-black/40 border border-white/5 rounded-full overflow-hidden">
                  <div className="h-full bg-gradient-to-r from-emerald-500 to-[#C5A059] shadow-[0_0_15px_rgba(197,160,89,0.4)] transition-all duration-1000" style={{ width: `${progress}%` }} />
               </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
               <div className="bg-emerald-900/20 border border-white/5 p-8 rounded-3xl text-center">
                  <Zap size={24} className="text-[#C5A059] mx-auto mb-3" />
                  <p className="text-[9px] font-black text-emerald-700 uppercase tracking-widest">Logs</p>
                  <p className="text-2xl font-black text-white">{totalCount.toLocaleString()}</p>
               </div>
               <div className="bg-emerald-900/20 border border-white/5 p-8 rounded-3xl text-center">
                  <Target size={24} className="text-emerald-800 mx-auto mb-3" />
                  <p className="text-[9px] font-black text-emerald-700 uppercase tracking-widest">Target</p>
                  <p className="text-2xl font-black text-white">{config.target.toLocaleString()}</p>
               </div>
            </div>
          </div>
        )}

        {activeTab === 'impact' && (
          <FundraisingDashboard currentGroupCount={totalCount} groupTarget={config.target} personalRaised={totalCount * 0.01} totalGroupRaised={totalCount * 0.01 + 2500} joinedUsers={142} recentDonations={[]} onOpenSettings={() => setIsAdminOpen(true)} />
        )}

        {activeTab === 'members' && (
          <div className="space-y-4 animate-in slide-in-from-right duration-500">
             <div className="flex justify-between items-center px-2">
                <h3 className="text-[10px] font-black uppercase text-emerald-600 tracking-[0.3em]">GROUP ASSEMBLY</h3>
                <span className="text-[9px] font-black text-amber-500 uppercase">{members.length} SOULS</span>
             </div>
             {members.map((m, i) => (
               <div key={i} className="bg-black/30 p-5 rounded-2xl border border-white/5 flex justify-between items-center group">
                  <div className="flex items-center gap-4">
                     <div className={`w-12 h-12 rounded-xl flex items-center justify-center border ${m.role === 'admin' ? 'bg-[#C5A059] text-[#022c22]' : 'bg-emerald-900/40 text-emerald-500 border-emerald-800'}`}>
                        {m.role === 'admin' ? <Crown size={20}/> : <User size={20}/>}
                     </div>
                     <div>
                        <h4 className="text-sm font-black uppercase tracking-tight">{m.name}</h4>
                        <p className="text-[8px] text-emerald-700 font-black uppercase tracking-widest flex items-center gap-1">
                           <Medal size={8}/> {m.rank} MEMBER
                        </p>
                     </div>
                  </div>
                  <div className="text-right">
                     <p className="text-sm font-black font-mono text-white">#{m.count.toLocaleString()}</p>
                     <p className="text-[8px] text-[#C5A059] font-black uppercase tracking-widest">Log Power</p>
                  </div>
               </div>
             ))}
          </div>
        )}

        {activeTab === 'chat' && (
          <div className="flex flex-col h-full animate-in slide-in-from-bottom duration-500">
             <div className="flex-1 space-y-6 mb-20">
                {chatHistory.map((c, i) => (
                  <div key={i} className={`flex flex-col ${c.user === 'Moderator' ? 'items-end' : 'items-start'}`}>
                     <div className="flex items-center gap-2 mb-1 px-2">
                        <span className="text-[8px] font-black text-emerald-700 uppercase tracking-widest">{c.user}</span>
                        <span className="text-[8px] font-bold text-stone-600 uppercase">{c.time}</span>
                     </div>
                     <div className={`p-4 rounded-2xl max-w-[80%] text-xs font-medium leading-relaxed ${c.user === 'Moderator' ? 'bg-[#C5A059] text-[#022c22] rounded-tr-none' : 'bg-white/5 text-emerald-100 border border-white/5 rounded-tl-none'}`}>
                        {c.msg}
                     </div>
                  </div>
                ))}
             </div>
             
             <div className="fixed bottom-24 left-6 right-6 p-4 bg-[#011a14] rounded-2xl border border-[#C5A059]/20 shadow-2xl flex items-center gap-3">
                <input 
                  type="text" 
                  value={chatMessage} 
                  onChange={(e) => setChatMessage(e.target.value)} 
                  placeholder="Share barakah..." 
                  className="flex-1 bg-transparent outline-none text-xs font-bold text-white placeholder:text-emerald-900"
                />
                <button className="p-3 bg-[#C5A059] text-[#022c22] rounded-xl active:scale-90 transition-all">
                  <Send size={16} />
                </button>
             </div>
          </div>
        )}
      </div>

      {isAdminOpen && (
        <div className="absolute inset-0 z-[100] bg-[#022c22] animate-in slide-in-from-bottom duration-500 overflow-y-auto pb-40 no-scrollbar">
           <header className="p-8 border-b border-[#C5A059]/20 flex justify-between items-center sticky top-0 bg-[#022c22]/95 backdrop-blur-md z-50">
              <div className="flex items-center gap-4">
                 <div className="p-3 bg-emerald-950 text-[#C5A059] rounded-xl border border-[#C5A059]/30"><ShieldAlert size={24} /></div>
                 <div>
                    <h2 className="text-2xl font-black uppercase tracking-tighter">Moderator</h2>
                    <p className="text-[9px] text-emerald-500 font-black uppercase tracking-[0.3em]">Command Suite</p>
                 </div>
              </div>
              <button onClick={() => setIsAdminOpen(false)} className="p-4 bg-black/40 text-[#C5A059] rounded-xl active:scale-90"><X size={28} /></button>
           </header>

           <div className="p-8 space-y-10">
              {/* Mission Config */}
              <div className="bg-black/20 border border-emerald-900 p-8 rounded-[2.5rem] space-y-8">
                 <h3 className="text-[10px] font-black uppercase text-amber-500 tracking-[0.2em] mb-2 flex items-center gap-2"><Target size={14}/> Core Configuration</h3>
                 <AdminInput label="Mission Designation" value={config.name} onChange={v => setConfig({...config, name: v})} />
                 <AdminInput label="Verse Override" value={config.customZikrName} onChange={v => setConfig({...config, customZikrName: v, isCustomZikr: !!v})} />
                 <div className="grid grid-cols-2 gap-4">
                    <AdminInput type="number" label="Quota" value={config.target} onChange={v => setConfig({...config, target: parseInt(v) || 0})} />
                    <AdminInput type="date" label="Deadline" value={config.deadline} onChange={v => setConfig({...config, deadline: v})} />
                 </div>
              </div>

              {/* Fundraising Pillar Selection */}
              <div className="bg-black/20 border border-emerald-900 p-8 rounded-[2.5rem] space-y-6">
                 <h3 className="text-[10px] font-black uppercase text-amber-500 tracking-[0.2em] mb-2 flex items-center gap-2">
                   <HeartHandshake size={14}/> Spiritual Funding Pillar
                 </h3>
                 <p className="text-[9px] text-emerald-600 font-bold uppercase tracking-widest px-2 mb-4 leading-relaxed">
                   Select the mode of contribution for this circle. This protocol dictates how barakah is distributed.
                 </p>
                 
                 <div className="grid grid-cols-2 gap-3">
                    {PILLARS.map((pillar) => (
                      <button 
                        key={pillar.id}
                        onClick={() => handlePillarSelect(pillar.id)}
                        className={`p-4 rounded-2xl border text-left transition-all active:scale-[0.98] group flex flex-col gap-2 relative overflow-hidden
                          ${config.selectedPillar === pillar.id 
                            ? 'bg-amber-500/10 border-amber-500 shadow-[0_0_15px_rgba(245,158,11,0.1)]' 
                            : 'bg-black/40 border-emerald-900 hover:border-emerald-700'}`}
                      >
                         <div className={`w-8 h-8 rounded-lg flex items-center justify-center transition-all ${config.selectedPillar === pillar.id ? 'bg-amber-500 text-emerald-950' : 'bg-emerald-950 text-emerald-600'}`}>
                           {pillar.icon}
                         </div>
                         <div>
                            <h4 className={`text-[10px] font-black uppercase tracking-tight ${config.selectedPillar === pillar.id ? 'text-amber-500' : 'text-white'}`}>
                              {pillar.label}
                            </h4>
                            <p className="text-[8px] text-emerald-700 font-bold uppercase tracking-widest mt-1">
                              {pillar.desc}
                            </p>
                         </div>
                         {config.selectedPillar === pillar.id && (
                            <div className="absolute top-2 right-2 text-amber-500 animate-in zoom-in duration-300">
                               <CheckCircle2 size={12} fill="currentColor" className="text-emerald-950"/>
                            </div>
                         )}
                      </button>
                    ))}
                 </div>
              </div>

              {/* Invitation System */}
              <div className="bg-emerald-900/10 border border-emerald-900 p-8 rounded-[2.5rem] space-y-6">
                 <div className="flex justify-between items-center">
                    <h3 className="text-[10px] font-black uppercase text-amber-500 tracking-[0.2em] flex items-center gap-2"><UserPlus size={14}/> Invite Ummah</h3>
                    <span className="text-[8px] font-black text-emerald-700 uppercase">{pendingDispatches.length} DISPATCHED</span>
                 </div>

                 <div className="flex gap-2">
                    <div className="flex-1 relative">
                       <Mail size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-emerald-800" />
                       <input 
                          type="text" 
                          placeholder="Email or @Username" 
                          value={inviteInput}
                          onChange={e => setInviteInput(e.target.value)}
                          className="w-full bg-black/40 border border-emerald-800 rounded-2xl py-4 pl-12 pr-4 text-xs font-bold outline-none focus:border-amber-500 transition-all text-white placeholder:text-emerald-950"
                       />
                    </div>
                    <button 
                       onClick={handleSendInvite}
                       className="bg-amber-500 text-emerald-950 px-6 rounded-2xl font-black text-[10px] uppercase tracking-widest active:scale-95 shadow-lg"
                    >
                       Invite
                    </button>
                 </div>

                 {pendingDispatches.length > 0 && (
                    <div className="space-y-2 mt-6">
                       <p className="text-[8px] font-black text-emerald-800 uppercase tracking-widest ml-1">Pending Responses</p>
                       {pendingDispatches.map((identifier) => (
                          <div key={identifier} className="bg-black/20 p-4 rounded-xl border border-white/5 flex justify-between items-center group">
                             <div className="flex items-center gap-3">
                                <div className="w-8 h-8 rounded-lg bg-emerald-950 flex items-center justify-center text-emerald-600">
                                   <Mail size={14} />
                                </div>
                                <span className="text-[10px] font-bold text-white/60">{identifier}</span>
                             </div>
                             <button onClick={() => handleRemovePending(identifier)} className="text-red-950 hover:text-red-500 p-2 transition-colors">
                                <Trash2 size={14} />
                             </button>
                          </div>
                       ))}
                    </div>
                 )}
              </div>
              
              <div className="space-y-4">
                 <button onClick={() => { setIsLive(true); setIsAdminOpen(false); }} className="w-full btn-gold font-black py-8 rounded-2xl flex items-center justify-center gap-4 uppercase tracking-[0.3em] text-[11px] shadow-2xl">
                    <Play size={22} fill="currentColor" /> START BROADCAST
                 </button>
                 <button onClick={() => alert('Mission Reset.')} className="w-full text-red-500 border border-red-500/30 bg-red-500/5 font-black py-6 rounded-2xl flex items-center justify-center gap-4 uppercase tracking-[0.3em] text-[10px] active:scale-95">
                    <RotateCcw size={18} /> RESET MISSION COUNTS
                 </button>
              </div>
           </div>
        </div>
      )}
    </div>
  );
};

const TabBtn = ({ active, onClick, label, icon }: any) => (
  <button 
    onClick={onClick} 
    className={`flex-1 px-6 py-3 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all flex items-center gap-2 ${active ? 'bg-[#C5A059] text-[#022c22]' : 'text-emerald-700'}`}
  >
    {icon} {label}
  </button>
);

const AdminInput = ({ label, value, onChange, type = "text" }: any) => (
  <div className="space-y-2">
     <label className="text-[9px] font-black uppercase text-emerald-700 ml-1 tracking-widest">{label}</label>
     <input type={type} value={value} onChange={e => onChange(e.target.value)} className="w-full input-emerald p-5 rounded-2xl text-sm font-bold" />
  </div>
);

export default AmanahView;