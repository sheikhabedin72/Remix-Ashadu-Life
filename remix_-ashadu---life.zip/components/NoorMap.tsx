
import React, { useState, useEffect, useMemo, useRef } from 'react';
import { 
  MapPin, 
  Search, 
  Navigation, 
  Building2, 
  Store, 
  ShieldCheck, 
  Compass, 
  Map as MapIcon,
  Zap,
  Target,
  Sparkles,
  Eye,
  EyeOff,
  Shield,
  MessageSquare,
  Users,
  Clock,
  Globe,
  UserPlus,
  Heart,
  X,
  ChevronRight,
  Share2,
  Flame,
  MessageCircle,
  ThumbsUp,
  Rss,
  UsersRound,
  Users2,
  Home,
  Check,
  Mail,
  Send,
  PlusCircle,
  User as UserIcon
} from 'lucide-react';
import { LocationLandmark, LandmarkCategory, SystemSettings } from '../types';
import { calculateDistance, fetchCurrentLocation } from '../services/locationService';
import { DEMO_PROFILES } from '../constants';

interface NoorMapProps {
  settings: SystemSettings;
}

type UmmahMode = 'RADAR' | 'SOULS' | 'FEED';
type UnitType = 'GROUP' | 'CIRCLE' | 'FAMILY';

const NoorMap: React.FC<NoorMapProps> = ({ settings }) => {
  const [activeMode, setActiveMode] = useState<UmmahMode>('RADAR');
  const [searchQuery, setSearchQuery] = useState('');
  const [userCoords, setUserCoords] = useState<{lat: number, lng: number} | null>(null);
  const [isGhostMode, setIsGhostMode] = useState(false);
  const [matchIndex, setMatchIndex] = useState(0);
  const [showCreateModal, setShowCreateModal] = useState(false);
  
  // Creation state
  const [unitData, setUnitData] = useState({
    type: 'CIRCLE' as UnitType,
    name: '',
    purpose: '',
    invitee: ''
  });

  // Dropdown state for invitations
  const [showInviteDropdown, setShowInviteDropdown] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    fetchCurrentLocation().then(pos => {
      setUserCoords({ lat: pos.coords.latitude, lng: pos.coords.longitude });
    }).catch(() => setUserCoords({ lat: 51.5074, lng: -0.1278 }));
  }, []);

  // Handle clicks outside the dropdown to close it
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setShowInviteDropdown(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const filteredSouls = useMemo(() => {
    return DEMO_PROFILES.filter(u => 
      u.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
      u.city.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [searchQuery]);

  // Logic for the friend lookup dropdown
  const friendSuggestions = useMemo(() => {
    if (!unitData.invitee && !showInviteDropdown) return [];
    const query = unitData.invitee.startsWith('@') ? unitData.invitee.slice(1).toLowerCase() : unitData.invitee.toLowerCase();
    return DEMO_PROFILES.filter(u => 
      u.name.toLowerCase().includes(query) || 
      u.id.toLowerCase().includes(query)
    ).slice(0, 5);
  }, [unitData.invitee, showInviteDropdown]);

  const handleSalaam = (name: string) => {
    alert(`As-Salaamu Alaykum to ${name}! A spiritual connection request has been sent.`);
  };

  const handleAddProfile = () => {
    window.dispatchEvent(new CustomEvent('openIdentityPortal'));
  };

  const finalizeUnitCreation = () => {
    if (!unitData.name) {
      alert("Please designate a name for your unit.");
      return;
    }
    alert(`Mabrouk! Your ${unitData.type.toLowerCase()} "${unitData.name}" has been established. Invitations have been dispatched to ${unitData.invitee || 'your connections'}.`);
    setShowCreateModal(false);
    setUnitData({ type: 'CIRCLE', name: '', purpose: '', invitee: '' });
  };

  const selectFriend = (friend: typeof DEMO_PROFILES[0]) => {
    const username = `@${friend.name.toLowerCase().replace(/\s/g, '_')}_${friend.id}`;
    setUnitData({ ...unitData, invitee: username });
    setShowInviteDropdown(false);
  };

  const currentMatch = filteredSouls[matchIndex % filteredSouls.length];

  return (
    <div className="flex-1 flex flex-col bg-[#021F1F] animate-in fade-in duration-700 overflow-hidden relative font-inter">
      
      {/* CREATION MODAL */}
      {showCreateModal && (
        <div className="fixed inset-0 z-[1000] flex items-center justify-center p-6 bg-black/95 backdrop-blur-2xl animate-in fade-in duration-500">
           <div className="bg-emerald-900 w-full max-w-sm rounded-[3.5rem] border border-[#C5A059]/30 p-10 shadow-2xl relative overflow-hidden flex flex-col gap-8">
              <div className="absolute inset-0 celestial-grid opacity-10 pointer-events-none" />
              
              <header className="flex justify-between items-center relative z-10">
                 <div>
                    <h3 className="text-2xl font-black text-white uppercase tracking-tighter">Start Unit</h3>
                    <p className="text-[9px] text-[#C5A059] font-black uppercase tracking-[0.3em] mt-1.5">Unifying the Ummah</p>
                 </div>
                 <button onClick={() => setShowCreateModal(false)} className="p-3 bg-black/40 text-stone-500 rounded-2xl hover:text-white transition-colors active:scale-90"><X size={24} /></button>
              </header>

              <div className="space-y-6 relative z-10">
                 {/* Type Selector */}
                 <div className="flex gap-2 p-1.5 bg-black/30 rounded-2xl border border-white/5">
                    <UnitTypeBtn active={unitData.type === 'GROUP'} onClick={() => setUnitData({...unitData, type: 'GROUP'})} label="Group" icon={<Users2 size={12}/>} />
                    <UnitTypeBtn active={unitData.type === 'CIRCLE'} onClick={() => setUnitData({...unitData, type: 'CIRCLE'})} label="Circle" icon={<UsersRound size={12}/>} />
                    <UnitTypeBtn active={unitData.type === 'FAMILY'} onClick={() => setUnitData({...unitData, type: 'FAMILY'})} label="Family" icon={<Home size={12}/>} />
                 </div>

                 <div className="space-y-4">
                    <div className="space-y-2">
                       <label className="text-[10px] font-black uppercase text-emerald-500 tracking-[0.2em] ml-1">Identity Name</label>
                       <input 
                         type="text" placeholder={`e.g. ${unitData.type === 'FAMILY' ? 'The Hashimi Clan' : 'Daily Duas'}`} 
                         value={unitData.name} onChange={e => setUnitData({...unitData, name: e.target.value})}
                         className="w-full bg-black/40 border border-emerald-800 rounded-2xl p-5 text-sm font-bold text-white outline-none focus:border-[#C5A059] transition-all"
                       />
                    </div>
                    
                    <div className="space-y-2 relative" ref={dropdownRef}>
                       <label className="text-[10px] font-black uppercase text-emerald-500 tracking-[0.2em] ml-1">Invite Souls</label>
                       <div className="relative">
                          <Mail size={16} className="absolute left-5 top-1/2 -translate-y-1/2 text-emerald-700" />
                          <input 
                            type="text" 
                            placeholder="Type name or select below..." 
                            value={unitData.invitee} 
                            onFocus={() => setShowInviteDropdown(true)}
                            onChange={e => {
                                setUnitData({...unitData, invitee: e.target.value});
                                setShowInviteDropdown(true);
                            }}
                            className="w-full bg-black/40 border border-emerald-800 rounded-2xl py-5 pl-14 pr-5 text-sm font-bold text-white outline-none focus:border-[#C5A059] transition-all"
                          />
                       </div>

                       {/* Friend Dropdown */}
                       {showInviteDropdown && friendSuggestions.length > 0 && (
                          <div className="absolute top-full left-0 right-0 mt-2 bg-emerald-950 border border-[#C5A059]/30 rounded-2xl shadow-2xl overflow-hidden z-[1100] animate-in slide-in-from-top-2">
                             <div className="p-3 border-b border-white/5 bg-black/20">
                                <span className="text-[8px] font-black text-[#C5A059] uppercase tracking-widest">Connect with Friends</span>
                             </div>
                             {friendSuggestions.map((friend) => (
                                <button 
                                  key={friend.id}
                                  onClick={() => selectFriend(friend)}
                                  className="w-full p-4 flex items-center justify-between hover:bg-[#C5A059]/10 transition-colors border-b border-white/5 last:border-none group"
                                >
                                   <div className="flex items-center gap-3">
                                      <div className="w-8 h-8 rounded-lg bg-emerald-900 border border-white/5 flex items-center justify-center text-[#C5A059] text-[10px] font-black uppercase group-hover:scale-110 transition-transform">
                                         {friend.name[0]}
                                      </div>
                                      <div className="text-left">
                                         <p className="text-xs font-bold text-white leading-none">{friend.name}</p>
                                         <p className="text-[8px] text-emerald-600 font-black uppercase mt-1">@{friend.name.toLowerCase().replace(/\s/g, '')}</p>
                                      </div>
                                   </div>
                                   <PlusCircle size={14} className="text-emerald-800 group-hover:text-[#C5A059]" />
                                </button>
                             ))}
                          </div>
                       )}
                    </div>
                 </div>
              </div>

              <button 
                onClick={finalizeUnitCreation}
                className="w-full btn-gold py-6 rounded-3xl font-black text-xs uppercase tracking-[0.3em] shadow-2xl active:scale-95 transition-all flex items-center justify-center gap-3 relative z-10 border-b-8 border-[#8c713b]"
              >
                <Send size={18} /> Initialize & Invite
              </button>
           </div>
        </div>
      )}

      {/* 1. PERSISTENT HEADER & MULTI-MODE TOGGLE */}
      <header className="p-6 bg-black/40 border-b border-[#0A4242]/50 backdrop-blur-3xl z-20">
         <div className="flex justify-between items-center mb-6">
            <div>
               <h2 className="text-xl font-bold text-white tracking-[0.2em] uppercase flex items-center gap-2">
                 UMMAH <Globe size={18} className="text-[#C5A059]" />
               </h2>
               <p className="text-[9px] text-[#4ADE80] uppercase font-black tracking-[0.3em] mt-1">
                 {activeMode === 'RADAR' ? 'SOULS IN YOUR PROXIMITY' : 
                  activeMode === 'SOULS' ? 'ZIKR PARTNER DISCOVERY' : 'SPIRITUAL SOCIETY FEED'}
               </p>
            </div>
            
            <div className="flex gap-2">
               {/* START UNIT BUTTON */}
               <button 
                onClick={() => setShowCreateModal(true)}
                className="p-3 rounded-2xl bg-amber-500 text-emerald-950 border-b-4 border-[#8c713b] active:scale-90 transition-all shadow-lg flex items-center gap-2 font-black"
               >
                 <PlusCircle size={18} />
                 <span className="text-[9px] uppercase tracking-widest hidden sm:inline">Start Unit</span>
               </button>

               <button 
                onClick={handleAddProfile}
                className="p-3 rounded-2xl bg-emerald-900/60 border border-[#C5A059]/40 text-[#C5A059] active:scale-90 transition-all shadow-lg flex items-center gap-2"
               >
                 <UserPlus size={18} />
                 <span className="text-[9px] font-black uppercase tracking-widest hidden sm:inline">Add Profile</span>
               </button>

               <button 
                onClick={() => setIsGhostMode(!isGhostMode)}
                className={`p-3 rounded-2xl transition-all shadow-xl flex items-center gap-2 border ${isGhostMode ? 'bg-[#0A4242]/50 text-[#4ADE80] border-[#0A4242]' : 'bg-[#C5A059] text-[#021F1F] border-[#C5A059]'}`}
               >
                {isGhostMode ? <EyeOff size={18} /> : <Shield size={18} />}
               </button>
            </div>
         </div>

         {/* Mode Controller */}
         <div className="flex gap-2 p-1 bg-[#053131] rounded-2xl border border-[#0A4242]">
            <ModeBtn active={activeMode === 'RADAR'} onClick={() => setActiveMode('RADAR')} label="RADAR" icon={<Navigation size={12}/>} />
            <ModeBtn active={activeMode === 'SOULS'} onClick={() => setActiveMode('SOULS')} label="MATCH" icon={<Heart size={12}/>} />
            <ModeBtn active={activeMode === 'FEED'} onClick={() => setActiveMode('FEED')} label="SOCIETY" icon={<Rss size={12}/>} />
         </div>
      </header>

      {/* 2. DYNAMIC CONTENT AREA */}
      <div className="flex-1 overflow-y-auto px-6 pt-6 pb-40 custom-scrollbar relative z-10">
        
        {/* RADAR MODE (Happn Clone) */}
        {activeMode === 'RADAR' && (
          <div className="space-y-4 animate-in slide-in-from-left-4 duration-500">
            <div className="relative group mb-6">
              <Search className="absolute left-5 top-1/2 -translate-y-1/2 text-[#4ADE80]/30" size={18} />
              <input 
                type="text" placeholder="Scanning for souls..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} 
                className="w-full pl-14 pr-6 py-4 bg-[#053131]/50 border border-[#0A4242]/50 rounded-2xl outline-none text-sm font-bold text-white placeholder-[#0A4242] shadow-inner" 
              />
            </div>
            
            {filteredSouls.map((user, i) => (
              <div key={user.id} className="bg-[#053131]/30 border border-[#0A4242] p-5 rounded-[2rem] flex items-center justify-between group hover:border-[#C5A059]/40 transition-all">
                <div className="flex items-center gap-4">
                  <div className="relative">
                    <div className="w-14 h-14 rounded-2xl bg-[#021F1F] border border-[#C5A059]/30 flex items-center justify-center text-[#C5A059] font-black text-xl shadow-lg group-hover:rotate-3 transition-transform">
                      {user.name.charAt(0)}
                    </div>
                    <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-[#4ADE80] rounded-full border-2 border-[#053131] animate-pulse" />
                  </div>
                  <div>
                    <h4 className="text-white font-black text-sm tracking-tight">{user.name}</h4>
                    <p className="text-[9px] text-[#4ADE80] font-bold uppercase tracking-widest mt-1">Crossed paths { (i % 10) + 1 } times</p>
                    <p className="text-[8px] text-stone-500 font-black uppercase mt-0.5">{user.city} • Just now</p>
                  </div>
                </div>
                <button onClick={() => handleSalaam(user.name)} className="p-3 bg-[#C5A059]/10 text-[#C5A059] rounded-xl hover:bg-[#C5A059] hover:text-[#021F1F] transition-all">
                  <MessageCircle size={18} />
                </button>
              </div>
            ))}
          </div>
        )}

        {/* MATCH MODE (Tinder Clone) */}
        {activeMode === 'SOULS' && (
          <div className="h-full flex flex-col items-center justify-center animate-in zoom-in-95 duration-500 px-4">
            <div className="w-full max-w-sm bg-[#053131] border-2 border-[#C5A059]/30 rounded-[3rem] overflow-hidden shadow-[0_20px_60px_rgba(0,0,0,0.5)] relative">
               <div className="h-96 bg-gradient-to-br from-emerald-900 to-emerald-950 flex flex-col items-center justify-center relative">
                  <div className="absolute inset-0 celestial-grid opacity-20" />
                  <div className="w-40 h-40 rounded-full bg-[#021F1F] border-4 border-[#C5A059] flex items-center justify-center text-[#C5A059] text-7xl font-black shadow-2xl relative z-10">
                    {currentMatch.name.charAt(0)}
                  </div>
                  <div className="absolute top-6 left-6 bg-amber-500/20 px-3 py-1 rounded-full border border-amber-500/40 z-10">
                     <span className="text-[10px] font-black text-amber-500 uppercase tracking-widest flex items-center gap-1.5"><Flame size={12}/> {currentMatch.streak} DAY STREAK</span>
                  </div>
               </div>
               
               <div className="p-8 text-center bg-black/20">
                  <h3 className="text-3xl font-black text-white tracking-tighter uppercase">{currentMatch.name}</h3>
                  <p className="text-[#4ADE80] text-xs font-bold uppercase tracking-[0.2em] mt-2 mb-6">{currentMatch.city} • {currentMatch.rank} Member</p>
                  
                  <div className="flex items-center justify-center gap-2 bg-[#0A4242]/40 p-4 rounded-2xl border border-white/5 mb-8">
                     <ShieldCheck size={16} className="text-[#C5A059]" />
                     <p className="text-[10px] text-emerald-100 font-bold uppercase tracking-widest">98% Spiritual Compatibility</p>
                  </div>

                  <div className="flex justify-center gap-6">
                     <button 
                      onClick={() => setMatchIndex(prev => prev + 1)}
                      className="w-16 h-16 rounded-full bg-black/40 border border-red-500/30 text-red-500 flex items-center justify-center hover:bg-red-500 hover:text-white transition-all active:scale-90 shadow-xl"
                     >
                       <X size={32} />
                     </button>
                     <button 
                      onClick={() => { handleSalaam(currentMatch.name); setMatchIndex(prev => prev + 1); }}
                      className="w-20 h-20 rounded-full bg-[#C5A059] text-[#021F1F] flex items-center justify-center hover:scale-110 transition-all active:scale-90 shadow-2xl border-4 border-emerald-950"
                     >
                       <Heart size={40} className="fill-current" />
                     </button>
                     <button 
                      onClick={() => setMatchIndex(prev => prev + 1)}
                      className="w-16 h-16 rounded-full bg-black/40 border border-blue-500/30 text-blue-400 flex items-center justify-center hover:bg-blue-500 hover:text-white transition-all active:scale-90 shadow-xl"
                     >
                       <Share2 size={28} />
                     </button>
                  </div>
               </div>
            </div>
            <p className="text-[9px] text-[#4ADE80]/40 font-black uppercase tracking-[0.4em] mt-8">Discover Zikr Partners Globally</p>
          </div>
        )}

        {/* FEED MODE (Facebook Clone) */}
        {activeMode === 'FEED' && (
          <div className="space-y-6 animate-in slide-in-from-right-4 duration-500">
            {filteredSouls.slice(0, 8).map((user, i) => (
              <div key={user.id} className="bg-[#053131]/20 border border-[#0A4242] rounded-[2.5rem] overflow-hidden shadow-xl">
                 <div className="p-6">
                    <div className="flex items-center gap-4 mb-4">
                       <div className="w-12 h-12 rounded-2xl bg-[#0A4242] border border-[#C5A059]/20 flex items-center justify-center text-[#C5A059] font-black">{user.name.charAt(0)}</div>
                       <div>
                          <h4 className="text-white font-black text-sm">{user.name} <span className="text-emerald-800 font-bold ml-1 text-xs">• Follow</span></h4>
                          <p className="text-[9px] text-[#4ADE80]/60 font-black uppercase tracking-widest">{i + 1}h ago • {user.city}</p>
                       </div>
                    </div>
                    <p className="text-emerald-100 text-sm leading-relaxed mb-6 font-medium italic">
                      "Alhamdulillah, just completed a 500 SubhanAllah cycle for the Gaza Thirst Relief Well mission. The barakah is tangible! ✨"
                    </p>
                    <div className="bg-black/20 rounded-2xl p-4 border border-white/5 flex items-center justify-between">
                       <div className="flex items-center gap-1.5">
                          <Zap size={14} className="text-amber-500" />
                          <span className="text-[9px] font-black text-[#C5A059] uppercase tracking-widest">+50 Impact Points Generated</span>
                       </div>
                       <ChevronRight size={14} className="text-emerald-900" />
                    </div>
                 </div>
                 <div className="flex border-t border-[#0A4242]/50">
                    <FeedAction icon={<ThumbsUp size={16}/>} label="Ma Sha Allah" />
                    <FeedAction icon={<MessageCircle size={16}/>} label="Dua" />
                    <FeedAction icon={<Share2 size={16}/>} label="Forward" />
                 </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* 3. PERSISTENT SAFETY FOOTER */}
      <footer className="shrink-0 z-30">
        <div className="flex items-center justify-center gap-3 p-5 bg-[#053131] border-t border-[#0A4242] backdrop-blur-3xl shadow-[0_-10px_40px_rgba(0,0,0,0.5)]">
           <ShieldCheck size={16} className={isGhostMode ? 'text-stone-500' : 'text-[#4ADE80]'} />
           <p className={`text-[10px] font-black uppercase tracking-[0.2em] transition-colors ${isGhostMode ? 'text-stone-500' : 'text-[#4ADE80]'}`}>
             {isGhostMode ? 'GHOST MODE ACTIVE • PRIVATE' : 'UMMAH SIGNAL ACTIVE • PUBLIC'}
           </p>
        </div>
      </footer>
    </div>
  );
};

const UnitTypeBtn = ({ active, onClick, label, icon }: any) => (
  <button 
    onClick={onClick} 
    className={`flex-1 py-3 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all flex items-center justify-center gap-2 
      ${active ? 'bg-[#C5A059] text-emerald-950 shadow-lg' : 'text-emerald-700'}`}
  >
    {icon} {label}
  </button>
);

const ModeBtn = ({ active, onClick, label, icon }: any) => (
  <button onClick={onClick} className={`flex-1 py-3 rounded-xl text-[10px] font-black uppercase tracking-[0.1em] transition-all flex items-center justify-center gap-2 ${active ? 'bg-[#0A4242] text-white border border-[#C5A059] shadow-md' : 'text-[#4D6B6B]'}`}>
    {icon}{label}
  </button>
);

const FeedAction = ({ icon, label }: any) => (
  <button className="flex-1 py-4 flex items-center justify-center gap-2 text-[9px] font-black uppercase text-[#4D6B6B] hover:text-[#4ADE80] hover:bg-white/5 transition-all">
    {icon}{label}
  </button>
);

export default NoorMap;
