
import React, { useState } from 'react';
import { motion, AnimatePresence, useMotionValue, useTransform } from 'framer-motion';
import { Heart, X, User, Briefcase, GraduationCap, MapPin, Sparkles, MessageCircle } from 'lucide-react';
import { UserProfile } from '../types';

interface DiscoveryProfile {
  id: string;
  name: string;
  age: number;
  city: string;
  role: string;
  tags: string[];
  bio: string;
  avatarColor: string;
  category: 'Business' | 'Study' | 'Marriage' | 'Community';
}

const MOCK_PROFILES: DiscoveryProfile[] = [
  {
    id: '1',
    name: 'Zaid',
    age: 28,
    city: 'London',
    role: 'Web Developer',
    tags: ['React', 'TypeScript', 'Learning Tajweed'],
    bio: 'Looking for a study partner for Quranic Arabic and potential business collaborations in tech.',
    avatarColor: 'bg-indigo-600',
    category: 'Business'
  },
  {
    id: '2',
    name: 'Maryam',
    age: 24,
    city: 'Manchester',
    role: 'Medical Student',
    tags: ['Community Volunteer', 'Hafiza', 'Baking'],
    bio: 'Passionate about community health and Islamic history. Looking for sisters to study with.',
    avatarColor: 'bg-rose-600',
    category: 'Study'
  },
  {
    id: '3',
    name: 'Ibrahim',
    age: 31,
    city: 'Birmingham',
    role: 'Architect',
    tags: ['Masjid Volunteer', 'Hiking', 'Calligraphy'],
    bio: 'Dedicated to Islamic architecture and youth mentorship. Seeking meaningful brotherhood.',
    avatarColor: 'bg-emerald-600',
    category: 'Community'
  }
];

interface UmmahConnectViewProps {
  user: UserProfile | null;
}

const UmmahConnectView: React.FC<UmmahConnectViewProps> = ({ user }) => {
  const [profiles, setProfiles] = useState(MOCK_PROFILES);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [match, setMatch] = useState<DiscoveryProfile | null>(null);

  const handleSwipe = (direction: 'left' | 'right') => {
    if (direction === 'right') {
      // Simulate match logic
      if (Math.random() > 0.5) {
        setMatch(profiles[currentIndex]);
      }
    }
    setCurrentIndex(prev => prev + 1);
  };

  const currentProfile = profiles[currentIndex];

  return (
    <div className="flex-1 overflow-hidden flex flex-col bg-[#022c22] font-inter relative">
      <header className="px-6 pt-6 mb-8">
        <h2 className="text-3xl font-black text-white tracking-tighter uppercase leading-none">
          Ummah <span className="text-[#C5A059]">Connect</span>
        </h2>
        <p className="text-[10px] text-emerald-500 font-black uppercase tracking-[0.3em] mt-2">Purpose-Driven Networking</p>
      </header>

      <div className="flex-1 relative flex items-center justify-center px-4">
        <AnimatePresence>
          {currentProfile ? (
            <SwipeCard 
              key={currentProfile.id}
              profile={currentProfile}
              onSwipe={handleSwipe}
            />
          ) : (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center p-8"
            >
              <div className="w-20 h-20 bg-emerald-900/30 rounded-full flex items-center justify-center mx-auto mb-6 border border-emerald-800">
                <Sparkles className="text-[#C5A059]" size={32} />
              </div>
              <h3 className="text-xl font-black text-white uppercase tracking-tighter mb-2">Deck Completed</h3>
              <p className="text-xs text-emerald-500 font-black uppercase tracking-widest">Check back later for new souls</p>
              <button 
                onClick={() => setCurrentIndex(0)}
                className="mt-8 btn-gold px-8 py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest"
              >
                Refresh Deck
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Match Overlay */}
      <AnimatePresence>
        {match && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[300] bg-emerald-950/95 backdrop-blur-xl flex items-center justify-center p-8"
          >
            <div className="text-center max-w-sm">
              <motion.div 
                initial={{ scale: 0.5, rotate: -20 }}
                animate={{ scale: 1, rotate: 0 }}
                className="w-32 h-32 bg-[#C5A059] rounded-[2.5rem] flex items-center justify-center mx-auto mb-8 shadow-[0_0_50px_rgba(197,160,89,0.3)]"
              >
                <Sparkles size={64} className="text-emerald-950" />
              </motion.div>
              <h2 className="text-4xl font-black text-white uppercase tracking-tighter mb-4">MashaAllah!</h2>
              <p className="text-emerald-400 font-black uppercase tracking-widest text-xs mb-8">You have a new connection with {match.name}</p>
              <div className="space-y-4">
                <button 
                  onClick={() => setMatch(null)}
                  className="w-full btn-gold py-6 rounded-2xl font-black uppercase tracking-widest text-xs shadow-2xl"
                >
                  Send Message
                </button>
                <button 
                  onClick={() => setMatch(null)}
                  className="w-full bg-emerald-900/50 text-emerald-500 py-6 rounded-2xl font-black uppercase tracking-widest text-xs"
                >
                  Keep Exploring
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="h-32 flex items-center justify-center gap-8 px-8">
        <button 
          onClick={() => handleSwipe('left')}
          className="w-16 h-16 rounded-full bg-emerald-950 border border-rose-500/30 flex items-center justify-center text-rose-500 shadow-lg active:scale-90 transition-all"
        >
          <X size={28} />
        </button>
        <button 
          onClick={() => handleSwipe('right')}
          className="w-20 h-20 rounded-full bg-[#C5A059] flex items-center justify-center text-emerald-950 shadow-[0_10px_30px_rgba(197,160,89,0.3)] active:scale-90 transition-all"
        >
          <Heart size={36} fill="currentColor" />
        </button>
      </div>
    </div>
  );
};

const SwipeCard = ({ profile, onSwipe }: { profile: DiscoveryProfile, onSwipe: (d: 'left' | 'right') => void }) => {
  const x = useMotionValue(0);
  const rotate = useTransform(x, [-200, 200], [-25, 25]);
  const opacity = useTransform(x, [-200, -150, 0, 150, 200], [0, 1, 1, 1, 0]);

  return (
    <motion.div
      style={{ x, rotate, opacity }}
      drag="x"
      dragConstraints={{ left: 0, right: 0 }}
      onDragEnd={(_, info) => {
        if (info.offset.x > 100) onSwipe('right');
        else if (info.offset.x < -100) onSwipe('left');
      }}
      initial={{ scale: 0.9, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      exit={{ x: x.get() > 0 ? 500 : -500, opacity: 0 }}
      className="absolute w-full max-w-[340px] aspect-[3/4] bg-emerald-900/40 backdrop-blur-md border border-emerald-800/50 rounded-[3rem] overflow-hidden shadow-2xl cursor-grab active:cursor-grabbing"
    >
      <div className={`h-1/2 ${profile.avatarColor} relative flex items-center justify-center`}>
        <div className="absolute inset-0 bg-gradient-to-t from-emerald-950/80 to-transparent" />
        <User size={80} className="text-white/20" />
        <div className="absolute bottom-6 left-8">
          <div className="bg-[#C5A059] text-emerald-950 px-3 py-1 rounded-full text-[8px] font-black uppercase tracking-widest mb-2 inline-block">
            {profile.category}
          </div>
          <h3 className="text-3xl font-black text-white uppercase tracking-tighter">{profile.name}, {profile.age}</h3>
          <div className="flex items-center gap-2 text-emerald-400 text-[10px] font-black uppercase tracking-widest">
            <MapPin size={12} />
            {profile.city}
          </div>
        </div>
      </div>
      <div className="p-8">
        <div className="flex items-center gap-2 mb-4">
          <Briefcase size={14} className="text-[#C5A059]" />
          <span className="text-[10px] font-black text-white uppercase tracking-widest">{profile.role}</span>
        </div>
        <p className="text-xs text-emerald-100/70 font-medium leading-relaxed mb-6 line-clamp-3">
          {profile.bio}
        </p>
        <div className="flex flex-wrap gap-2">
          {profile.tags.map(tag => (
            <span key={tag} className="px-3 py-1 bg-emerald-950 border border-emerald-800 rounded-full text-[8px] font-black text-emerald-500 uppercase tracking-widest">
              {tag}
            </span>
          ))}
        </div>
      </div>
    </motion.div>
  );
};

export default UmmahConnectView;
