
import React from 'react';
import { ShieldCheck, Lock, Shield, Cookie, Folder, ChevronLeft, Calendar, BadgeCheck, User } from 'lucide-react';

interface PrivacyPolicyViewProps {
  onBack: () => void;
}

const PrivacyPolicyView: React.FC<PrivacyPolicyViewProps> = ({ onBack }) => {
  return (
    <div className="flex-1 overflow-y-auto px-6 pb-40 bg-emerald-950 animate-in fade-in duration-700 font-inter">
      {/* Back to Home Button */}
      <div className="pt-8 pb-4">
        <button 
          onClick={onBack}
          className="flex items-center gap-2 px-4 py-2 bg-emerald-900/50 border border-[#C5A059]/30 rounded-xl text-[#C5A059] font-black text-[10px] uppercase tracking-widest hover:bg-emerald-800 transition-all active:scale-95"
        >
          <ChevronLeft size={14} />
          Back to Home
        </button>
      </div>

      <div className="py-8 mb-4">
        <h2 className="text-3xl font-black text-white tracking-tighter uppercase leading-none">
          📜 Privacy & <span className="text-[#C5A059]">Data Security</span>
        </h2>
        <div className="flex flex-wrap gap-3 mt-4">
          <div className="flex items-center gap-1.5 px-3 py-1 bg-emerald-900/50 rounded-full border border-emerald-800">
            <Calendar size={10} className="text-emerald-400" />
            <span className="text-[8px] text-emerald-400 font-black uppercase tracking-widest">Last Updated: Feb 27, 2026</span>
          </div>
          <div className="flex items-center gap-1.5 px-3 py-1 bg-emerald-900/50 rounded-full border border-emerald-800">
            <BadgeCheck size={10} className="text-emerald-400" />
            <span className="text-[8px] text-emerald-400 font-black uppercase tracking-widest">Compliance: Standard Web Security</span>
          </div>
        </div>
      </div>

      <div className="space-y-6">
        {/* Guest Experience */}
        <div className="p-8 bg-emerald-900/30 rounded-[3rem] border border-emerald-800 relative overflow-hidden group">
          <div className="flex items-center gap-4 mb-6 relative z-10">
            <div className="p-3 bg-emerald-800 rounded-2xl text-emerald-400">
              <User size={20} />
            </div>
            <h3 className="font-black text-white text-sm uppercase tracking-widest">Guest Experience</h3>
          </div>
          <div className="space-y-4 text-xs text-emerald-100/70 leading-relaxed relative z-10">
            <p>
              <strong>Feature:</strong> Guest Exploration
            </p>
            <p>
              <strong>How to use:</strong> Click 'Start Exploring' on the home page to enter the ecosystem without an account.
            </p>
            <p>
              <strong>Limitations:</strong> Data entered in Guest Mode is stored in local memory only and will be lost upon closing the browser or clearing your cache.
            </p>
            <p>
              <strong>Conversion:</strong> You can upgrade to a full account at any time by clicking the 'Join Ummah' button in the floating footer or via the Identity Portal.
            </p>
          </div>
        </div>

        {/* 1. What Data We Collect */}
        <div className="p-8 bg-emerald-900/30 rounded-[3rem] border border-emerald-800 relative overflow-hidden group">
          <div className="flex items-center gap-4 mb-6 relative z-10">
            <div className="p-3 bg-emerald-800 rounded-2xl text-emerald-400">
              <Shield size={20} />
            </div>
            <h3 className="font-black text-white text-sm uppercase tracking-widest">1. What Data We Collect</h3>
          </div>
          <p className="text-xs text-emerald-100/70 leading-relaxed mb-4 relative z-10">
            We only collect information that you explicitly provide to us through our input fields. This includes:
          </p>
          <ul className="space-y-3 relative z-10">
            <li className="flex gap-3 text-xs text-emerald-100/60">
              <span className="text-emerald-400 font-bold">•</span>
              <span><strong className="text-white uppercase text-[10px]">Account Information:</strong> Your email address and encrypted password used for authentication.</span>
            </li>
            <li className="flex gap-3 text-xs text-emerald-100/60">
              <span className="text-emerald-400 font-bold">•</span>
              <span><strong className="text-white uppercase text-[10px]">Profile Data:</strong> Any information you enter into the "User Data" fields (Name, Bio, Website, etc.).</span>
            </li>
            <li className="flex gap-3 text-xs text-emerald-100/60">
              <span className="text-emerald-400 font-bold">•</span>
              <span><strong className="text-white uppercase text-[10px]">Technical Logs:</strong> Basic information like your IP address and browser type, which helps us prevent bot attacks.</span>
            </li>
          </ul>
        </div>

        {/* 2. How Your Data is Protected */}
        <div className="p-8 bg-emerald-900/30 rounded-[3rem] border border-emerald-800 relative overflow-hidden group">
          <div className="flex items-center gap-4 mb-6 relative z-10">
            <div className="p-3 bg-emerald-800 rounded-2xl text-emerald-400">
              <Lock size={20} />
            </div>
            <h3 className="font-black text-white text-sm uppercase tracking-widest">2. How Your Data is Protected</h3>
          </div>
          <p className="text-xs text-emerald-100/70 leading-relaxed mb-4 relative z-10">
            Your security is our priority. We use a multi-layered defense system:
          </p>
          <ul className="space-y-3 relative z-10">
            <li className="flex gap-3 text-xs text-emerald-100/60">
              <span className="text-emerald-400 font-bold">•</span>
              <span><strong className="text-white uppercase text-[10px]">Encryption at Rest:</strong> Your data is stored in a PostgreSQL database (Supabase) protected by AES-256 encryption.</span>
            </li>
            <li className="flex gap-3 text-xs text-emerald-100/60">
              <span className="text-emerald-400 font-bold">•</span>
              <span><strong className="text-white uppercase text-[10px]">Encryption in Transit:</strong> All data sent between your browser and our server is encrypted via HTTPS/TLS.</span>
            </li>
            <li className="flex gap-3 text-xs text-emerald-100/60">
              <span className="text-emerald-400 font-bold">•</span>
              <span><strong className="text-white uppercase text-[10px]">Password Hashing:</strong> We never see your actual password. It is scrambled using the Bcrypt algorithm before it ever hits our database.</span>
            </li>
            <li className="flex gap-3 text-xs text-emerald-100/60">
              <span className="text-emerald-400 font-bold">•</span>
              <span><strong className="text-white uppercase text-[10px]">Row Level Security (RLS):</strong> Our database rules ensure that only you can query or modify your specific data rows.</span>
            </li>
          </ul>
        </div>

        {/* 3. Cookies and Sessions */}
        <div className="p-8 bg-emerald-900/30 rounded-[3rem] border border-emerald-800 relative overflow-hidden group">
          <div className="flex items-center gap-4 mb-6 relative z-10">
            <div className="p-3 bg-emerald-800 rounded-2xl text-emerald-400">
              <Cookie size={20} />
            </div>
            <h3 className="font-black text-white text-sm uppercase tracking-widest">3. Cookies and Sessions</h3>
          </div>
          <p className="text-xs text-emerald-100/70 leading-relaxed mb-4 relative z-10">
            We use "Essential Cookies" to keep you logged in.
          </p>
          <ul className="space-y-3 relative z-10">
            <li className="flex gap-3 text-xs text-emerald-100/60">
              <span className="text-emerald-400 font-bold">•</span>
              <span>These are small text files stored in your browser.</span>
            </li>
            <li className="flex gap-3 text-xs text-emerald-100/60">
              <span className="text-emerald-400 font-bold">•</span>
              <span>They do not track your movement across other websites.</span>
            </li>
            <li className="flex gap-3 text-xs text-emerald-100/60">
              <span className="text-emerald-400 font-bold">•</span>
              <span>They expire automatically when you log out or after a period of inactivity.</span>
            </li>
          </ul>
        </div>

        {/* 4. Your Rights (Data Control) */}
        <div className="p-8 bg-emerald-900/30 rounded-[3rem] border border-emerald-800 relative overflow-hidden group">
          <div className="flex items-center gap-4 mb-6 relative z-10">
            <div className="p-3 bg-emerald-800 rounded-2xl text-emerald-400">
              <Folder size={20} />
            </div>
            <h3 className="font-black text-white text-sm uppercase tracking-widest">4. Your Rights (Data Control)</h3>
          </div>
          <p className="text-xs text-emerald-100/70 leading-relaxed mb-4 relative z-10">
            Under our policy, you have the following rights:
          </p>
          <ul className="space-y-3 relative z-10">
            <li className="flex gap-3 text-xs text-emerald-100/60">
              <span className="text-emerald-400 font-bold">•</span>
              <span><strong className="text-white uppercase text-[10px]">The Right to Access:</strong> You can view all data we have stored about you on your Profile page.</span>
            </li>
            <li className="flex gap-3 text-xs text-emerald-100/60">
              <span className="text-emerald-400 font-bold">•</span>
              <span><strong className="text-white uppercase text-[10px]">The Right to Erasure:</strong> You may request that we delete your account and all associated data from our Supabase tables at any time.</span>
            </li>
            <li className="flex gap-3 text-xs text-emerald-100/60">
              <span className="text-emerald-400 font-bold">•</span>
              <span><strong className="text-white uppercase text-[10px]">The Right to Correction:</strong> You can update any incorrect information directly through the input fields.</span>
            </li>
          </ul>
        </div>
      </div>

      <div className="mt-16 text-center">
         <ShieldCheck size={24} className="text-emerald-800 mx-auto mb-4" />
         <p className="text-[9px] text-emerald-700 font-black uppercase tracking-[0.4em]">Prophetic Ethics • Since 2026</p>
      </div>
    </div>
  );
};

export default PrivacyPolicyView;
