
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Heart, MessageSquare, Share2, Send, Shield, AlertTriangle, Sparkles, User } from 'lucide-react';
import { UserProfile } from '../types';

interface Post {
  id: string;
  author: {
    name: string;
    avatarColor: string;
  };
  content: string;
  type: 'general' | 'dua' | 'event';
  timestamp: string;
  subhanAllahCount: number;
  ameenCount: number;
  comments: number;
}

interface UmmahWallViewProps {
  user: UserProfile | null;
}

const UmmahWallView: React.FC<UmmahWallViewProps> = ({ user }) => {
  const [posts, setPosts] = useState<Post[]>([
    {
      id: '1',
      author: { name: 'Ahmed', avatarColor: 'bg-emerald-600' },
      content: 'Assalamu Alaikum! Does anyone know of any community service projects this weekend? Looking to help out.',
      type: 'general',
      timestamp: '2h ago',
      subhanAllahCount: 12,
      ameenCount: 0,
      comments: 3
    },
    {
      id: '2',
      author: { name: 'Fatima', avatarColor: 'bg-amber-600' },
      content: 'Please keep my grandmother in your Duas, she is feeling unwell and going for surgery tomorrow.',
      type: 'dua',
      timestamp: '4h ago',
      subhanAllahCount: 0,
      ameenCount: 45,
      comments: 8
    },
    {
      id: '3',
      author: { name: 'Community Center', avatarColor: 'bg-blue-600' },
      content: 'Youth Halaqa this Friday after Maghrib. Topic: Finding Balance in the Modern World. All are welcome!',
      type: 'event',
      timestamp: '6h ago',
      subhanAllahCount: 8,
      ameenCount: 0,
      comments: 2
    }
  ]);

  const [newPost, setNewPost] = useState('');
  const [postType, setPostType] = useState<'general' | 'dua' | 'event'>('general');

  const handlePost = () => {
    if (!newPost.trim()) return;
    if (user?.isGuest) {
      alert('You are viewing as a guest. Please sign up to post!');
      return;
    }

    const post: Post = {
      id: Date.now().toString(),
      author: { 
        name: user?.firstName || 'User', 
        avatarColor: user?.avatarColor || 'bg-emerald-700' 
      },
      content: newPost,
      type: postType,
      timestamp: 'Just now',
      subhanAllahCount: 0,
      ameenCount: 0,
      comments: 0
    };

    setPosts([post, ...posts]);
    setNewPost('');
  };

  return (
    <div className="flex-1 overflow-y-auto px-4 pb-32 pt-6 bg-[#022c22] font-inter">
      <header className="mb-8">
        <h2 className="text-3xl font-black text-white tracking-tighter uppercase leading-none">
          Ummah <span className="text-[#C5A059]">Wall</span>
        </h2>
        <p className="text-[10px] text-emerald-500 font-black uppercase tracking-[0.3em] mt-2">The Digital Gathering Place</p>
      </header>

      {/* Post Creation */}
      <div className="bg-emerald-900/30 border border-emerald-800/50 rounded-3xl p-5 mb-8 backdrop-blur-sm">
        <div className="flex gap-3 mb-4">
          {(['general', 'dua', 'event'] as const).map((t) => (
            <button
              key={t}
              onClick={() => setPostType(t)}
              className={`px-4 py-2 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all ${
                postType === t 
                  ? 'bg-[#C5A059] text-emerald-950' 
                  : 'bg-emerald-950 text-emerald-600 border border-emerald-800'
              }`}
            >
              {t === 'dua' ? '🤲 Dua Request' : t === 'event' ? '📅 Event' : '📝 General'}
            </button>
          ))}
        </div>
        <textarea
          value={newPost}
          onChange={(e) => setNewPost(e.target.value)}
          placeholder={postType === 'dua' ? "Share your Dua request..." : "Share something beneficial..."}
          className="w-full bg-transparent border-none focus:ring-0 text-sm text-emerald-50 placeholder:text-emerald-800 resize-none h-24 font-medium"
        />
        <div className="flex justify-end mt-2 pt-4 border-t border-emerald-800/30">
          <button 
            onClick={handlePost}
            className="btn-gold px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest flex items-center gap-2"
          >
            <Send size={14} />
            Post to Wall
          </button>
        </div>
      </div>

      {/* Feed */}
      <div className="space-y-4">
        <AnimatePresence>
          {posts.map((post) => (
            <motion.div
              key={post.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-emerald-900/20 border border-emerald-800/30 rounded-3xl p-6 relative overflow-hidden group"
            >
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 ${post.author.avatarColor} rounded-2xl flex items-center justify-center text-white font-black text-xs shadow-lg`}>
                    {post.author.name[0]}
                  </div>
                  <div>
                    <h4 className="text-sm font-black text-white uppercase tracking-tight">{post.author.name}</h4>
                    <p className="text-[9px] text-emerald-600 font-bold uppercase tracking-widest">{post.timestamp}</p>
                  </div>
                </div>
                {post.type === 'dua' && (
                  <div className="bg-blue-500/10 border border-blue-500/30 px-3 py-1 rounded-full">
                    <span className="text-[8px] text-blue-400 font-black uppercase tracking-widest">Dua Request</span>
                  </div>
                )}
              </div>

              <p className="text-sm text-emerald-100/90 leading-relaxed font-medium mb-6">
                {post.content}
              </p>

              <div className="flex items-center gap-4 pt-4 border-t border-emerald-800/20">
                <button className="flex items-center gap-2 text-emerald-600 hover:text-[#C5A059] transition-colors">
                  <Sparkles size={16} />
                  <span className="text-[10px] font-black uppercase tracking-widest">
                    {post.type === 'dua' ? 'Ameen' : 'SubhanAllah'} ({post.type === 'dua' ? post.ameenCount : post.subhanAllahCount})
                  </span>
                </button>
                <button className="flex items-center gap-2 text-emerald-600 hover:text-white transition-colors">
                  <MessageSquare size={16} />
                  <span className="text-[10px] font-black uppercase tracking-widest">Comment ({post.comments})</span>
                </button>
                <button className="ml-auto text-emerald-800 hover:text-rose-500 transition-colors">
                  <AlertTriangle size={14} />
                </button>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default UmmahWallView;
