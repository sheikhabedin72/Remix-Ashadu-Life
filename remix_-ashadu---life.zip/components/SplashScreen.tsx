import React, { useState, useEffect } from 'react';
import { Loader2 } from 'lucide-react';

interface SplashScreenProps {
  onComplete: () => void;
}

const SplashScreen: React.FC<SplashScreenProps> = ({ onComplete }) => {
  const [phase, setPhase] = useState(0); 
  // 0: The Void (Emerald)
  // 1: The Noor (Bismillah)
  // 2: The Logo Reveal (Pulse/Scale)
  // 3: The Handshake (Loading)

  useEffect(() => {
    const timers = [
      setTimeout(() => setPhase(1), 800),   // Void -> Noor
      setTimeout(() => setPhase(2), 2200),  // Noor -> Logo Reveal
      setTimeout(() => setPhase(3), 4500),  // Logo -> Handshake
      setTimeout(onComplete, 6500),         // Completion
    ];
    return () => timers.forEach(t => clearTimeout(t));
  }, [onComplete]);

  return (
    <div className="fixed inset-0 z-[1000] bg-[#022c22] flex flex-col items-center justify-center overflow-hidden font-inter">
      {/* 1. THE VOID: Background is the deep emerald container */}
      <div className="absolute inset-0 celestial-grid opacity-10 pointer-events-none" />
      
      {/* 2. THE NOOR: Elegant Gold Calligraphy */}
      <div className={`transition-all duration-[1500ms] text-center absolute top-1/4 ${phase >= 1 ? 'opacity-30 translate-y-0' : 'opacity-0 translate-y-10'}`}>
        <h1 className="arabic text-3xl md:text-5xl text-[#C5A059] tracking-widest px-8">
          بِسْمِ اللهِ الرَّحْمٰنِ الرَّحِيْمِ
        </h1>
      </div>

      {/* 3. THE LOGO REVEAL: Pulse and Scale */}
      <div className={`relative flex flex-col items-center transition-all duration-1000 transform ${phase >= 2 ? 'opacity-100 scale-100' : 'opacity-0 scale-75'}`}>
        <div className="w-64 h-64 rounded-full flex items-center justify-center relative">
          {/* Animated rings for the reveal */}
          <div className={`absolute inset-0 rounded-full border border-[#C5A059]/20 transition-all duration-[2000ms] ${phase >= 2 ? 'scale-125 opacity-0' : 'scale-50 opacity-100'}`} />
          
          <div className={`p-8 bg-[#064e3b] rounded-[3rem] border border-[#C5A059]/30 shadow-2xl relative z-10 transition-transform duration-500 ${phase === 2 ? 'animate-spiritual-pulse' : ''}`}>
          </div>
          
          {/* Background Aura */}
          <div className="absolute inset-0 bg-[#C5A059]/5 blur-[60px] rounded-full animate-pulse pointer-events-none" />
        </div>

        {/* 4. THE HANDSHAKE: Database Check & Loading */}
        <div className={`mt-16 flex flex-col items-center gap-4 transition-all duration-700 ${phase >= 3 ? 'opacity-100' : 'opacity-0'}`}>
           <div className="flex items-center gap-3 bg-black/30 px-6 py-3 rounded-full border border-white/5">
              <Loader2 size={16} className="text-[#C5A059] animate-spin" />
              <span className="text-[10px] font-black uppercase text-[#C5A059] tracking-[0.3em]">Syncing Permanent Ledger</span>
           </div>
           <p className="text-[8px] font-black uppercase text-emerald-800 tracking-[0.5em]">ASHADU CORE v2.5.0-GOLD</p>
        </div>
      </div>

      <style>{`
        @keyframes spiritual-pulse {
          0% { transform: scale(1); }
          50% { transform: scale(1.05); filter: brightness(1.2); }
          100% { transform: scale(1); }
        }
        .animate-spiritual-pulse {
          animation: spiritual-pulse 2s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
};

export default SplashScreen;