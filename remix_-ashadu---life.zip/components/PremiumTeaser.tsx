
import React from 'react';
import { Sparkles, Crown, Heart, BarChart3, ShieldCheck, X } from 'lucide-react';
import { SubscriptionTier } from '../types';

interface PremiumTeaserProps {
  onClose: () => void;
  onUpgrade: (tier: SubscriptionTier) => void;
  price: string;
}

const PremiumTeaser: React.FC<PremiumTeaserProps> = ({ onClose, onUpgrade, price }) => {
  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-xl flex items-center justify-center z-[500] p-6 animate-in fade-in duration-300">
      <div className="max-w-md w-full bg-gradient-to-b from-emerald-900 to-black border border-amber-500/50 rounded-[3rem] p-10 text-center relative overflow-hidden shadow-[0_0_80px_rgba(251,191,36,0.3)]">
        
        {/* Background Aura */}
        <div className="absolute -top-10 -right-10 w-48 h-48 bg-amber-500/10 rounded-full blur-3xl animate-pulse" />
        
        <div className="w-24 h-24 mx-auto mb-8 bg-amber-500 rounded-full flex items-center justify-center shadow-[0_0_40px_#fbbf24] animate-bounce">
          <span className="text-4xl">✨</span>
        </div>

        <h2 className="text-3xl font-black text-white mb-3 tracking-tight">Unlock the Muhsin Tier</h2>
        <p className="text-emerald-400 text-sm mb-10 leading-relaxed font-medium">
          Support the ASHADU ecosystem. Your sponsorship covers server costs for the Ummah and unlocks the highest level of Celestial customization.
        </p>

        <ul className="text-left space-y-5 mb-10 px-4">
          <TeaserListItem icon="🌙" text="Exclusive Rose Gold & Midnight Themes" />
          <TeaserListItem icon="📉" text="3D Heartbeat & Zikr Analytics" />
          <TeaserListItem icon="🛡️" text="Verified 'Muhsin' Badge on the Noor Map" />
          <TeaserListItem icon="💧" text="10% of your fee goes to Sadaqah Jariyah" />
        </ul>

        <div className="space-y-4">
          <button 
            onClick={() => onUpgrade('MUHSIN')}
            className="w-full bg-amber-500 hover:bg-white text-black font-black py-5 rounded-2xl transition-all transform active:scale-95 shadow-[0_0_20px_rgba(251,191,36,0.4)] uppercase tracking-[0.2em] text-[11px]"
          >
            BECOME A PATRON — £{price}/mo
          </button>
          
          <button 
            onClick={onClose}
            className="text-white/40 text-[10px] font-black uppercase tracking-widest hover:text-white transition-colors"
          >
            Maybe later, I'll stick to the Abid Tier
          </button>
        </div>
        
        {/* Guard Notice */}
        <div className="mt-8 pt-6 border-t border-white/5 flex justify-center items-center gap-2">
            <ShieldCheck size={12} className="text-amber-500/40" />
            <span className="text-[8px] font-black uppercase tracking-widest text-white/20">Secure Server-Side Verification</span>
        </div>
      </div>
    </div>
  );
};

const TeaserListItem = ({ icon, text }: { icon: string, text: string }) => (
  <li className="flex items-center gap-4 text-sm text-white/80 font-bold group">
    <span className="text-amber-500 text-lg transition-transform group-hover:scale-125">{icon}</span>
    <span className="tracking-tight">{text}</span>
  </li>
);

export default PremiumTeaser;
