import React, { useState } from 'react';
import { 
  Store, 
  Package, 
  Ticket, 
  BarChart3, 
  ChevronLeft, 
  X, 
  Check, 
  Plus, 
  Trash2, 
  Info,
  ShieldCheck,
  Building2,
  FileText,
  MapPin,
  Save,
  Percent,
  Coins,
  Users,
  AlertTriangle,
  Lock,
  Mail,
  ShieldAlert,
  BadgeCheck
} from 'lucide-react';
import { UserProfile } from '../types';

interface MerchantPortalProps {
  profile: UserProfile | null;
  onUpdateProfile: (p: UserProfile) => void;
  onClose: () => void;
}

const MerchantPortal: React.FC<MerchantPortalProps> = ({ profile, onUpdateProfile, onClose }) => {
  const [activeTab, setActiveTab] = useState<'profile' | 'products' | 'coupons' | 'sales'>('profile');
  const [formData, setFormData] = useState({
    businessName: profile?.businessName || '',
    businessBio: profile?.businessBio || '',
    city: profile?.city || '',
    zipcode: profile?.zipcode || ''
  });
  
  const [couponCode, setCouponCode] = useState('');
  const [couponType, setCouponType] = useState<'PERCENT' | 'FIXED'>('PERCENT');
  const [couponValue, setCouponValue] = useState(10);
  const [isSaved, setIsSaved] = useState(false);
  const [isVerifying, setIsVerifying] = useState(false);

  const handleSaveInfo = () => {
    if (!profile) return;
    const updated: UserProfile = {
      ...profile,
      ...formData
    };
    onUpdateProfile(updated);
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2000);
  };

  const handleResendVerification = () => {
    setIsVerifying(true);
    setTimeout(() => {
      setIsVerifying(false);
      alert(`Verification link re-sent to ${profile?.email}. Link expires in 24 hours.`);
    }, 1500);
  };

  const handleGenerateCoupon = () => {
    if (!profile?.isEmailVerified) return;
    if (!couponCode) return;
    alert(`Success: Coupon ${couponCode.toUpperCase()} generated with ${couponValue}${couponType === 'PERCENT' ? '%' : '£'} discount.`);
    setCouponCode('');
  };

  const isVerified = profile?.isEmailVerified;
  const isFrozen = profile?.isFrozen;

  if (isFrozen) {
    return (
      <div className="h-full flex flex-col items-center justify-center bg-black p-8 text-center">
         <ShieldAlert size={80} className="text-red-500 mb-8 animate-pulse" />
         <h1 className="text-3xl font-black mb-4 uppercase tracking-tighter text-white">Establishment Frozen</h1>
         <p className="text-red-400 text-sm leading-relaxed max-w-xs mx-auto mb-8">
           This shop has been temporarily suspended by ASHADU administration. Please contact the Super-Admin for details.
         </p>
         <button onClick={onClose} className="px-8 py-4 bg-white/5 border border-white/10 rounded-2xl text-[10px] font-black uppercase text-white hover:bg-white/10 transition-all">Exit Portal</button>
      </div>
    );
  }

  return (
    <div className="h-full flex bg-emerald-950 text-white overflow-hidden animate-in fade-in duration-500">
      {/* Sidebar */}
      <aside className="w-20 lg:w-64 bg-black/40 border-r border-emerald-900/40 p-4 lg:p-6 flex flex-col transition-all">
        <div className="mb-12 text-center">
            <div className="w-12 h-12 bg-amber-500/10 rounded-2xl flex items-center justify-center text-amber-500 mx-auto mb-3 border border-amber-500/20">
                <Store size={24} />
            </div>
            <p className="hidden lg:block text-[9px] text-amber-500 font-black tracking-widest uppercase">Merchant Portal</p>
        </div>
        
        <nav className="flex-1 space-y-2 lg:space-y-4">
            <MerchantNavBtn active={activeTab === 'profile'} onClick={() => setActiveTab('profile')} icon={<Building2 size={20} />} label="Shop Profile" />
            <MerchantNavBtn active={activeTab === 'products'} onClick={() => setActiveTab('products')} icon={<Package size={20} />} label="My Products" />
            <MerchantNavBtn active={activeTab === 'coupons'} onClick={() => setActiveTab('coupons')} icon={<Ticket size={20} />} label="Coupons" />
            <MerchantNavBtn active={activeTab === 'sales'} onClick={() => setActiveTab('sales')} icon={<BarChart3 size={20} />} label="Sales Ledger" />
        </nav>

        <button onClick={onClose} className="mt-auto flex items-center gap-3 p-4 text-emerald-500 hover:text-white transition-colors lg:w-full">
            <ChevronLeft size={20} />
            <span className="hidden lg:inline text-[9px] font-black uppercase tracking-widest">Exit Portal</span>
        </button>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-6 lg:p-12 overflow-y-auto pb-32">
        {!isVerified && (
          <div className="mb-10 p-6 bg-amber-500/10 border border-amber-500/30 rounded-3xl flex flex-col lg:flex-row items-center justify-between gap-6 animate-in slide-in-from-top-4">
             <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-amber-500/20 rounded-2xl flex items-center justify-center text-amber-500">
                    <Mail size={24} />
                </div>
                <div>
                   <h4 className="font-black text-amber-500 uppercase text-xs tracking-widest">Action Required: Verify Email</h4>
                   <p className="text-[10px] text-amber-200/60 mt-1">Unlock the Sadaqa Coupon Engine & Sales Ledger by verifying your identity.</p>
                </div>
             </div>
             <button 
                onClick={handleResendVerification}
                disabled={isVerifying}
                className="bg-amber-500 text-emerald-950 px-6 py-3 rounded-xl text-[9px] font-black uppercase tracking-widest hover:bg-amber-400 transition-all active:scale-95 disabled:opacity-50"
             >
                {isVerifying ? 'Sending...' : 'Resend Link'}
             </button>
          </div>
        )}

        <header className="mb-12 flex justify-between items-start">
            <div>
                <h2 className="text-3xl font-black tracking-tighter uppercase">{activeTab === 'profile' ? 'Establishment Setup' : activeTab.replace('-', ' ')}</h2>
                <p className="text-[10px] text-emerald-400 uppercase font-black tracking-[0.3em] mt-2">Manage your business within ASHADU</p>
            </div>
            <div className="flex items-center gap-4">
                {profile?.hasTrustBadge && (
                    <div className="flex items-center gap-2 bg-cyan-500/10 px-4 py-2 rounded-xl border border-cyan-500/30 shadow-[0_0_15px_rgba(34,211,238,0.1)]">
                        <BadgeCheck size={14} className="text-cyan-400" />
                        <span className="text-[8px] font-black uppercase tracking-widest text-cyan-500">Verified Ameen</span>
                    </div>
                )}
                <div className="flex items-center gap-2 bg-emerald-900/50 px-4 py-2 rounded-xl border border-emerald-800">
                    <ShieldCheck size={14} className="text-emerald-400" />
                    <span className="text-[8px] font-black uppercase tracking-widest text-emerald-500">Shop Identity Verified</span>
                </div>
            </div>
        </header>

        {activeTab === 'profile' && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 animate-in slide-in-from-right-4 duration-500">
                <section className="bg-black/20 border border-emerald-900 p-8 rounded-[3rem] space-y-8">
                    <div className="flex items-center gap-3">
                        <FileText className="text-amber-500" size={18} />
                        <h3 className="text-amber-500 text-[10px] font-black uppercase tracking-widest">Business Information</h3>
                    </div>
                    <div className="space-y-5">
                        <div className="space-y-2">
                            <label className="text-[9px] font-black uppercase text-emerald-600 tracking-widest ml-1">Establishment Name</label>
                            <input 
                                type="text" 
                                placeholder="e.g. Medina Scented" 
                                value={formData.businessName}
                                onChange={e => setFormData({...formData, businessName: e.target.value})}
                                className="w-full bg-emerald-900/40 border border-emerald-800 rounded-2xl p-5 text-sm font-bold text-white outline-none focus:border-amber-500 transition-all"
                            />
                        </div>
                        <div className="space-y-2">
                            <label className="text-[9px] font-black uppercase text-emerald-600 tracking-widest ml-1">Business Bio</label>
                            <textarea 
                                placeholder="The story behind your craft..." 
                                value={formData.businessBio}
                                onChange={e => setFormData({...formData, businessBio: e.target.value})}
                                className="w-full bg-emerald-900/40 border border-emerald-800 rounded-2xl p-5 text-sm font-bold text-white outline-none focus:border-amber-500 transition-all h-32 resize-none"
                            />
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-2">
                                <label className="text-[9px] font-black uppercase text-emerald-600 tracking-widest ml-1">City</label>
                                <input 
                                    type="text" 
                                    placeholder="London" 
                                    value={formData.city}
                                    onChange={e => setFormData({...formData, city: e.target.value})}
                                    className="w-full bg-emerald-900/40 border border-emerald-800 rounded-2xl p-5 text-sm font-bold text-white outline-none focus:border-amber-500 transition-all"
                                />
                            </div>
                            <div className="space-y-2">
                                <label className="text-[9px] font-black uppercase text-emerald-600 tracking-widest ml-1">Zipcode</label>
                                <input 
                                    type="text" 
                                    placeholder="E1 6AN" 
                                    value={formData.zipcode}
                                    onChange={e => setFormData({...formData, zipcode: e.target.value})}
                                    className="w-full bg-emerald-900/40 border border-emerald-800 rounded-2xl p-5 text-sm font-bold text-white outline-none focus:border-amber-500 transition-all"
                                />
                            </div>
                        </div>
                    </div>
                    <button 
                        onClick={handleSaveInfo}
                        className={`w-full py-5 rounded-2xl font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-2 transition-all shadow-xl active:scale-95 ${isSaved ? 'bg-emerald-500 text-white' : 'bg-amber-500 text-emerald-950 shadow-amber-500/10'}`}
                    >
                        {isSaved ? <><Check size={16} /> Identity Synchronized</> : <><Save size={16} /> Save Establishment Info</>}
                    </button>
                </section>

                <section className="bg-black/20 border border-emerald-900 p-8 rounded-[3rem] space-y-8 flex flex-col">
                    <div className="flex items-center gap-3">
                        <Percent className="text-amber-500" size={18} />
                        <h3 className="text-amber-500 text-[10px] font-black uppercase tracking-widest">Sadaqah Split</h3>
                    </div>
                    <div className="bg-emerald-950/50 p-6 rounded-2xl border border-emerald-800">
                        <p className="text-[9px] text-emerald-500 font-black uppercase tracking-widest mb-4">Commission Level</p>
                        <h3 className="text-3xl font-black text-white font-mono">{profile?.commissionRate || 10}%</h3>
                        <p className="text-[10px] text-emerald-600 font-medium mt-2 leading-relaxed italic">
                          Calculated by Admin. This amount is automatically routed to Legacy Projects upon every sale.
                        </p>
                    </div>
                    <div className="flex items-center gap-3 bg-white/5 p-5 rounded-2xl border border-white/5">
                        <Info size={16} className="text-emerald-500" />
                        <p className="text-[9px] text-emerald-300 font-bold uppercase tracking-widest leading-relaxed">
                          Your "Trust Rating" is based on the precision of these contributions over time.
                        </p>
                    </div>
                </section>
            </div>
        )}

        {activeTab === 'coupons' && (
            <div className="max-w-2xl mx-auto animate-in slide-in-from-right-4">
                {!isVerified ? (
                    <div className="bg-black/40 border border-emerald-900 p-20 rounded-[3rem] text-center">
                        <Lock size={48} className="text-amber-500 mx-auto mb-6 opacity-30" />
                        <h3 className="text-xl font-black text-white uppercase tracking-tighter">Coupon Engine Locked</h3>
                        <p className="text-stone-500 text-xs mt-2 font-medium">Verify your email address to generate discount codes for your customers.</p>
                        <button onClick={handleResendVerification} className="mt-8 text-[9px] font-black uppercase text-amber-500 tracking-widest underline decoration-2 underline-offset-4">Resend Link</button>
                    </div>
                ) : (
                    <section className="bg-black/20 border border-emerald-900 p-10 rounded-[3rem] space-y-8 flex flex-col">
                        <div className="flex items-center gap-3">
                            <Ticket className="text-amber-500" size={18} />
                            <h3 className="text-amber-500 text-[10px] font-black uppercase tracking-widest">Coupon Engine</h3>
                        </div>
                        
                        <div className="space-y-6 flex-1">
                            <div className="p-10 bg-emerald-950/50 rounded-2xl border border-emerald-800 text-center">
                                <p className="text-[9px] text-emerald-500 font-black uppercase tracking-widest mb-2">Live Preview</p>
                                <div className="bg-amber-500 text-emerald-950 inline-block px-4 py-2 rounded-lg font-mono font-black text-3xl tracking-tighter">
                                    {couponCode.toUpperCase() || 'CODE'}
                                </div>
                                <p className="text-lg font-bold mt-4 text-white">Save {couponValue}{couponType === 'PERCENT' ? '%' : '£'} Today</p>
                            </div>

                            <div className="space-y-2">
                                <label className="text-[9px] font-black uppercase text-emerald-600 tracking-widest ml-1">Coupon Code</label>
                                <input 
                                    type="text" 
                                    placeholder="e.g. BARAKAH10" 
                                    value={couponCode}
                                    onChange={e => setCouponCode(e.target.value)}
                                    className="w-full bg-emerald-900/40 border border-emerald-800 rounded-2xl p-5 text-sm font-mono font-black text-white outline-none focus:border-amber-500 transition-all uppercase"
                                />
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                                <div className="space-y-2">
                                    <label className="text-[9px] font-black uppercase text-emerald-600 tracking-widest ml-1">Discount Type</label>
                                    <select 
                                        value={couponType}
                                        onChange={e => setCouponType(e.target.value as any)}
                                        className="w-full bg-emerald-900/40 border border-emerald-800 rounded-2xl p-5 text-sm font-bold text-white outline-none focus:border-amber-500 transition-all appearance-none"
                                    >
                                        <option value="PERCENT">Percentage (%)</option>
                                        <option value="FIXED">Fixed (£)</option>
                                    </select>
                                </div>
                                <div className="space-y-2">
                                    <label className="text-[9px] font-black uppercase text-emerald-600 tracking-widest ml-1">Value</label>
                                    <input 
                                        type="number" 
                                        value={couponValue}
                                        onChange={e => setCouponValue(parseInt(e.target.value))}
                                        className="w-full bg-emerald-900/40 border border-emerald-800 rounded-2xl p-5 text-sm font-black text-white outline-none focus:border-amber-500 transition-all"
                                    />
                                </div>
                            </div>
                        </div>

                        <button 
                            onClick={handleGenerateCoupon}
                            className="w-full bg-amber-500 hover:bg-amber-400 text-emerald-950 border-none py-6 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all flex items-center justify-center gap-2 active:scale-95 shadow-xl"
                        >
                            <Plus size={16} /> Generate Coupon
                        </button>
                    </section>
                )}
            </div>
        )}

        {activeTab === 'products' && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-in slide-in-from-right-4 duration-500">
                <div className="bg-emerald-900/20 border-2 border-dashed border-emerald-800 rounded-[2.5rem] p-8 flex flex-col items-center justify-center gap-4 group hover:border-amber-500/30 transition-all cursor-pointer">
                    <div className="w-16 h-16 rounded-full bg-emerald-900 flex items-center justify-center text-emerald-600 group-hover:text-amber-500 transition-colors">
                        <Plus size={32} />
                    </div>
                    <p className="text-[10px] font-black uppercase tracking-widest text-emerald-700 group-hover:text-white transition-colors">Add New Craft</p>
                </div>
                {/* Mock Products */}
                <MerchantProductCard name="Onyx Stone Tasbih" price={24.00} sales={142} />
                <MerchantProductCard name="Pure Oud Attar" price={18.00} sales={89} />
            </div>
        )}

        {activeTab === 'sales' && (
            <div className="space-y-8 animate-in slide-in-from-right-4">
                {!isVerified ? (
                    <div className="bg-black/40 border border-emerald-900 p-20 rounded-[3rem] text-center">
                        <Lock size={48} className="text-amber-500 mx-auto mb-6 opacity-30" />
                        <h3 className="text-xl font-black text-white uppercase tracking-tighter">Ledger Restricted</h3>
                        <p className="text-stone-500 text-xs mt-2 font-medium">Sales data and payouts are only accessible to verified establishments.</p>
                        <button onClick={handleResendVerification} className="mt-8 text-[9px] font-black uppercase text-amber-500 tracking-widest underline decoration-2 underline-offset-4">Verify Identity</button>
                    </div>
                ) : (
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <AdminStatCard icon={<Coins size={24} />} label="Total Revenue" value="£2,450.00" delta="+12% this month" color="text-amber-500" />
                        <AdminStatCard icon={<Percent size={24} />} label="Sadaqa Shared" value="£342.10" delta="14% average" color="text-emerald-500" />
                        <AdminStatCard icon={<Users size={24} />} label="Customers" value="231" delta="+4 today" color="text-blue-400" />
                    </div>
                )}
            </div>
        )}
      </main>
    </div>
  );
};

const MerchantNavBtn = ({ active, onClick, icon, label }: any) => (
  <button onClick={onClick} className={`w-full flex items-center gap-4 p-4 rounded-2xl transition-all group ${active ? 'bg-amber-500 text-emerald-950 font-black shadow-xl' : 'text-emerald-500 hover:bg-emerald-900/40'}`}>
    <div className={`transition-transform group-hover:scale-110 ${active ? 'text-emerald-950' : 'text-emerald-400'}`}>{icon}</div>
    <span className="hidden lg:inline text-[9px] uppercase tracking-widest leading-none text-left">{label}</span>
  </button>
);

const MerchantProductCard = ({ name, price, sales }: any) => (
    <div className="bg-emerald-900/40 border border-emerald-800 p-6 rounded-[2.5rem] flex flex-col group hover:border-amber-500/20 transition-all">
        <div className="h-32 bg-emerald-950 rounded-2xl mb-4 flex items-center justify-center text-4xl group-hover:scale-105 transition-transform">📦</div>
        <h4 className="font-black text-sm text-white">{name}</h4>
        <p className="text-amber-500 font-mono font-black text-sm mt-1">£{price.toFixed(2)}</p>
        <div className="mt-4 flex justify-between items-center border-t border-emerald-800 pt-4">
            <span className="text-[8px] font-black uppercase text-emerald-600 tracking-widest">{sales} Sold</span>
            <div className="flex gap-2">
                <button className="p-2 text-emerald-500 hover:text-white transition-colors"><FileText size={16} /></button>
                <button className="p-2 text-red-400 hover:text-red-300 transition-colors"><Trash2 size={16} /></button>
            </div>
        </div>
    </div>
);

const AdminStatCard = ({ icon, label, value, delta, color = "text-amber-500" }: any) => (
  <div className="bg-emerald-900/10 border border-emerald-800 p-8 rounded-[2.5rem] relative overflow-hidden group hover:border-amber-500/20 transition-all">
    <div className="flex justify-between items-start mb-4 relative z-10">
       <div className={`p-4 bg-emerald-900 rounded-2xl ${color} border border-white/5 transition-transform group-hover:rotate-6`}>{icon}</div>
       <span className="text-[7px] font-black text-emerald-500 bg-emerald-950 px-2 py-1 rounded-full uppercase tracking-widest border border-emerald-800">{delta}</span>
    </div>
    <div className="relative z-10">
      <p className="text-[9px] font-black text-emerald-700 uppercase tracking-widest mb-1">{label}</p>
      <h4 className="text-3xl font-black text-white font-mono tracking-tighter">{value}</h4>
    </div>
  </div>
);

export default MerchantPortal;