
import React from 'react';
import { 
  ShieldCheck, 
  Target, 
  Clock, 
  ChevronRight, 
  X, 
  Check, 
  Heart, 
  Coins, 
  Users,
  Zap,
  Radio
} from 'lucide-react';
import { Invitation, DonationPillar } from '../types';

interface InvitationPortalProps {
  invitationData: Invitation;
  onAccept: (inviteId: string) => void;
  onReject: (inviteId: string) => void;
}

const InvitationPortal: React.FC<InvitationPortalProps> = ({ invitationData, onAccept, onReject }) => {
  const getPillarLabel = (pillar: DonationPillar) => {
    switch (pillar) {
      case 'PENNY_PER_ZIKR': return "1 Penny Per Zikr Contribution";
      case 'PROXY_ZIKR': return "Proxy Zikr (Sponsor Sponsored)";
      case 'ZIKR_ONLY': return "Zikr Focused (No Mandatory Donation)";
      case 'DIRECT': return "Direct Charity Connection";
      case 'PER_USER': return "Community Density Trigger";
      case 'ZIKR_AND_DONATE': return "Remembrance + Voluntary Sadaqah";
      // Fix: Cast pillar to string as it's inferred as never in an exhaustive switch
      default: return (pillar as string).replace(/_/g, ' ');
    }
  };

  const getPillarIcon = (pillar: DonationPillar) => {
    switch (pillar) {
      case 'PENNY_PER_ZIKR': return <Coins size={16} />;
      case 'PROXY_ZIKR': return <ShieldCheck size={16} />;
      case 'ZIKR_ONLY': return <Zap size={16} />;
      default: return <Heart size={16} />;
    }
  };

  return (
    <div className="fixed inset-0 z-[1000] flex items-center justify-center p-6 bg-[#022c22]/90 backdrop-blur-3xl animate-in fade-in duration-500 font-inter">
      <div className="w-full max-w-md bg-emerald-900/30 border border-[#C5A059]/40 rounded-[3.5rem] p-8 md:p-12 shadow-[0_30px_100px_rgba(0,0,0,0.6)] relative overflow-hidden animate-in zoom-in-95 duration-700">
        
        {/* Background Flourish */}
        <div className="absolute top-0 right-0 p-10 opacity-[0.03] rotate-12 pointer-events-none">
          <Users size={320} className="text-white" />
        </div>

        <div className="text-center mb-8">
          <h1 className="arabic text-3xl text-[#C5A059] mb-6 drop-shadow-lg">بِسْمِ اللهِ الرَّحْمٰنِ الرَّحِيْمِ</h1>
          
          <div className="flex flex-col items-center mb-6">
            <div className="w-16 h-16 bg-[#C5A059]/10 rounded-2xl flex items-center justify-center text-[#C5A059] mb-4 border border-[#C5A059]/30">
              <Users size={32} />
            </div>
            <h2 className="text-2xl font-black text-white uppercase tracking-tighter">Invitation to Zikr</h2>
            <p className="text-emerald-400 text-[10px] font-black uppercase tracking-[0.3em] mt-2">
              <span className="text-[#C5A059]">{invitationData.adminName}</span> has called you
            </p>
          </div>
        </div>

        <div className="bg-black/20 border border-emerald-800/50 rounded-[2.5rem] p-6 mb-8 space-y-4">
           <div>
              <h3 className="text-lg font-black text-white tracking-tight uppercase leading-tight mb-1">{invitationData.groupName}</h3>
              <p className="text-emerald-400 text-[9px] font-bold uppercase tracking-widest italic">"{invitationData.customZikr}"</p>
           </div>
           
           <p className="text-xs text-stone-400 leading-relaxed font-medium">
             {invitationData.description}
           </p>

           <div className="grid grid-cols-2 gap-3 pt-2">
              <div className="flex items-center gap-2 bg-emerald-950/50 p-3 rounded-2xl border border-emerald-800">
                 <Target size={14} className="text-[#C5A059]" />
                 <div className="text-left">
                    <p className="text-[7px] font-black text-emerald-700 uppercase">Target</p>
                    <p className="text-[10px] font-black text-white font-mono">{invitationData.target.toLocaleString()}</p>
                 </div>
              </div>
              <div className="flex items-center gap-2 bg-emerald-950/50 p-3 rounded-2xl border border-emerald-800">
                 <Clock size={14} className="text-[#C5A059]" />
                 <div className="text-left">
                    <p className="text-[7px] font-black text-emerald-700 uppercase">Ends</p>
                    <p className="text-[10px] font-black text-white font-mono">{new Date(invitationData.endDate).toLocaleDateString('en-GB', { day: '2-digit', month: 'short' })}</p>
                 </div>
              </div>
           </div>
        </div>

        <div className="mb-10 px-2">
           <div className="flex items-center gap-3 bg-amber-500/10 p-4 rounded-2xl border border-amber-500/30">
              <div className="text-amber-500 shrink-0">
                {getPillarIcon(invitationData.fundraisingOption)}
              </div>
              <div>
                 <p className="text-[8px] font-black text-amber-600 uppercase tracking-widest leading-none mb-1">Fundraising Option</p>
                 <p className="text-[10px] font-black text-amber-500 uppercase tracking-tight">{getPillarLabel(invitationData.fundraisingOption)}</p>
              </div>
           </div>
        </div>

        <div className="flex bg-emerald-950/50 rounded-[2.5rem] p-1.5 border border-emerald-800/50">
           <button 
             onClick={() => onReject(invitationData.id)}
             className="flex-1 py-5 rounded-[2rem] text-[10px] font-black text-emerald-600 uppercase tracking-widest hover:text-white transition-all active:scale-95 hover:bg-red-500/10"
           >
             Decline
           </button>
           <button 
             onClick={() => onAccept(invitationData.id)}
             className="flex-1 py-5 bg-[#C5A059] text-emerald-950 rounded-[2rem] text-[10px] font-black uppercase tracking-widest shadow-xl shadow-amber-500/10 flex items-center justify-center gap-2 active:scale-95 hover:bg-white transition-all"
           >
             Accept & Join <ChevronRight size={14} />
           </button>
        </div>

        <footer className="mt-8 pt-6 border-t border-white/5 flex items-center justify-center gap-2 opacity-30">
          <ShieldCheck size={12} className="text-[#C5A059]" />
          <span className="text-[8px] font-black uppercase tracking-widest text-emerald-400">Secure collective sync active</span>
        </footer>
      </div>
    </div>
  );
};

export default InvitationPortal;
