
import React, { useState } from 'react';
import { 
  Mail, Phone, User, MapPin, Navigation, Send, 
  Loader2, ShieldCheck, Globe, CheckCircle2, 
  MapPinCheck
} from 'lucide-react';
import { fetchCurrentLocation, reverseGeocode } from '../services/locationService';
import { UserProfile } from '../types';

interface RegistrationScreenProps {
  onComplete: (profile: UserProfile) => void;
}

const RegistrationScreen: React.FC<RegistrationScreenProps> = ({ onComplete }) => {
  const [loading, setLoading] = useState(false);
  const [locating, setLocating] = useState(false);
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    city: '',
    zipcode: '',
    gpsLat: null as number | null,
    gpsLng: null as number | null
  });

  const handleAutoLocate = async () => {
    setLocating(true);
    try {
      const position = await fetchCurrentLocation();
      const { latitude, longitude } = position.coords;
      const { city, zipcode } = await reverseGeocode(latitude, longitude);
      setFormData(prev => ({ 
        ...prev, 
        city, 
        zipcode,
        gpsLat: latitude,
        gpsLng: longitude
      }));
    } catch (err) {
      alert("Location retrieval failed. Please enable permissions.");
    } finally {
      setLocating(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    // Simulate encryption and identity creation
    setTimeout(() => {
      // Add missing role: 'servant'
      const profile: UserProfile = {
        firstName: formData.firstName,
        lastName: formData.lastName,
        email: formData.email,
        phone: formData.phone,
        city: formData.city,
        zipcode: formData.zipcode,
        isRegistered: true,
        avatarColor: 'bg-emerald-700',
        isAnonymous: false,
        tier: 'ABID',
        isPremium: false,
        role: 'servant'
      };
      
      localStorage.setItem('ashadu_user_profile', JSON.stringify(profile));
      onComplete(profile);
    }, 2000);
  };

  return (
    <div className="fixed inset-0 z-[500] bg-[#064e3b] flex flex-col items-center justify-center p-6 overflow-y-auto font-inter">
      {/* Glassmorphism Panel */}
      <div className="w-full max-w-md bg-emerald-900/30 backdrop-blur-2xl rounded-[3.5rem] p-8 md:p-12 border border-[#C5A059]/30 shadow-[0_30px_100px_rgba(0,0,0,0.5)] relative overflow-hidden animate-in zoom-in-95 duration-700">
        
        {/* Visual Brand Elements */}
        <div className="absolute top-0 right-0 p-10 opacity-5 rotate-12">
          <Globe size={240} className="text-white" />
        </div>

        <header className="text-center mb-10 relative z-10">
          <div className="w-20 h-20 bg-emerald-950 rounded-3xl flex items-center justify-center mx-auto mb-6 border border-[#C5A059]/20 shadow-2xl">
          </div>
          <h2 className="text-3xl font-black text-[#C5A059] tracking-tighter uppercase mb-2">Join ASHADU</h2>
          <p className="text-emerald-400/60 text-[10px] font-black uppercase tracking-[0.4em]">Spirituality & Technology Unified</p>
        </header>

        <form onSubmit={handleSubmit} className="space-y-5 relative z-10">
          {/* Identity Fields */}
          <div className="grid grid-cols-2 gap-4">
            <GlassInput 
              icon={<User size={16}/>} 
              placeholder="First Name" 
              value={formData.firstName} 
              onChange={v => setFormData({...formData, firstName: v})} 
              required
            />
            <GlassInput 
              icon={<User size={16}/>} 
              placeholder="Last Name" 
              value={formData.lastName} 
              onChange={v => setFormData({...formData, lastName: v})} 
              required
            />
          </div>

          {/* Contact Fields */}
          <GlassInput 
            type="email"
            icon={<Mail size={16}/>} 
            placeholder="Email Address" 
            value={formData.email} 
            onChange={v => setFormData({...formData, email: v})} 
            required
          />
          <GlassInput 
            type="tel"
            icon={<Phone size={16}/>} 
            placeholder="Contact Number" 
            value={formData.phone} 
            onChange={v => setFormData({...formData, phone: v})} 
            required
          />

          {/* Location Fields */}
          <div className="flex gap-3">
            <div className="flex-[2]">
              <GlassInput 
                icon={<MapPin size={16}/>} 
                placeholder="City / Town" 
                value={formData.city} 
                onChange={v => setFormData({...formData, city: v})} 
                required
              />
            </div>
            <div className="flex-1">
              <GlassInput 
                placeholder="Zipcode" 
                value={formData.zipcode} 
                onChange={v => setFormData({...formData, zipcode: v})} 
                required
              />
            </div>
          </div>

          {/* GPS Integration Button */}
          <button 
            type="button"
            onClick={handleAutoLocate}
            disabled={locating}
            className={`w-full py-4 rounded-2xl flex items-center justify-center gap-3 transition-all border font-black text-[10px] uppercase tracking-widest active:scale-95
              ${formData.gpsLat ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' : 'bg-black/20 text-[#C5A059] border-[#C5A059]/20 hover:bg-black/40'}`}
          >
            {locating ? <Loader2 size={16} className="animate-spin" /> : formData.gpsLat ? <MapPinCheck size={16} /> : <Navigation size={16} />}
            {locating ? 'Aligning Qibla...' : formData.gpsLat ? 'GPS COORDINATES SECURED' : 'ENABLE GPS LOCATION'}
          </button>

          {/* Submit Action */}
          <button 
            type="submit" 
            disabled={loading}
            className="w-full bg-[#C5A059] hover:bg-white text-emerald-950 font-black py-6 rounded-3xl mt-6 shadow-2xl transition-all active:scale-95 flex items-center justify-center gap-3 uppercase tracking-[0.3em] text-xs"
          >
            {loading ? <Loader2 size={20} className="animate-spin" /> : <><CheckCircle2 size={18} /> JOIN THE UMMAH</>}
          </button>
        </form>

        <footer className="mt-8 pt-6 border-t border-white/5 flex items-center justify-center gap-2 opacity-40">
          <ShieldCheck size={14} className="text-[#C5A059]" />
          <span className="text-[9px] font-black uppercase tracking-widest text-emerald-400">Identity Guard Encrypted</span>
        </footer>
      </div>

      <div className="mt-10 text-center relative z-10 opacity-30">
        <p className="text-[8px] font-black uppercase tracking-[0.6em] text-white">ASHADU_CORE: 2.5.0-GOLD</p>
      </div>
    </div>
  );
};

const GlassInput = ({ icon, placeholder, value, onChange, type = "text", required }: any) => (
  <div className="relative group">
    {icon && (
      <div className="absolute left-5 top-1/2 -translate-y-1/2 text-emerald-600 group-focus-within:text-[#C5A059] transition-colors">
        {icon}
      </div>
    )}
    <input 
      type={type}
      required={required}
      placeholder={placeholder}
      value={value}
      onChange={e => onChange(e.target.value)}
      className={`w-full bg-black/30 border border-white/10 rounded-2xl py-4 pr-6 ${icon ? 'pl-14' : 'pl-6'} text-sm font-bold text-white placeholder:text-emerald-800 outline-none focus:border-[#C5A059]/60 focus:ring-4 focus:ring-[#C5A059]/5 transition-all shadow-inner`}
    />
  </div>
);

export default RegistrationScreen;
