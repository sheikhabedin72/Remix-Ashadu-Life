import React, { useRef, useState } from 'react';
import { RefreshCw, Info, Zap, Heart, BookMarked } from 'lucide-react';
import { Phrase } from '../types';
import DigitalLantern from './DigitalLantern';

interface CounterProps {
  count: number;
  target: number;
  phrase: Phrase;
  onIncrement: () => boolean;
  onReset: () => void;
  onInsight: () => void;
  onSelectZikr: () => void;
  onSetTarget: (newTarget: number) => void;
  streak: number;
  onJoinGroup?: () => void;
  onSponsor?: () => void;
}

const Counter: React.FC<CounterProps> = ({ 
  count, target, phrase, onIncrement, onReset, onInsight, onSelectZikr, onJoinGroup, onSponsor 
}) => {
  const [isBouncing, setIsBouncing] = useState(false);
  const progress = Math.min((count / target) * 100, 100);
  const radius = 140;
  const circumference = 2 * Math.PI * radius;
  const dashOffset = circumference * (1 - progress / 100);

  const handleTap = () => {
    if (!onIncrement()) return;
    if ('vibrate' in navigator) navigator.vibrate(12);
    setIsBouncing(true);
    setTimeout(() => setIsBouncing(false), 150);
  };

  const handleReset = () => {
    if (count === 0) return;
    if (window.confirm("CELESTIAL RESET: Are you sure you want to return this frequency to zero?")) {
      onReset();
    }
  };

  return (
    <div className="h-full flex flex-col items-center justify-between p-6 pb-40 relative bg-[#022c22] overflow-y-auto custom-scrollbar">
      <div className="w-full flex flex-col items-center mt-6 shrink-0">
        <div className="mb-8"><DigitalLantern progress={progress / 100} /></div>

        <div onClick={handleTap} className="relative w-80 h-80 flex items-center justify-center cursor-pointer select-none active:scale-95 transition-transform shrink-0">
          <svg className="absolute inset-0 w-full h-full -rotate-90">
            <circle cx="160" cy="160" r={radius} className="stroke-emerald-900/50" strokeWidth="14" fill="transparent" />
            <circle cx="160" cy="160" r={radius}
              className="transition-all duration-700 ease-out stroke-[#C5A059]"
              strokeWidth="14" fill="transparent" strokeDasharray={circumference}
              strokeDashoffset={dashOffset} strokeLinecap="round"
              style={{ filter: 'drop-shadow(0 0 10px rgba(197, 160, 89, 0.4))' }}
            />
          </svg>

          <div className={`w-64 h-64 rounded-full flex flex-col items-center justify-center bg-emerald-900/60 backdrop-blur-2xl border-2 border-[#C5A059]/30 shadow-[0_20px_60px_rgba(0,0,0,0.5)] ${isBouncing ? 'bead-click' : ''}`}>
             <span className="text-7xl font-black text-white tracking-tighter leading-none">{count}</span>
             <p className="arabic text-4xl text-[#C5A059] mt-6">{phrase.arabic}</p>
             <p className="text-[10px] font-black uppercase text-emerald-500 tracking-[0.4em] mt-3">{phrase.transliteration}</p>
          </div>
        </div>
      </div>

      <div className="w-full max-w-md space-y-4 px-4 mt-12 shrink-0">
        <div className="grid grid-cols-2 gap-4">
          <button onClick={onJoinGroup} className="py-6 btn-gold rounded-2xl font-black uppercase tracking-widest text-[11px] flex flex-col items-center gap-2 shadow-xl shadow-amber-500/10">
            <Zap size={20} /> MISSION HUB
          </button>
          <button onClick={onSponsor} className="py-6 bg-emerald-900/50 border border-[#C5A059]/30 text-[#C5A059] rounded-2xl font-black uppercase tracking-widest text-[11px] flex flex-col items-center gap-2 hover:bg-emerald-800 transition-all">
            <Heart size={20} /> SPONSOR SOULS
          </button>
        </div>
        <div className="flex gap-3">
          <button onClick={handleReset} className="flex-1 py-4 bg-black/30 text-emerald-700 rounded-xl font-black uppercase tracking-widest text-[8px] border border-white/5">RESET</button>
          <button onClick={onSelectZikr} className="flex-1 py-4 bg-emerald-900/50 text-[#C5A059] rounded-xl font-black uppercase tracking-widest text-[8px] border border-[#C5A059]/30 flex items-center justify-center gap-2">
            <BookMarked size={12} /> ZIKR NAME
          </button>
          <button onClick={onInsight} className="flex-1 py-4 bg-emerald-900/30 text-[#C5A059] rounded-xl font-black uppercase tracking-widest text-[8px] border border-[#C5A059]/30">WISDOM</button>
        </div>
      </div>
      
      <div className="absolute inset-0 celestial-grid pointer-events-none opacity-20" />
    </div>
  );
};

export default Counter;