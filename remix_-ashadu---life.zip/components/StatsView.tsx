import React from 'react';
import { UserStats } from '../types';
import { TrendingUp, Target, Award, BarChart3, Flame } from 'lucide-react';

const StatsView: React.FC<{ stats: UserStats }> = ({ stats }) => {
  const today = new Date().toISOString().split('T')[0];
  const last7Days = Array.from({ length: 7 }, (_, i) => {
    const d = new Date();
    d.setDate(d.getDate() - i);
    return d.toISOString().split('T')[0];
  }).reverse();

  const maxVal = Math.max(...last7Days.map(d => stats.dailyLogs.find(l => l.date === d)?.count || 0), 100);

  return (
    <div className="h-full overflow-y-auto px-6 pb-40 bg-[#FDFBF7] animate-in slide-in-from-bottom-8 duration-500 font-inter">
      <div className="py-10">
        <h2 className="text-3xl font-black text-[#0F172A] tracking-tighter uppercase">Analytical Ledger</h2>
        <p className="text-slate-400 text-[10px] font-black uppercase tracking-[0.3em] mt-1">Consistency is a spiritual discipline.</p>
      </div>

      <div className="grid grid-cols-2 gap-4 mb-10">
        <StatCard icon={<TrendingUp size={20} />} label="Total Volume" value={stats.totalCount} className="bg-white border-2 border-[#0F172A] text-[#0F172A]" />
        <StatCard icon={<Flame size={20} />} label="Active Streak" value={stats.streak} className="bg-[#0F172A] text-[#FDFBF7] shadow-[6px_6px_0px_#C5A059]" suffix=" Days" />
      </div>

      <div className="bg-white p-8 rounded-3xl border-2 border-[#0F172A] shadow-[8px_8px_0px_#0F172A] mb-10">
        <div className="flex justify-between items-center mb-10">
            <h3 className="font-black text-[#0F172A] uppercase text-[10px] tracking-[0.3em] flex items-center gap-2">
                <BarChart3 size={16} /> Weekly Velocity
            </h3>
        </div>
        <div className="flex items-end justify-between h-40 gap-4">
          {last7Days.map(date => {
            const logCount = stats.dailyLogs.find(l => l.date === date)?.count || 0;
            const height = (logCount / maxVal) * 100;
            const isToday = date === today;
            
            return (
              <div key={date} className="flex-1 flex flex-col items-center gap-4">
                <div className="w-full relative group h-full flex flex-col justify-end">
                   <div 
                    style={{ height: `${Math.max(height, 8)}%` }}
                    className={`w-full rounded-lg transition-all duration-700 ${isToday ? 'bg-[#C5A059]' : 'bg-[#0F172A]'}`}
                   />
                </div>
                <span className={`text-[8px] font-black uppercase tracking-widest ${isToday ? 'text-[#C5A059]' : 'text-slate-400'}`}>
                  {new Date(date).toLocaleDateString('en-US', { weekday: 'short' })}
                </span>
              </div>
            );
          })}
        </div>
      </div>
      
      <div className="p-8 bg-[#0F172A] rounded-3xl flex items-center justify-between border-2 border-[#0F172A] shadow-xl">
         <div className="flex items-center gap-5">
            <div className="w-14 h-14 bg-[#FDFBF7] rounded-xl flex items-center justify-center text-[#0F172A] border-2 border-[#C5A059]">
                <Award size={28} />
            </div>
            <div>
                <h4 className="text-[#FDFBF7] font-black text-lg tracking-tight uppercase">Milestone Path</h4>
                <p className="text-[#C5A059] text-[9px] font-black uppercase tracking-widest mt-1">Goal: 10,000 Verified Zikr</p>
            </div>
         </div>
      </div>
    </div>
  );
};

const StatCard = ({ icon, label, value, className, suffix = "" }: any) => (
  <div className={`p-8 rounded-3xl flex flex-col justify-between h-44 transition-all duration-500 ${className}`}>
    <div className="p-3 bg-black/5 w-fit rounded-xl">{icon}</div>
    <div>
      <p className="text-[8px] font-black uppercase tracking-[0.2em] opacity-60">{label}</p>
      <p className="text-3xl font-black leading-none mt-2 tracking-tighter">
        {value.toLocaleString()}<span className="text-sm font-bold opacity-40 ml-1">{suffix}</span>
      </p>
    </div>
  </div>
);

export default StatsView;