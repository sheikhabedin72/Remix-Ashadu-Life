import React from 'react';
import { 
  Fingerprint, BookMarked, Droplets, Send, Map, Users, Trophy, BarChart3, Mic, BookOpen, Zap, Globe, Scale, Landmark, ShoppingBag, Wallet, ChevronRight, X, ShieldAlert, UserPlus, Compass, Sparkles, Heart, Home, Terminal, ShieldCheck
} from 'lucide-react';
import { View, UserProfile } from '../types';

interface MainMenuViewProps {
  onNavigate: (view: View) => void;
  onClose: () => void;
}

const MainMenuView: React.FC<MainMenuViewProps> = ({ onNavigate, onClose }) => {
  const userProfileStr = localStorage.getItem('ashadu_user_profile');
  const userProfile: UserProfile | null = userProfileStr ? JSON.parse(userProfileStr) : null;
  const isGuest = !userProfile;
  const isAuthority = userProfile?.role === 'admin' || userProfile?.role === 'developer' || userProfile?.email?.endsWith('ashadu.com');

  const sections = [
    { title: "Navigation", items: [
      { name: "COMMAND CENTER", icon: null, view: 'dashboard', premium: "Advanced Analytics Dashboard" },
      { name: "PROFILE SETTINGS", icon: null, view: 'profile', premium: "Identity Configuration" },
      { name: "ACCOUNT CONFIG", icon: null, view: 'settings', premium: "Data & Privacy Controls" },
    ]},
    { title: "Worship", items: [
      { name: "TASBIH COUNTER", icon: null, view: 'counter', premium: "3D Heartbeat & Zikr Analytics" },
      { name: "GROUP ZIKR", icon: null, view: 'circles', premium: "Verified 'Muhsin' Badge" },
      { name: "ZIKR NAME", icon: null, view: 'library', premium: "Custom Zikr Library Sync" },
      { name: "RAMADAN HUB", icon: null, view: 'ramadan', premium: "Rose Gold & Midnight Themes" },
      { name: "SALAH GUIDE", icon: null, view: 'salah-guide', premium: "AI Posture Correction (Beta)" },
    ]},
    { title: "Legacy", items: [
      { name: "ZAKAT PORTAL", icon: null, view: 'zakat-calculator', highlight: true, premium: "Automated Wealth Tracking" },
      { name: "LEGACY MISSIONS", icon: null, view: 'legacy-hub', premium: "Priority Project Allocation" },
      { name: "PAY SADAQA", icon: null, view: 'marketplace', premium: "Zero-Commission Merchant Support" },
      { name: "BALANCE LEDGER", icon: null, view: 'ledger', premium: "Exportable Tax-Ready Reports" },
    ]},
    { title: "Trust & Ethics", items: [
      { name: "Privacy & Data Ethics Policy", icon: null, view: 'privacy', premium: "Enhanced Encryption Shield" },
    ]}
  ];

  return (
    <div className="fixed inset-0 z-[1000] bg-[#022c22] flex flex-col animate-in fade-in duration-500 overflow-hidden font-inter">
      <div className="absolute inset-0 celestial-grid opacity-10 pointer-events-none" />
      
      <div className="p-8 pb-4 flex justify-between items-center z-10 bg-black/40 backdrop-blur-md border-b border-white/5">
        <div>
          <h2 className="text-3xl font-black text-white tracking-tighter uppercase leading-none">Celestial Hub</h2>
          <p className="text-[9px] text-[#C5A059] uppercase font-black tracking-[0.4em] mt-2">Ummah Navigation System</p>
        </div>
        <button onClick={onClose} className="p-4 bg-emerald-950 rounded-2xl text-[#C5A059] border border-[#C5A059]/30 active:scale-90 shadow-xl font-black">X</button>
      </div>

      <div className="flex-1 overflow-y-auto px-8 py-10 pb-32 custom-scrollbar z-10 relative">
        <div className="max-w-xl mx-auto space-y-12">
          {isAuthority && (
            <button onClick={() => { onNavigate('admin-full'); onClose(); }}
              className="w-full bg-[#010e0b] border border-cyan-500/30 p-8 rounded-[2.5rem] flex items-center justify-between shadow-2xl group transition-all">
               <div className="flex items-center gap-6">
                  <div className="w-16 h-16 bg-cyan-500/10 rounded-2xl flex items-center justify-center text-cyan-400 border border-cyan-500/20">
                    {/* Terminal removed */}
                  </div>
                  <div className="text-left">
                     <p className="font-black uppercase tracking-[0.2em] text-xs text-cyan-400">CELESTIAL COMMAND</p>
                     <p className="text-[10px] font-bold opacity-60 uppercase mt-1 text-emerald-300">Authority Backend Active</p>
                  </div>
               </div>
               {/* ChevronRight removed */}
            </button>
          )}

          {isGuest && (
            <button onClick={() => { onClose(); window.dispatchEvent(new CustomEvent('openIdentityPortal')); }}
              className="w-full btn-gold p-8 rounded-[2.5rem] flex items-center justify-between shadow-2xl group transition-all">
               <div className="flex items-center gap-6">
                  {/* UserPlus removed */}
                  <div className="text-left">
                     <p className="font-black uppercase tracking-[0.2em] text-xs text-emerald-950">CREATE SPIRIT IDENTITY</p>
                     <p className="text-[10px] font-bold opacity-60 uppercase mt-1 text-emerald-900">Access collective missions</p>
                  </div>
               </div>
               {/* ChevronRight removed */}
            </button>
          )}

          {sections.map((section, idx) => (
            <div key={idx} className="space-y-4">
              <h3 className="text-[10px] font-black uppercase text-emerald-800 tracking-[0.4em] px-2">{section.title}</h3>
              <div className="grid grid-cols-1 gap-3">
                {section.items.map((item, i) => (
                  <button key={i} onClick={() => { onNavigate(item.view as any); onClose(); }}
                    className={`w-full flex items-center justify-between p-5 rounded-2xl border transition-all active:scale-[0.98] group
                      ${item.highlight ? 'bg-amber-500/10 border-amber-500/30 text-amber-500' : 'bg-black/20 border-white/5 text-emerald-600 hover:text-white hover:border-white/10'}`}>
                    <div className="flex items-center gap-5">
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center border ${item.highlight ? 'bg-amber-500 text-[#022c22] border-amber-400' : 'bg-emerald-950 text-[#C5A059] border-[#C5A059]/20'}`}>
                        {item.icon}
                      </div>
                      <div className="text-left">
                        <span className="text-[11px] font-black uppercase tracking-widest block">{item.name}</span>
                        <span className={`text-[8px] font-bold uppercase tracking-wider mt-0.5 flex items-center gap-1 ${item.highlight ? 'text-amber-500/60' : 'text-emerald-400/40 group-hover:text-emerald-400/60'}`}>
                          {item.premium}
                        </span>
                      </div>
                    </div>
                    {/* ChevronRight removed */}
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default MainMenuView;