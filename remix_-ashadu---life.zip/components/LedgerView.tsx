import React, { useState, useEffect, useMemo } from 'react';
import { UserStats, GlobalPricing, LedgerTransaction, TransactionType, TransactionStatus } from '../types';
import { 
  Coins, Heart, ShieldCheck, FileText, Wallet, Sparkles, BookOpen, ChevronRight, 
  AlertTriangle, Fingerprint, History, Download, Filter, CheckCircle2, Clock
} from 'lucide-react';
import { db } from '../services/databaseService';

interface LedgerViewProps {
  stats: UserStats;
  donationRate: number;
  onClearDebt: (type: 'all' | 'fast' | 'prayer') => void;
  onApplyEducationCredits: () => void;
  pricing: GlobalPricing;
}

const LedgerView: React.FC<LedgerViewProps> = ({ stats, donationRate, onApplyEducationCredits }) => {
  const [filter, setFilter] = useState<'All' | 'Zakat' | 'Zikr'>('All');
  const [zakatRecords, setZakatRecords] = useState<LedgerTransaction[]>([]);

  // 1. DATA AGGREGATION: Merging simulated Supabase tables
  useEffect(() => {
    const fetchLedger = async () => {
      const records = await db.getZakatRecords();
      const zikrTotalImpact = stats.totalCount * donationRate;

      // Transform Zakat records into unified Ledger format
      const zakatItems: LedgerTransaction[] = records.map(r => ({
        id: r.id,
        title: r.customName || 'Wealth Purification',
        date: r.date,
        amount: r.zakatDue,
        type: 'Zakat',
        status: r.status === 'SETTLED' ? 'Verified' : 'Processing'
      }));

      // Create a cumulative Zikr impact row if there's volume
      const zikrRow: LedgerTransaction[] = stats.totalCount > 0 ? [{
        id: 'zikr-main-ledger',
        title: 'Total Zikr Penny-Contributions',
        date: new Date().toLocaleDateString('en-GB'),
        amount: zikrTotalImpact,
        type: 'Zikr',
        status: 'Distributed'
      }] : [];

      setZakatRecords([...zikrRow, ...zakatItems]);
    };
    fetchLedger();
  }, [stats.totalCount, donationRate]);

  const filteredTransactions = useMemo(() => {
    if (filter === 'All') return zakatRecords;
    return zakatRecords.filter(t => t.type === filter);
  }, [zakatRecords, filter]);

  const totalContributed = zakatRecords.reduce((acc, curr) => acc + curr.amount, 0);
  const barakahPoints = Math.floor(totalContributed * 12); // Mock points logic

  const getStatusColor = (status: TransactionStatus) => {
    switch (status) {
      case 'Verified': return 'text-emerald-400';
      case 'Distributed': return 'text-cyan-400';
      case 'Processing': return 'text-amber-500 animate-pulse';
      default: return 'text-white/40';
    }
  };

  return (
    <div className="flex-1 overflow-y-auto px-6 pb-40 bg-[#021F1F] animate-in slide-in-from-bottom-8 duration-700 font-inter">
      {/* 1. LEDGER HEADER SUMMARY: GOLD SUMMARY CARD */}
      <div className="py-10">
        <div className="bg-gradient-to-br from-[#C5A059] via-amber-400 to-[#8c713b] p-10 rounded-[3.5rem] shadow-[0_20px_60px_rgba(197,160,89,0.3)] relative overflow-hidden group border-b-8 border-black/10">
          <div className="absolute top-4 right-4 opacity-10 group-hover:scale-110 transition-transform">
          </div>
          <div className="relative z-10">
            <p className="text-[10px] font-black uppercase text-emerald-950 tracking-[0.4em] mb-2">TOTAL CONTRIBUTED</p>
            <h3 className="text-6xl font-black text-emerald-950 font-mono tracking-tighter leading-none mb-4">£{totalContributed.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</h3>
            <div className="flex items-center gap-2 bg-emerald-950/20 backdrop-blur-md px-4 py-2 rounded-full border border-white/20 w-fit">
               <Sparkles size={14} className="text-emerald-950" />
               <span className="text-[9px] font-black text-emerald-950 uppercase tracking-widest">+{barakahPoints.toLocaleString()} Barakah Points Earned</span>
            </div>
          </div>
        </div>
      </div>

      {/* 2. FILTER & TOOLS */}
      <div className="flex justify-between items-center mb-8 px-2">
        <div className="flex gap-2 p-1 bg-black/40 rounded-xl border border-white/5">
           <FilterBtn active={filter === 'All'} onClick={() => setFilter('All')} label="All" />
           <FilterBtn active={filter === 'Zakat'} onClick={() => setFilter('Zakat')} label="Zakat" />
           <FilterBtn active={filter === 'Zikr'} onClick={() => setFilter('Zikr')} label="Zikr" />
        </div>
        <button className="p-3 bg-emerald-900/40 text-[#C5A059] rounded-xl border border-[#C5A059]/20 active:scale-95 transition-all">
          <Download size={20} />
        </button>
      </div>

      {/* 3. TRANSACTION LIST: THE AMANAH LEDGER ROWS */}
      <div className="space-y-4 mb-12">
        {filteredTransactions.length === 0 ? (
          <div className="py-20 text-center bg-black/20 rounded-[3rem] border border-dashed border-emerald-900">
             <History size={48} className="mx-auto text-emerald-900 mb-4 opacity-40" />
             <p className="text-[10px] text-emerald-800 font-black uppercase tracking-widest">No entries found in ledger</p>
          </div>
        ) : (
          filteredTransactions.map((item) => (
            <div key={item.id} className="bg-black/30 border border-emerald-900/50 p-6 rounded-[2.5rem] flex items-center justify-between group hover:border-[#C5A059]/30 transition-all active:scale-[0.98]">
              <div className="flex items-center gap-5">
                 {/* Emerald Icon Circle */}
                 <div className="w-14 h-14 rounded-2xl bg-emerald-950 border border-[#C5A059]/20 flex items-center justify-center text-[#C5A059] shadow-lg group-hover:rotate-6 transition-transform">
                   {item.type === 'Zakat' ? <Heart size={24} className="fill-[#C5A059]/10" /> : <Fingerprint size={24} />}
                 </div>
                 <div>
                    <h4 className="text-white font-black text-sm uppercase tracking-tight leading-none group-hover:text-[#C5A059] transition-colors">{item.title}</h4>
                    <div className="flex items-center gap-2 mt-2">
                       <Clock size={10} className="text-emerald-800" />
                       <p className="text-[9px] text-emerald-700 font-black uppercase tracking-widest">{item.date}</p>
                    </div>
                 </div>
              </div>
              <div className="text-right">
                <p className="text-xl font-black text-white font-mono leading-none">£{item.amount.toLocaleString(undefined, { minimumFractionDigits: 2 })}</p>
                <div className={`flex items-center gap-1.5 justify-end mt-2`}>
                   <div className={`w-1 h-1 rounded-full ${getStatusColor(item.status).replace('text', 'bg')}`} />
                   <span className={`text-[8px] font-black uppercase tracking-[0.2em] ${getStatusColor(item.status)}`}>
                     {item.status}
                   </span>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* 4. DOWNLOAD STATEMENT BUTTON: GOLD GHOST BUTTON */}
      <button 
        className="w-full py-7 bg-transparent border-2 border-[#C5A059]/40 text-[#C5A059] rounded-[2.5rem] font-black uppercase tracking-[0.3em] text-[10px] shadow-xl flex items-center justify-center gap-3 transition-all hover:bg-[#C5A059]/5 active:scale-95"
      >
        <FileText size={18} /> DOWNLOAD AMANAH REPORT (PDF)
      </button>

      {/* FOOTER SEAL */}
      <div className="mt-12 text-center opacity-30">
         <div className="flex items-center justify-center gap-3 mb-4">
            <CheckCircle2 size={16} className="text-[#C5A059]" />
            <p className="text-[10px] font-black text-white uppercase tracking-[0.5em]">CELESTIAL EMERALD AUDIT v2.5</p>
         </div>
      </div>
    </div>
  );
};

const FilterBtn = ({ active, onClick, label }: any) => (
  <button 
    onClick={onClick}
    className={`px-5 py-2.5 rounded-lg text-[9px] font-black uppercase tracking-widest transition-all ${active ? 'bg-[#C5A059] text-emerald-950' : 'text-emerald-700 hover:text-emerald-500'}`}
  >
    {label}
  </button>
);

export default LedgerView;