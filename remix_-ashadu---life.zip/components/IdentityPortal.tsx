
import React, { useState } from 'react';
import { Mail, User, Navigation, Loader2, ShieldCheck, ChevronLeft, Lock } from 'lucide-react';
import { fetchCurrentLocation, reverseGeocode } from '../services/locationService';
import { saveUserData, signUp, signIn, supabase } from '../services/supabaseService';
import { UserProfile } from '../types';

interface IdentityPortalProps {
  onComplete: (profile: UserProfile) => void;
  mandatory?: boolean;
  initialMode?: 'CHOICE' | 'LOGIN' | 'SIGNUP';
}

const IdentityPortal: React.FC<IdentityPortalProps> = ({ onComplete, mandatory, initialMode = 'CHOICE' }) => {
  const [mode, setMode] = useState<'CHOICE' | 'LOGIN' | 'SIGNUP'>(initialMode);
  const [loading, setLoading] = useState(false);
  const [locating, setLocating] = useState(false);
  const [formData, setFormData] = useState({ firstName: '', lastName: '', email: '', phone: '', city: '', zipcode: '', gpsLat: null as number | null, pin: '' });

  const handleAutoLocate = async () => {
    setLocating(true);
    try {
      const pos = await fetchCurrentLocation();
      const { city, zipcode } = await reverseGeocode(pos.coords.latitude, pos.coords.longitude);
      setFormData(prev => ({ ...prev, city, zipcode, gpsLat: pos.coords.latitude }));
    } finally { setLocating(false); }
  };

  const handleAction = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      if (mode === 'SIGNUP') {
        // 1. Supabase Auth Signup
        const authData = await signUp(formData.email, formData.pin, {
          firstName: formData.firstName,
          lastName: formData.lastName
        });

        if (authData.user) {
          // 2. Create User Profile
          const p: UserProfile = { 
            ...formData, 
            isRegistered: true, 
            avatarColor: 'bg-[#064e3b]', 
            isAnonymous: false, 
            tier: 'ABID', 
            isPremium: false,
            role: 'servant'
          };
          
          // 3. Save to Supabase user_data table
          await saveUserData({
            firstName: p.firstName,
            lastName: p.lastName,
            phone: p.phone,
            city: p.city,
            zipcode: p.zipcode,
            gpsLat: p.gpsLat,
            isRegistered: p.isRegistered,
            role: p.role,
            tier: p.tier
          });

          localStorage.setItem('ashadu_user_profile', JSON.stringify(p));
          onComplete(p);
        }
      } else if (mode === 'LOGIN') {
        // Supabase Auth Signin
        const authData = await signIn(formData.email, formData.pin);
        
        if (authData.user) {
          // Fetch user profile from user_data table using user_id
          const { data: profileData, error: profileError } = await supabase
            .from('user_data')
            .select('*')
            .eq('user_id', authData.user.id)
            .single();

          if (profileData) {
            localStorage.setItem('ashadu_user_profile', JSON.stringify(profileData));
            onComplete(profileData);
          } else {
            // Fallback if profile not found in table
            const p: UserProfile = {
              email: formData.email,
              firstName: authData.user.user_metadata?.firstName || 'User',
              lastName: authData.user.user_metadata?.lastName || '',
              isRegistered: true,
              role: 'servant',
              avatarColor: 'bg-[#064e3b]',
              isAnonymous: false,
              tier: 'ABID',
              isPremium: false
            };
            onComplete(p);
          }
        }
      }
    } catch (error: any) {
      alert(`Authentication Error: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[600] bg-[#022c22] flex flex-col items-center justify-center p-6 font-inter overflow-y-auto">
      <div className="absolute inset-0 celestial-grid opacity-10 pointer-events-none" />
      
      <div className="w-full max-w-md card-emerald rounded-[3rem] p-10 md:p-12 relative overflow-hidden animate-in zoom-in-95 duration-500">
        
        {mode === 'CHOICE' && (
          <div className="text-center animate-in fade-in duration-700">
             <h1 className="arabic text-4xl text-[#C5A059] mb-10 drop-shadow-xl">بِسْمِ اللهِ الرَّحْمٰنِ الرَّحِيْمِ</h1>
             <div className="flex justify-center mb-10">
                <div className="w-32 h-32 bg-[#064e3b] rounded-[2rem] flex items-center justify-center shadow-[0_0_40px_rgba(197,160,89,0.2)] border border-[#C5A059]/30 rotate-3 transition-transform hover:rotate-0">
                </div>
             </div>
             <h2 className="text-3xl font-black text-white uppercase tracking-tighter mb-2">Identification</h2>
             <p className="text-emerald-500 text-[10px] font-black uppercase tracking-[0.4em] mb-12">Verify spiritual handshake</p>
             <div className="space-y-4">
                <button onClick={() => setMode('LOGIN')} className="w-full btn-gold py-7 rounded-2xl font-black uppercase tracking-widest text-xs shadow-2xl">LOG IN</button>
                <button onClick={() => setMode('SIGNUP')} className="w-full bg-black/30 border border-[#C5A059]/30 text-[#C5A059] py-7 rounded-2xl font-black uppercase tracking-widest text-xs active:scale-95 transition-all">CREATE IDENTITY</button>
                <button 
                  onClick={() => onComplete({ 
                    email: 'guest@ashadu.com', 
                    firstName: 'Guest', 
                    lastName: 'Explorer', 
                    isRegistered: false, 
                    isGuest: true,
                    role: 'servant',
                    avatarColor: 'bg-emerald-700',
                    isAnonymous: true,
                    city: 'Global',
                    zipcode: '00000',
                    phone: '',
                    isPremium: false
                  })} 
                  className="w-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 py-5 rounded-2xl font-black uppercase tracking-widest text-[10px] active:scale-95 transition-all hover:bg-emerald-500/20"
                >
                  🚀 Start Exploring
                </button>
             </div>
          </div>
        )}

        {(mode === 'LOGIN' || mode === 'SIGNUP') && (
          <form onSubmit={handleAction} className="space-y-6 animate-in slide-in-from-bottom-4 duration-500">
            <header className="flex justify-between items-center mb-10">
               <button type="button" onClick={() => setMode('CHOICE')} className="p-4 bg-emerald-950 border border-emerald-800 rounded-2xl text-[#C5A059] active:scale-90 transition-all hover:bg-emerald-900 font-black">BACK</button>
               <div className="text-right">
                  <h2 className="text-2xl font-black uppercase tracking-tighter text-white">{mode}</h2>
                  <p className="text-[10px] text-[#C5A059] font-black uppercase tracking-widest">Amanah Protocol</p>
               </div>
            </header>

            {mode === 'SIGNUP' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Input icon={null} placeholder="First Name" value={formData.firstName} onChange={v => setFormData({...formData, firstName: v})} required />
                <Input icon={null} placeholder="Last Name" value={formData.lastName} onChange={v => setFormData({...formData, lastName: v})} required />
              </div>
            )}
            <Input type="email" icon={null} placeholder="Email" value={formData.email} onChange={(v: string) => setFormData({...formData, email: v})} required />
            <Input type="password" icon={null} placeholder="Amanah Pin" value={formData.pin} onChange={(v: string) => setFormData({...formData, pin: v})} required />

            {mode === 'SIGNUP' && (
              <button type="button" onClick={handleAutoLocate} disabled={locating} className="w-full py-5 rounded-2xl border border-emerald-800 bg-black/20 text-[10px] font-black uppercase tracking-widest flex items-center justify-center gap-3 text-emerald-500 active:bg-emerald-900 transition-colors">
                {locating ? 'LOCATING...' : 'Auto-Verify Location'}
              </button>
            )}

            <button type="submit" disabled={loading} className="w-full btn-gold py-7 rounded-2xl font-black uppercase tracking-widest text-xs flex items-center justify-center gap-3 shadow-2xl relative overflow-hidden group">
              {loading ? (
                <div className="flex items-center gap-3">
                  <span>SECURING...</span>
                </div>
              ) : (
                'SECURE ACCESS'
              )}
              <div className="absolute inset-0 bg-white/10 opacity-0 group-hover:opacity-100 transition-opacity" />
            </button>
          </form>
        )}

        <footer className="mt-12 pt-6 border-t border-white/5 flex items-center justify-center gap-3 opacity-50">
          <span className="text-[9px] font-black uppercase tracking-widest text-emerald-600">Amanah Guard Encrypted</span>
        </footer>
      </div>
    </div>
  );
};

const Input = ({ icon, placeholder, value, onChange, type = "text", required }: any) => (
  <div className="relative group">
    {icon && <div className="absolute left-6 top-1/2 -translate-y-1/2 text-emerald-800 group-focus-within:text-[#C5A059] transition-colors">{icon}</div>}
    <input 
      type={type} 
      required={required} 
      placeholder={placeholder} 
      value={value} 
      onChange={e => onChange?.(e.target.value)}
      className={`w-full input-emerald rounded-2xl py-6 pr-6 ${icon ? 'pl-16' : 'pl-6'} text-sm font-black placeholder:text-emerald-900 transition-all shadow-inner focus:ring-4 focus:ring-[#C5A059]/5`} 
    />
  </div>
);

export default IdentityPortal;
