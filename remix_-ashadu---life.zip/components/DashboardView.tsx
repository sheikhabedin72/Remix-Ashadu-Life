import React, { useState, useEffect } from 'react';
import { 
  User, 
  ShieldCheck, 
  Clock, 
  AlertCircle, 
  ChevronRight, 
  LayoutDashboard, 
  Settings, 
  Shield,
  Database,
  Calendar,
  ExternalLink,
  Heart,
  Sparkles
} from 'lucide-react';
import { UserStats, UserProfile, SystemSettings, View } from '../types';
import { fetchLatestUserData } from '../services/supabaseService';

interface DashboardViewProps {
  stats: UserStats;
  user: UserProfile | null;
  settings: SystemSettings;
  onNavigate: (view: View) => void;
  location?: { city: string; gpsActive: boolean; coords?: { lat: number; lon: number } | null };
}

const DashboardView: React.FC<DashboardViewProps> = ({ stats, user, settings, onNavigate }) => {
  const [isFetching, setIsFetching] = useState(true);
  const [dbData, setDbData] = useState<any>(null);

  useEffect(() => {
    const loadDashboardData = async () => {
      try {
        setIsFetching(true);
        const data = await fetchLatestUserData();
        setDbData(data);
      } catch (error) {
        console.error("Dashboard fetch failed:", error);
      } finally {
        setIsFetching(false);
      }
    };
    loadDashboardData();
  }, []);

  if (isFetching) {
    return (
      <div className="h-full bg-emerald-950 p-6 space-y-8 animate-in fade-in duration-500">
        {/* Skeleton Header */}
        <div className="h-12 w-64 bg-emerald-900/50 rounded-2xl animate-pulse" />
        
        {/* Skeleton Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[1, 2, 3].map(i => (
            <div key={i} className="h-40 bg-emerald-900/30 rounded-[2.5rem] animate-pulse" />
          ))}
        </div>

        {/* Skeleton Content */}
        <div className="h-64 bg-emerald-900/20 rounded-[3rem] animate-pulse" />
      </div>
    );
  }

  const fullName = dbData?.full_name || user?.firstName || "Seeker";
  const hasBio = !!dbData?.bio;
  const lastUpdated = dbData?.updated_at ? new Date(dbData.updated_at).toLocaleDateString() : 'Never';

  return (
    <div className="h-full bg-emerald-950 flex flex-col font-inter overflow-hidden relative animate-in fade-in duration-700">
      <div className="absolute inset-0 celestial-grid opacity-10 pointer-events-none" />
      
      {/* Top Navigation Bar */}
      <div className="px-6 py-4 flex items-center justify-between bg-emerald-900/20 border-b border-emerald-800/50 backdrop-blur-md z-20">
        <div className="flex items-center gap-2">
          <LayoutDashboard size={18} className="text-[#C5A059]" />
          <span className="text-[10px] font-black uppercase tracking-widest text-white">Central Hub</span>
        </div>
        <div className="flex items-center gap-4">
          <button onClick={() => onNavigate('dashboard')} className="text-[9px] font-black uppercase tracking-widest text-[#C5A059]">Dashboard</button>
          <button onClick={() => onNavigate('profile')} className="text-[9px] font-black uppercase tracking-widest text-emerald-500 hover:text-white transition-colors">Settings</button>
          <button onClick={() => onNavigate('privacy')} className="text-[9px] font-black uppercase tracking-widest text-emerald-500 hover:text-white transition-colors">Privacy</button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-6 py-10 pb-40 space-y-10 relative z-10 custom-scrollbar">
        
        {/* Personalized Header */}
        <header className="space-y-2">
          <h1 className="text-4xl md:text-5xl font-black text-white tracking-tighter leading-none">
            Welcome back, <span className="text-[#C5A059]">{fullName}</span>
          </h1>
          <p className="text-[10px] text-emerald-500 font-black uppercase tracking-[0.4em]">Your Spiritual Dashboard is Active</p>
        </header>

        {/* Bio Alert Box */}
        {!hasBio && (
          <div className="p-6 bg-amber-500/10 border border-amber-500/30 rounded-[2.5rem] flex items-center justify-between group animate-in slide-in-from-top-4 duration-500">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-amber-500/20 rounded-2xl text-amber-500">
                <AlertCircle size={24} />
              </div>
              <div>
                <h4 className="font-black text-white text-sm uppercase tracking-tight">Complete Your Profile</h4>
                <p className="text-[10px] text-amber-500/70 font-black uppercase tracking-widest mt-1">Tell the Ummah about your journey</p>
              </div>
            </div>
            <button 
              onClick={() => onNavigate('profile')}
              className="p-4 bg-amber-500 rounded-2xl text-emerald-950 hover:bg-amber-400 transition-all active:scale-95"
            >
              <ChevronRight size={20} />
            </button>
          </div>
        )}

        {/* 3-Column Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <StatCard 
            icon={<ShieldCheck size={24} />}
            title="Profile Status"
            value={hasBio ? "Complete" : "Incomplete"}
            sub={hasBio ? "Identity Anchored" : "Action Required"}
            color={hasBio ? "text-emerald-400" : "text-amber-500"}
          />
          <StatCard 
            icon={<Database size={24} />}
            title="Total Saves"
            value={dbData ? "1" : "0"}
            sub="Cloud Records Found"
            color="text-[#C5A059]"
          />
          <StatCard 
            icon={<Calendar size={24} />}
            title="Last Updated"
            value={lastUpdated}
            sub="Celestial Timestamp"
            color="text-emerald-400"
          />
        </div>

        {/* Quick Actions Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <QuickAction icon={<Heart size={20} />} label="Zakat Portal" onClick={() => onNavigate('zakat-calculator')} color="bg-emerald-900/40 text-[#C5A059]" />
          <QuickAction icon={<Sparkles size={20} />} label="Legacy Hub" onClick={() => onNavigate('legacy-hub')} color="bg-emerald-900/40 text-[#C5A059]" />
          <QuickAction icon={<LayoutDashboard size={20} />} label="Sadaqa" onClick={() => onNavigate('marketplace')} color="bg-emerald-900/40 text-[#C5A059]" />
          <QuickAction icon={<Database size={20} />} label="Ledger" onClick={() => onNavigate('ledger')} color="bg-emerald-900/40 text-[#C5A059]" />
          <QuickAction icon={<Clock size={20} />} label="Salah Guide" onClick={() => onNavigate('salah-guide')} color="bg-emerald-900/40 text-[#C5A059]" />
          <QuickAction icon={<Calendar size={20} />} label="Ramadan" onClick={() => onNavigate('ramadan')} color="bg-emerald-900/40 text-[#C5A059]" />
          <QuickAction icon={<Shield size={20} />} label="Privacy" onClick={() => onNavigate('privacy')} color="bg-emerald-900/40 text-[#C5A059]" />
          <QuickAction icon={<Settings size={20} />} label="Settings" onClick={() => onNavigate('settings')} color="bg-emerald-900/40 text-[#C5A059]" />
        </div>

        {/* Quick Actions / Summary */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="p-8 bg-emerald-900/30 border border-emerald-800 rounded-[3rem] space-y-6">
            <div className="flex items-center gap-3">
              <User size={20} className="text-[#C5A059]" />
              <h3 className="font-black text-white text-sm uppercase tracking-widest">Identity Summary</h3>
            </div>
            <div className="space-y-4">
              <div className="flex justify-between items-center py-3 border-b border-emerald-800/50">
                <span className="text-[10px] font-black uppercase text-emerald-600 tracking-widest">Email</span>
                <span className="text-xs text-white font-medium">{user?.email}</span>
              </div>
              <div className="flex justify-between items-center py-3 border-b border-emerald-800/50">
                <span className="text-[10px] font-black uppercase text-emerald-600 tracking-widest">Website</span>
                <span className="text-xs text-[#C5A059] font-medium">{dbData?.website_url || 'None'}</span>
              </div>
              <div className="flex justify-between items-center py-3">
                <span className="text-[10px] font-black uppercase text-emerald-600 tracking-widest">Role</span>
                <span className="text-xs text-white font-black uppercase tracking-widest">{user?.role || 'Seeker'}</span>
              </div>
            </div>
          </div>

          <div className="p-8 bg-emerald-900/30 border border-emerald-800 rounded-[3rem] flex flex-col justify-between group cursor-pointer hover:bg-emerald-900/40 transition-all" onClick={() => onNavigate('profile')}>
            <div className="space-y-4">
              <div className="p-4 bg-emerald-800 rounded-2xl w-fit text-[#C5A059]">
                <Settings size={24} />
              </div>
              <h3 className="text-2xl font-black text-white uppercase tracking-tighter">Account Settings</h3>
              <p className="text-xs text-emerald-100/60 leading-relaxed">Manage your digital Amanah, update your profile, and control your data privacy settings.</p>
            </div>
            <div className="flex items-center gap-2 text-[#C5A059] font-black text-[10px] uppercase tracking-widest mt-6">
              Go to Settings <ChevronRight size={14} />
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};

interface QuickActionProps {
  icon: React.ReactNode;
  label: string;
  onClick: () => void;
  color: string;
}

const QuickAction: React.FC<QuickActionProps> = ({ icon, label, onClick, color }) => (
  <button 
    onClick={onClick}
    className={`p-6 rounded-3xl border border-emerald-800/50 flex flex-col items-center gap-3 transition-all active:scale-95 hover:border-[#C5A059]/30 shadow-lg ${color}`}
  >
    <div className="p-3 bg-emerald-950/50 rounded-xl">
      {icon}
    </div>
    <span className="text-[9px] font-black uppercase tracking-widest text-center">{label}</span>
  </button>
);

interface StatCardProps {
  icon: React.ReactNode;
  title: string;
  value: string;
  sub: string;
  color: string;
}

const StatCard: React.FC<StatCardProps> = ({ icon, title, value, sub, color }) => (
  <div className="p-8 bg-emerald-900/30 border border-emerald-800 rounded-[2.5rem] space-y-4 hover:border-[#C5A059]/30 transition-all group">
    <div className={`p-4 bg-emerald-800 rounded-2xl w-fit ${color} group-hover:scale-110 transition-transform`}>
      {icon}
    </div>
    <div>
      <p className="text-[9px] font-black uppercase tracking-[0.2em] text-emerald-600">{title}</p>
      <h3 className={`text-2xl font-black tracking-tighter mt-1 ${color}`}>{value}</h3>
      <p className="text-[8px] font-black uppercase tracking-widest text-emerald-900 mt-1">{sub}</p>
    </div>
  </div>
);

export default DashboardView;
