import React, { useState, useEffect, useCallback } from 'react';
import { 
  Search, 
  ChevronRight, 
  Plus, 
  Users, 
  ShieldCheck, 
  Sparkles,
  Zap,
  BookOpen,
  Flame,
  Landmark,
  Fingerprint,
  ChevronLeft,
  Heart,
  Radio,
  User,
  Target,
  Trophy,
  History,
  X,
  Save,
  Clock,
  Settings,
  ShieldAlert,
  UserPlus,
  Mail,
  Send,
  Trash2,
  Play,
  RotateCcw,
  Contact,
  UsersRound,
  Check,
  Shield,
  FileText,
  Coins,
  Medal,
  TrendingUp,
  ArrowUpRight,
  HandHeart
} from 'lucide-react';
import DigitalLantern from './DigitalLantern';
import { DEMO_PROFILES, INITIAL_PROJECTS } from '../constants';
import { LegacyProject } from '../types';

interface Circle {
  id: string;
  name: string;
  members: number;
  description: string;
  category: 'Worship' | 'Legacy' | 'Knowledge' | 'General';
  currentCount: number;
  target?: number;
  phrase: string;
  joined?: boolean;
  isModerator?: boolean;
  legacyMissionId?: string;
  raised?: number; // Optional override for raised amount
}

interface CirclesViewProps {
  onNavigateToMission: (id: string) => void;
}

const CommunityCircles: React.FC<CirclesViewProps> = ({ onNavigateToMission }) => {
  const [activeTab, setActiveTab] = useState<'MISSIONS' | 'LIVE'>('MISSIONS');
  const [activeRoomId, setActiveRoomId] = useState<string | null>(null);
  const [activeMissionSession, setActiveMissionSession] = useState<Circle | null>(null);
  const [isCreating, setIsCreating] = useState(false);
  const [isInviting, setIsInviting] = useState<Circle | null>(null);
  const [viewingMembers, setViewingMembers] = useState<Circle | null>(null);
  const [viewingImpact, setViewingImpact] = useState<Circle | null>(null);
  const [inviteTab, setInviteTab] = useState<'DIRECT' | 'FRIENDS' | 'CONTACTS'>('FRIENDS');
  const [sessionCount, setSessionCount] = useState(14502);
  const [inviteInput, setInviteInput] = useState('');
  const [searchInviteQuery, setSearchInviteQuery] = useState('');
  const [invitedIds, setInvitedIds] = useState<Set<string>>(new Set());
  const [showCompletionPopup, setShowCompletionPopup] = useState(false);
  
  const [legacyProjects] = useState<LegacyProject[]>(() => {
    const saved = localStorage.getItem('ashadu_legacy_projects');
    return saved ? JSON.parse(saved) : INITIAL_PROJECTS;
  });

  const [circles, setCircles] = useState<Circle[]>(() => {
    const saved = localStorage.getItem('ashadu_circles_data_v2');
    return saved ? JSON.parse(saved) : [
      { id: 'm-001', name: 'Emerald Mission', members: 1420, description: 'Gaza Water Well #14 Zikr Initiative.', category: 'Legacy', currentCount: 842000, target: 1000000, phrase: 'SubhanAllah', joined: true, isModerator: true, legacyMissionId: 'well-14', raised: 8420.00 },
      { id: 'm-002', name: 'Ramadan Warriors', members: 560, description: '30 Days of consistent Adhkar.', category: 'Worship', currentCount: 120000, target: 500000, phrase: 'Astaghfirullah', joined: true, isModerator: false, raised: 1200.00 },
      { id: 'r-001', name: 'Fajr Risers', members: 128, description: 'Morning Adhkar collective room.', category: 'Worship', currentCount: 14502, phrase: 'Alhamdulillah', joined: false },
      { id: 'r-002', name: 'Tajweed Study', members: 45, description: 'Collective Qirat practice room.', category: 'Knowledge', currentCount: 840, phrase: 'Allahu Akbar', joined: false },
    ];
  });

  const [mockContacts] = useState([
    { id: 'c1', name: 'Ahmad Al-Farsi', detail: '+44 7123 456789' },
    { id: 'c2', name: 'Bilal Khalid', detail: 'bilal.k@gmail.com' },
    { id: 'c3', name: 'Zainab Qureshi', detail: '+44 7987 654321' },
    { id: 'c4', name: 'Hassan Malik', detail: 'h.malik@outlook.com' },
    { id: 'c5', name: 'Fatima Noor', detail: '+971 50 123 4567' },
  ]);

  useEffect(() => {
    localStorage.setItem('ashadu_circles_data_v2', JSON.stringify(circles));
  }, [circles]);

  const [newMissionData, setNewMissionData] = useState({
    name: '',
    target: 100000,
    phrase: 'SubhanAllah',
    description: '',
    legacyMissionId: ''
  });

  const activeCircle = circles.find(c => c.id === activeRoomId);

  useEffect(() => {
    if (!activeRoomId) return;
    const interval = setInterval(() => {
      if (Math.random() > 0.7) {
        setSessionCount(prev => prev + 1);
      }
    }, 2000);
    return () => clearInterval(interval);
  }, [activeRoomId]);

  const handleContribute = useCallback(() => {
    setSessionCount(prev => prev + 1);
    if ('vibrate' in navigator) navigator.vibrate(15);
  }, []);

  const handleCreateMission = () => {
    if (!newMissionData.name) return;
    
    const newCircle: Circle = {
      id: `m-${Date.now()}`,
      name: newMissionData.name,
      members: 1,
      description: newMissionData.description,
      category: newMissionData.legacyMissionId ? 'Legacy' : 'Worship',
      currentCount: 0,
      target: newMissionData.target,
      phrase: newMissionData.phrase,
      joined: true,
      isModerator: true,
      legacyMissionId: newMissionData.legacyMissionId,
      raised: 0
    };

    setCircles([newCircle, ...circles]);
    setIsCreating(false);
    setNewMissionData({ name: '', target: 100000, phrase: 'SubhanAllah', description: '', legacyMissionId: '' });
    setIsInviting(newCircle);
  };

  const handleDispatchInvite = useCallback((identifier: string, id: string, isFromFriendList: boolean = false) => {
    if (!identifier || !isInviting) return;
    setInvitedIds(prev => new Set(prev).add(id));
    
    // Simulate receiving an invitation back for demo purposes ONLY if from friend list
    if (isFromFriendList) {
      window.dispatchEvent(new CustomEvent('ashadu_invite_received', {
        detail: {
          invitation: {
            id: `inv-${Math.random().toString(36).substr(2, 9)}`,
            adminName: identifier,
            groupName: isInviting.name,
            description: `You have been invited to join the ${isInviting.name} circle.`,
            customZikr: isInviting.phrase,
            target: isInviting.target,
            endDate: '2026-12-31',
            fundraisingOption: 'PENNY_PER_ZIKR'
          }
        }
      }));
    }

    setTimeout(() => {
      alert(`Amanah Dispatched: Invitation for "${isInviting.name}" sent to ${identifier}.`);
    }, 300);
  }, [isInviting]);

  const handleManualDispatch = useCallback(() => {
    if (!inviteInput.trim() || !isInviting) return;
    handleDispatchInvite(inviteInput, 'manual-' + Math.random().toString(36).substr(2, 9));
    setInviteInput('');
  }, [inviteInput, isInviting, handleDispatchInvite]);

  const handleStartMission = (circle: Circle) => {
    setActiveMissionSession(circle);
  };

  const handleSponsorClick = (circle: Circle) => {
    alert(`Sponsorship Portal Initializing for ${circle.name}...\nRedirecting to secure Sadaqah gateway.`);
  };

  const incrementMissionSession = () => {
    if (!activeMissionSession) return;
    if ('vibrate' in navigator) navigator.vibrate(12);
    
    const newCount = activeMissionSession.currentCount + 1;
    
    // Check for target completion
    if (activeMissionSession.target && newCount === activeMissionSession.target) {
      setShowCompletionPopup(true);
      if ('vibrate' in navigator) navigator.vibrate([100, 50, 100]);
    }

    setCircles(prev => prev.map(c => 
      c.id === activeMissionSession.id 
        ? { ...c, currentCount: newCount, raised: (c.raised || 0) + 0.01 } 
        : c
    ));
    setActiveMissionSession(prev => prev ? { ...prev, currentCount: newCount, raised: (prev.raised || 0) + 0.01 } : null);
    window.dispatchEvent(new CustomEvent('ashadu_mission_increment', {
      detail: { missionId: activeMissionSession.id }
    }));
  };

  if (activeMissionSession) {
    const progress = Math.min(100, (activeMissionSession.currentCount / (activeMissionSession.target || 100)) * 100);
    const radius = 120;
    const circumference = 2 * Math.PI * radius;
    const dashOffset = circumference * (1 - progress / 100);

    return (
      <div className="h-full bg-[#011a14] flex flex-col animate-in fade-in zoom-in-95 duration-500 overflow-hidden font-inter relative">
        <div className="absolute inset-0 celestial-grid opacity-20 pointer-events-none" />
        
        {/* COMPLETION POPUP */}
        {showCompletionPopup && (
          <div className="fixed inset-0 z-[3000] flex items-center justify-center p-6 bg-black/90 backdrop-blur-2xl animate-in zoom-in-95 duration-500">
             <div className="bg-emerald-900 border-2 border-[#C5A059] rounded-[3.5rem] p-12 text-center shadow-[0_0_100px_rgba(197,160,89,0.3)] relative overflow-hidden max-w-sm w-full">
                <div className="absolute inset-0 celestial-grid opacity-20 pointer-events-none" />
                <h2 className="arabic text-6xl text-white mb-4 drop-shadow-[0_0_20px_#C5A059]">الله أكبر</h2>
                <h3 className="text-4xl font-black text-[#C5A059] uppercase tracking-tighter mb-4">ALLAHU AKBAR</h3>
                <p className="text-emerald-400 text-[10px] font-black uppercase tracking-[0.4em] mb-10 leading-relaxed">Mission Target Fulfilled<br/>Divine Praise Multiplied</p>
                <button 
                  onClick={() => setShowCompletionPopup(false)}
                  className="w-full btn-gold py-6 rounded-2xl font-black uppercase tracking-widest text-xs shadow-2xl"
                >
                  Continuue Zikr
                </button>
             </div>
          </div>
        )}

        <header className="p-6 flex justify-between items-center bg-black/40 backdrop-blur-xl border-b border-[#C5A059]/20 z-20">
          <button 
            onClick={() => setActiveMissionSession(null)} 
            className="p-3 bg-emerald-950/50 rounded-2xl text-emerald-500 border border-emerald-900 active:scale-90 transition-all flex items-center gap-2"
          >
            <span className="text-[9px] font-black uppercase tracking-widest">Back to Hub</span>
          </button>
          <div className="text-right">
             <h4 className="text-white font-black text-xs uppercase tracking-tight">{activeMissionSession.name}</h4>
             <p className="text-[8px] text-[#C5A059] font-black uppercase tracking-widest">Active Mission Log</p>
          </div>
        </header>

        <div className="flex-1 flex flex-col items-center justify-center p-8 gap-12">
          <DigitalLantern progress={progress / 100} />

          <div 
            onClick={incrementMissionSession}
            className="relative w-80 h-80 flex items-center justify-center cursor-pointer select-none active:scale-95 transition-transform group"
          >
            <svg className="absolute inset-0 w-full h-full -rotate-90">
              <circle cx="160" cy="160" r={radius} className="stroke-emerald-900/50" strokeWidth="12" fill="transparent" />
              <circle cx="160" cy="160" r={radius}
                className="transition-all duration-700 ease-out stroke-[#C5A059]"
                strokeWidth="12" fill="transparent" strokeDasharray={circumference}
                strokeDashoffset={dashOffset} strokeLinecap="round"
                style={{ filter: 'drop-shadow(0 0 15px rgba(197,160,89,0.5))' }}
              />
            </svg>

            <div className="w-60 h-60 rounded-full flex flex-col items-center justify-center bg-emerald-900/40 backdrop-blur-3xl border border-[#C5A059]/20 shadow-[0_0_80px_rgba(0,0,0,0.5)] group-active:scale-90 transition-all">
               <span className="text-6xl font-black text-white font-mono tracking-tighter">{activeMissionSession.currentCount.toLocaleString()}</span>
               <p className="text-[#C5A059] text-[9px] font-black uppercase tracking-[0.4em] mt-4">MISSION TALLY</p>
               <div className="mt-6 p-4 bg-black/40 rounded-2xl border border-[#C5A059]/20 text-center">
                  <p className="text-[10px] text-emerald-500 font-bold italic leading-tight">"{activeMissionSession.phrase}"</p>
               </div>
            </div>
          </div>

          <div className="w-full max-w-sm bg-black/40 p-6 rounded-[2.5rem] border border-emerald-900 backdrop-blur-md">
             <div className="flex justify-between items-center mb-4 px-2">
                <span className="text-[9px] font-black text-emerald-700 uppercase tracking-widest">COLLECTIVE PROGRESS</span>
                <span className="text-[11px] font-black text-white font-mono">{progress.toFixed(1)}%</span>
             </div>
             <div className="w-full h-2 bg-emerald-950 rounded-full overflow-hidden border border-white/5">
                <div className="h-full bg-gradient-to-r from-emerald-500 to-[#C5A059] transition-all duration-1000" style={{ width: `${progress}%` }} />
             </div>
          </div>
        </div>

        <div className="p-8 text-center bg-black/60 backdrop-blur-xl border-t border-white/5 flex flex-col gap-4">
           <div className="flex items-center justify-center gap-3 opacity-30">
              <p className="text-[9px] font-black text-emerald-500 uppercase tracking-[0.4em]">AMANAH AUTO-SAVE ACTIVE</p>
           </div>
        </div>
      </div>
    );
  }

  if (activeRoomId && activeCircle) {
    return (
      <div className="h-full bg-[#021F1F] flex flex-col animate-in fade-in slide-in-from-right duration-500 overflow-hidden font-inter">
        <div className="p-6 flex justify-between items-center bg-[#053131]/60 border-b border-[#0A4242] backdrop-blur-xl z-20">
          <button 
            onClick={() => setActiveRoomId(null)} 
            className="p-3 bg-[#0A4242]/50 rounded-2xl text-[#C5A059] border border-[#C5A059]/20 active:scale-90 transition-all"
          >
            BACK
          </button>
          
          <div className="flex items-center gap-3 bg-[#053131] px-5 py-2 rounded-full border border-[#4ADE80]/30 shadow-[0_0_15px_rgba(74,222,128,0.1)]">
            <div className="relative">
              <div className="w-2 h-2 bg-[#4ADE80] rounded-full" />
              <div className="absolute inset-0 bg-[#4ADE80] rounded-full animate-ping opacity-75" />
            </div>
            <span className="text-[#4ADE80] text-[9px] font-black uppercase tracking-[0.25em]">LIVE COLLECTIVE SESSION</span>
          </div>
          
          <div className="w-10" />
        </div>

        <div className="flex-1 flex flex-col justify-between p-8 pb-32 overflow-y-auto custom-scrollbar relative">
          <div className="flex flex-col items-center justify-center py-6 relative z-10">
            <div className="w-72 h-72 rounded-full border-2 border-[#C5A059] flex flex-col items-center justify-center bg-[#053131] shadow-[0_0_60px_rgba(197,160,89,0.15)] relative overflow-hidden group">
              <div className="absolute inset-0 bg-gradient-to-br from-[#C5A059]/10 to-transparent pointer-events-none" />
              
              <p className="text-[#C5A059] text-[9px] font-black uppercase tracking-[0.3em] mb-2">TOTAL RECITATIONS</p>
              <h1 className="text-6xl font-black text-white font-mono tracking-tighter my-3 leading-none">
                {sessionCount.toLocaleString()}
              </h1>
              <p className="text-[#4ADE80] text-sm font-bold italic opacity-90 px-8 text-center leading-tight">
                "{activeCircle.phrase}"
              </p>
            </div>
          </div>

          <div className="relative z-10">
            <button 
              onClick={handleContribute}
              className="w-full bg-[#C5A059] hover:bg-[#d4b16a] p-8 rounded-[2.5rem] flex items-center justify-center gap-5 transition-all active:scale-95 shadow-[0_20px_40px_rgba(197,160,89,0.2)] group border-b-[8px] border-[#8c713b]"
            >
              <div className="flex flex-col items-start text-left">
                <span className="text-[#021F1F] text-xs font-black uppercase tracking-[0.2em] mb-1">CONTRIBUTE TO NOOR</span>
                <span className="text-[#021F1F]/50 text-[9px] font-black uppercase tracking-widest">BARAKAH POINT +1</span>
              </div>
              <div className="bg-[#021F1F] p-4 rounded-2xl text-[#C5A059] shadow-inner group-hover:rotate-12 transition-transform">
              </div>
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-y-auto px-6 pb-40 bg-[#021F1F] animate-in fade-in duration-700 custom-scrollbar font-inter">
      <header className="py-10 text-center relative overflow-hidden">
        <h2 className="text-2xl font-black text-white uppercase tracking-[0.2em]">GROUP ZIKR</h2>
        <div className="h-1 w-20 bg-[#C5A059] mx-auto my-4 rounded-full" />
        <p className="text-[9px] font-black text-[#4ADE80] uppercase tracking-[0.4em] mt-2 opacity-80 leading-relaxed max-w-[200px] mx-auto">
          COLLECTIVE MISSIONS & SPIRITUAL SYNCHRONIZATION
        </p>
      </header>

      <div className="flex gap-2 p-1.5 bg-[#053131] rounded-2xl mb-8 border border-[#0A4242] shadow-inner">
        <button 
          onClick={() => setActiveTab('MISSIONS')}
          className={`flex-1 py-4 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === 'MISSIONS' ? 'bg-[#C5A059] text-[#021F1F] shadow-lg' : 'text-[#4D6B6B]'}`}
        >
          Active Missions
        </button>
        <button 
          onClick={() => setActiveTab('LIVE')}
          className={`flex-1 py-4 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === 'LIVE' ? 'bg-[#C5A059] text-[#021F1F] shadow-lg' : 'text-[#4D6B6B]'}`}
        >
          Live Rooms
        </button>
      </div>

      <div className="space-y-6">
        {activeTab === 'MISSIONS' ? (
          <>
            <div className="flex justify-between items-center px-2">
               <h3 className="text-[10px] font-black uppercase text-emerald-600 tracking-[0.4em]">MY CIRCLES</h3>
               <button 
                onClick={() => setIsCreating(true)}
                className="text-[9px] font-black text-[#C5A059] flex items-center gap-1.5 bg-[#C5A059]/10 px-3 py-1.5 rounded-lg border border-[#C5A059]/20 active:scale-95 transition-all"
               >
                 NEW MISSION
               </button>
            </div>
            
            {circles.filter(c => c.joined).map((circle) => (
              <div key={circle.id} className="relative group/card">
                <div className="w-full bg-[#053131] rounded-[2.5rem] border-l-4 border-[#C5A059] shadow-2xl relative overflow-hidden transition-all hover:border-[#4ADE80]">
                  <div className="w-full p-6">
                    <div className="flex justify-between items-start mb-4">
                       <div className="flex items-center gap-4">
                          <div className="w-12 h-12 rounded-2xl bg-[#021F1F] flex items-center justify-center text-[#C5A059] shadow-inner border border-white/5">
                          </div>
                          <div className="text-left">
                            <h4 className="text-white font-black text-lg tracking-tight uppercase">{circle.name}</h4>
                            <p className="text-[9px] text-[#4ADE80] font-black uppercase tracking-widest">
                                {circle.category} • ZIKR CIRCLE 
                                {circle.legacyMissionId && <span className="text-[#C5A059] ml-2">• LINKED MISSION</span>}
                            </p>
                          </div>
                       </div>
                       <button onClick={() => onNavigateToMission(circle.id)} className="p-2 text-[#C5A059]/20 hover:text-[#C5A059] transition-all">
                          GO
                       </button>
                    </div>

                    <div className="space-y-2 mb-6">
                       <div className="flex justify-between items-end px-1">
                          <span className="text-[8px] font-black text-[#4D6B6B] uppercase">MISSION PROGRESS</span>
                          <span className="text-[10px] font-black text-white font-mono">#{circle.currentCount.toLocaleString()} / {circle.target?.toLocaleString()}</span>
                       </div>
                       <div className="w-full h-2.5 bg-black/40 rounded-full overflow-hidden border border-white/5">
                          <div 
                            className="h-full bg-gradient-to-r from-emerald-500 to-[#C5A059] shadow-[0_0_15px_rgba(197,160,89,0.3)] transition-all duration-1000" 
                            style={{ width: `${Math.min(100, (circle.currentCount / (circle.target || 100))*100)}%` }} 
                          />
                       </div>
                    </div>

                    <div className="flex flex-col gap-3">
                       <div className="grid grid-cols-2 gap-3">
                         <div className="flex gap-1.5 h-12">
                           <button 
                             onClick={() => setViewingMembers(circle)}
                             className="flex-[2] bg-[#021F1F] border border-emerald-900 rounded-xl text-[9px] font-black uppercase tracking-widest text-[#4ADE80] flex items-center justify-center gap-2 hover:bg-emerald-950 transition-all active:scale-95"
                           >
                             UMMAH
                           </button>
                           <button 
                             onClick={() => setViewingMembers(circle)}
                             className="flex-1 bg-emerald-950/40 border border-[#4ADE80]/20 rounded-xl text-[10px] font-black text-white flex items-center justify-center font-mono shadow-inner hover:bg-emerald-900 transition-colors"
                           >
                             {circle.members}
                           </button>
                         </div>

                         <div className="flex gap-1.5 h-12">
                           <button 
                             onClick={() => setViewingImpact(circle)}
                             className="flex-[2] bg-[#021F1F] border border-emerald-900 rounded-xl text-[9px] font-black uppercase tracking-widest text-[#C5A059] flex items-center justify-center gap-2 hover:bg-emerald-950 transition-all active:scale-95"
                           >
                             IMPACT
                           </button>
                           <button 
                             onClick={() => setViewingImpact(circle)}
                             className="flex-[3] bg-emerald-950/40 border border-[#C5A059]/20 rounded-xl text-[9px] font-black text-white flex items-center justify-center font-mono shadow-inner hover:bg-emerald-900 transition-colors"
                           >
                             £{(circle.raised || (circle.currentCount * 0.01)).toLocaleString(undefined, { maximumFractionDigits: 0 })}
                           </button>
                         </div>
                       </div>
                       
                       <div className="flex gap-2">
                         <button 
                           onClick={() => handleSponsorClick(circle)}
                           className="flex-1 py-4 bg-amber-500/10 border border-amber-500/30 rounded-2xl text-[10px] font-black uppercase tracking-[0.2em] text-[#C5A059] flex items-center justify-center gap-2 hover:bg-amber-500/20 transition-all active:scale-95 shadow-lg group/sponsor"
                         >
                           Sponsor
                         </button>
                         <button 
                           onClick={() => handleStartMission(circle)}
                           className="flex-[2] bg-[#C5A059] hover:bg-white text-[#021F1F] py-4 rounded-2xl font-black text-[11px] uppercase tracking-[0.2em] flex items-center justify-center gap-2 shadow-xl active:scale-95 transition-all border-b-4 border-[#8c713b]"
                         >
                           Start Zikr
                         </button>
                         {circle.isModerator && (
                           <button 
                             onClick={() => { setIsInviting(circle); setInvitedIds(new Set()); }}
                             className="px-5 bg-emerald-900/50 border border-[#C5A059]/30 text-[#C5A059] rounded-2xl active:scale-95 transition-all hover:bg-emerald-800"
                             title="Invite"
                           >
                             INVITE
                           </button>
                         )}
                       </div>
                    </div>
                  </div>

                  {circle.isModerator && (
                    <div className="bg-[#021F1F]/40 px-6 py-3 border-t border-white/5 flex justify-between items-center">
                       <span className="text-[7px] font-black text-[#C5A059]/60 uppercase tracking-widest flex items-center gap-1">
                          Authority Handshake Active
                       </span>
                       <button onClick={() => onNavigateToMission(circle.id)} className="text-[#4D6B6B] hover:text-white transition-colors text-[10px] font-black uppercase tracking-widest">
                         EDIT
                       </button>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </>
        ) : (
          <>
            <div className="relative group mb-10">
              <input 
                type="text" 
                placeholder="Search global rooms..." 
                className="w-full px-8 py-6 bg-[#053131] border border-[#0A4242] rounded-3xl outline-none text-sm font-bold text-white placeholder:text-[#4D6B6B] shadow-inner"
              />
            </div>

            {circles.filter(c => !c.joined).map((circle) => (
              <button 
                key={circle.id} 
                onClick={() => {
                  setActiveRoomId(circle.id);
                  setSessionCount(circle.currentCount);
                }}
                className="w-full bg-[#053131] rounded-[2.5rem] p-6 flex items-center justify-between group border border-[#0A4242] hover:border-[#C5A059]/40 shadow-xl transition-all"
              >
                <div className="flex items-center gap-6 text-left">
                  <div className="w-16 h-16 bg-[#021F1F] rounded-2xl flex items-center justify-center text-[#4ADE80] font-black text-2xl shadow-xl shrink-0 border border-white/5">
                  </div>
                  <div>
                    <h4 className="text-white font-black text-xl tracking-tight group-hover:text-[#C5A059] transition-colors uppercase">
                      {circle.name}
                    </h4>
                    <p className="text-[9px] text-emerald-600 font-black uppercase tracking-widest mt-1">
                      {circle.members} PEOPLE IN ROOM
                    </p>
                  </div>
                </div>
                <div className="flex flex-col items-end gap-2">
                   <div className="bg-[#4ADE80]/10 px-3 py-1 rounded-lg flex items-center gap-2 border border-[#4ADE80]/20">
                      <div className="w-1.5 h-1.5 bg-[#4ADE80] rounded-full animate-pulse" />
                      <span className="text-[8px] font-black text-[#4ADE80] uppercase tracking-widest">LIVE NOW</span>
                   </div>
                   <span className="text-[10px] font-black text-[#C5A059] font-mono tracking-tighter">#{circle.currentCount.toLocaleString()}</span>
                </div>
              </button>
            ))}
          </>
        )}
      </div>

      {/* MISSION MEMBERS MODAL */}
      {viewingMembers && (
        <div className="fixed inset-0 z-[1002] flex items-center justify-center p-6 bg-black/90 backdrop-blur-xl animate-in fade-in duration-300">
           <div className="bg-[#053131] w-full max-w-sm rounded-[3.5rem] border border-[#4ADE80]/30 shadow-2xl relative overflow-hidden flex flex-col h-[70vh]">
              <header className="p-8 text-center bg-black/20 shrink-0">
                 <div className="w-14 h-14 bg-[#4ADE80]/10 rounded-2xl flex items-center justify-center text-[#4ADE80] mx-auto mb-4 border border-[#4ADE80]/20">
                    {/* UsersRound removed */}
                 </div>
                 <h3 className="text-xl font-black text-white uppercase tracking-tighter">Mission Ummah</h3>
                 <p className="text-[8px] text-[#4ADE80] font-black uppercase tracking-widest mt-2">{viewingMembers.members} Souls synchronized</p>
                 <button onClick={() => setViewingMembers(null)} className="absolute top-6 right-6 p-2 text-emerald-800 hover:text-white transition-colors">CLOSE</button>
              </header>
              <div className="flex-1 overflow-y-auto px-6 py-6 custom-scrollbar space-y-3">
                 {DEMO_PROFILES.slice(0, 10).map((user, i) => (
                   <div key={i} className="bg-black/20 p-4 rounded-2xl border border-white/5 flex items-center justify-between">
                      <div className="flex items-center gap-4">
                         <div className="w-10 h-10 rounded-xl bg-emerald-950 flex items-center justify-center text-[#C5A059] font-black text-xs">{user.name[0]}</div>
                         <div>
                            <p className="text-[11px] font-black text-white">{user.name}</p>
                            <p className="text-[8px] text-emerald-700 font-black uppercase">{user.city} • {user.rank}</p>
                         </div>
                      </div>
                      <div className="text-right">
                         <p className="text-[10px] font-black text-[#4ADE80] font-mono leading-none">+{ (100 + (i * 15)) }</p>
                         <p className="text-[7px] text-emerald-900 font-black uppercase mt-1">Logs contributed</p>
                      </div>
                   </div>
                 ))}
              </div>
              <footer className="p-6 text-center border-t border-white/5 opacity-40">
                 <p className="text-[8px] font-black text-[#C5A059] uppercase tracking-[0.2em]">Collective Barakah Handshake Active</p>
              </footer>
           </div>
        </div>
      )}

      {/* MISSION IMPACT MODAL */}
      {viewingImpact && (
        <div className="fixed inset-0 z-[1002] flex items-center justify-center p-6 bg-black/90 backdrop-blur-xl animate-in fade-in duration-300">
           <div className="bg-[#053131] w-full max-w-sm rounded-[3.5rem] border border-[#C5A059]/30 shadow-2xl relative overflow-hidden flex flex-col">
              <header className="p-10 text-center bg-black/20">
                 <div className="w-16 h-16 bg-[#C5A059]/10 rounded-2xl flex items-center justify-center text-[#C5A059] mx-auto mb-4 border border-[#C5A059]/20">
                    {/* Coins removed */}
                 </div>
                 <h3 className="text-2xl font-black text-white uppercase tracking-tighter">Mission Impact</h3>
                 <p className="text-[9px] text-[#C5A059] font-black uppercase tracking-[0.3em] mt-2">WEALTH PURIFICATION LEDGER</p>
                 <button onClick={() => setViewingImpact(null)} className="absolute top-6 right-6 p-2 text-stone-500 hover:text-white transition-colors">CLOSE</button>
              </header>
              <div className="p-10 space-y-8">
                 <div className="text-center space-y-2">
                    <p className="text-[10px] font-black text-emerald-500 uppercase tracking-widest">Total Funds Raised</p>
                    <h2 className="text-6xl font-black text-white font-mono tracking-tighter">£{(viewingImpact.raised || (viewingImpact.currentCount * 0.01)).toLocaleString(undefined, { minimumFractionDigits: 2 })}</h2>
                 </div>
                 
                 <div className="bg-black/20 p-6 rounded-[2.5rem] border border-emerald-900/50 space-y-4">
                    <div className="flex justify-between items-center">
                       <span className="text-[9px] font-black text-emerald-700 uppercase">Penny Pulse (Zikr)</span>
                       <span className="text-[11px] font-black text-white font-mono">£{(viewingImpact.currentCount * 0.01).toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between items-center">
                       <span className="text-[9px] font-black text-emerald-700 uppercase">External Donations</span>
                       <span className="text-[11px] font-black text-[#C5A059] font-mono">£{((viewingImpact.raised || 0) - (viewingImpact.currentCount * 0.01) > 0 ? (viewingImpact.raised || 0) - (viewingImpact.currentCount * 0.01) : 0).toFixed(2)}</span>
                    </div>
                    <div className="h-px bg-white/5" />
                    <div className="flex justify-between items-center">
                       <span className="text-[10px] font-black text-white uppercase tracking-tight">TOTAL AMANAH</span>
                       <span className="text-[14px] font-black text-[#C5A059] font-mono">£{(viewingImpact.raised || (viewingImpact.currentCount * 0.01)).toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                    </div>
                 </div>

                 <button className="w-full bg-[#C5A059] text-emerald-950 font-black py-6 rounded-3xl shadow-xl flex items-center justify-center gap-3 uppercase tracking-widest text-[10px] active:scale-95 transition-all border-b-4 border-[#8c713b]">
                   View Legacy Dashboard
                 </button>
              </div>
              <footer className="p-8 border-t border-white/5 opacity-30 text-center">
                 <p className="text-[8px] font-black text-emerald-500 uppercase tracking-[0.4em]">Prophetic Financial Precision Verified</p>
              </footer>
           </div>
        </div>
      )}

      {/* CREATE MISSION MODAL (Redesigned as per image) */}
      {isCreating && (
        <div className="fixed inset-0 z-[1000] flex items-center justify-center p-6 bg-black/90 backdrop-blur-xl animate-in fade-in duration-300">
           <div className="bg-[#053131] w-full max-w-sm rounded-[3.5rem] border border-[#C5A059]/20 p-10 shadow-[0_30px_100px_rgba(0,0,0,0.8)] relative overflow-hidden flex flex-col gap-6 font-inter">
              <header className="flex justify-between items-center mb-2">
                 <div className="flex items-center gap-3">
                    <div className="p-3 bg-emerald-950/50 rounded-2xl text-[#C5A059] border border-[#C5A059]/20 shadow-inner">
                       {/* Shield removed */}
                    </div>
                    <div>
                       <h3 className="text-3xl font-black text-white uppercase tracking-tighter leading-none">NEW MISSION</h3>
                       <p className="text-[9px] text-[#C5A059] font-black uppercase tracking-[0.3em] mt-1.5">AMANAH PROTOCOL V2.5</p>
                    </div>
                 </div>
                 <button onClick={() => setIsCreating(false)} className="p-3 bg-black/40 text-stone-500 rounded-2xl hover:text-white transition-colors active:scale-90">CLOSE</button>
              </header>

              <div className="space-y-6">
                 <div className="space-y-3">
                    <label className="text-[10px] font-black uppercase text-emerald-500 tracking-[0.2em] ml-1">MISSION IDENTIFIER</label>
                    <div className="relative">
                      <input 
                        type="text" 
                        placeholder="e.g. Daily Salawat Collective" 
                        value={newMissionData.name}
                        onChange={e => setNewMissionData({...newMissionData, name: e.target.value})}
                        className="w-full bg-black/40 border border-emerald-900 rounded-2xl p-6 text-sm font-bold text-white outline-none focus:border-[#C5A059] transition-all placeholder:text-stone-700 shadow-inner"
                      />
                    </div>
                 </div>

                 <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-3">
                        <label className="text-[10px] font-black uppercase text-emerald-500 tracking-[0.2em] ml-1">TARGET QUOTA</label>
                        <input 
                            type="number" 
                            value={newMissionData.target}
                            onChange={e => setNewMissionData({...newMissionData, target: parseInt(e.target.value) || 0})}
                            className="w-full bg-black/40 border border-emerald-900 rounded-2xl p-6 text-sm font-black text-white outline-none focus:border-[#C5A059] transition-all font-mono"
                        />
                    </div>
                    <div className="space-y-3">
                        <label className="text-[10px] font-black uppercase text-emerald-500 tracking-[0.2em] ml-1">ZIKR PHRASE</label>
                        <select 
                            value={newMissionData.phrase}
                            onChange={e => setNewMissionData({...newMissionData, phrase: e.target.value})}
                            className="w-full bg-black/40 border border-emerald-800 rounded-2xl p-6 text-[10px] font-black uppercase text-white outline-none focus:border-[#C5A059] transition-all appearance-none cursor-pointer"
                        >
                            <option>SUBHANALLAH</option>
                            <option>ALHAMDULILLAH</option>
                            <option>ALLAHU AKBAR</option>
                            <option>ASTAGHFIRULLAH</option>
                        </select>
                    </div>
                 </div>

                 <div className="space-y-3">
                    <label className="text-[10px] font-black uppercase text-emerald-500 tracking-[0.2em] ml-1">LEGACY MISSION LINK</label>
                    <select 
                        value={newMissionData.legacyMissionId}
                        onChange={e => setNewMissionData({...newMissionData, legacyMissionId: e.target.value})}
                        className="w-full bg-black/40 border border-emerald-900 rounded-2xl p-6 text-[10px] font-black uppercase text-white outline-none focus:border-[#C5A059] transition-all appearance-none cursor-pointer"
                    >
                        <option value="">-- UNLINKED --</option>
                        {legacyProjects.map(p => (
                          <option key={p.id} value={p.id}>{p.name.toUpperCase()}</option>
                        ))}
                    </select>
                 </div>

                 <div className="space-y-3">
                    <label className="text-[10px] font-black uppercase text-emerald-500 tracking-[0.2em] ml-1">MISSION CONTEXT</label>
                    <textarea 
                      placeholder="Define the spiritual goal of this circle..." 
                      value={newMissionData.description}
                      onChange={e => setNewMissionData({...newMissionData, description: e.target.value})}
                      className="w-full bg-black/40 border border-emerald-900 rounded-2xl p-6 text-sm text-stone-300 outline-none focus:border-[#C5A059] h-24 resize-none shadow-inner"
                    />
                 </div>
              </div>

              <button 
                onClick={handleCreateMission}
                className="w-full bg-[#C5A059] hover:bg-white text-emerald-950 font-black py-7 rounded-[2rem] shadow-2xl active:scale-95 transition-all flex items-center justify-center gap-3 uppercase tracking-[0.3em] text-xs border-b-8 border-[#8c713b] mt-4"
              >
                INITIALIZE MISSION
              </button>
           </div>
        </div>
      )}

      {/* INVITE USERS MODAL (ENHANCED) */}
      {isInviting && (
        <div className="fixed inset-0 z-[1001] flex items-center justify-center p-6 bg-[#021F1F]/95 backdrop-blur-2xl animate-in fade-in duration-300">
           <div className="bg-[#053131] w-full max-w-sm rounded-[3.5rem] border border-[#4ADE80]/30 shadow-2xl relative overflow-hidden flex flex-col h-[80vh] max-h-[700px]">
              <header className="p-8 text-center bg-black/20 shrink-0">
                 <div className="w-14 h-14 bg-[#4ADE80]/10 rounded-2xl flex items-center justify-center text-[#4ADE80] mx-auto mb-4 border border-[#4ADE80]/20">
                    {/* UserPlus removed */}
                 </div>
                 <h3 className="text-xl font-black text-white uppercase tracking-tighter leading-none">Invite Souls</h3>
                 <p className="text-[8px] text-[#4ADE80] font-black uppercase tracking-widest mt-2">Expanding "{isInviting.name}"</p>
                 
                 <button 
                  onClick={() => { setIsInviting(null); setInvitedIds(new Set()); setSearchInviteQuery(''); }} 
                  className="absolute top-6 right-6 p-2 text-emerald-800 hover:text-white transition-colors"
                 >
                   CLOSE
                 </button>
              </header>

              <div className="px-8 flex gap-2 py-4 bg-black/10 shrink-0">
                 <button 
                  onClick={() => setInviteTab('FRIENDS')} 
                  className={`flex-1 py-3 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all flex items-center justify-center gap-2 ${inviteTab === 'FRIENDS' ? 'bg-[#C5A059] text-emerald-950 shadow-lg' : 'bg-emerald-950/30 text-emerald-700'}`}
                 >
                   Ummah
                 </button>
                 <button 
                  onClick={() => setInviteTab('CONTACTS')} 
                  className={`flex-1 py-3 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all flex items-center justify-center gap-2 ${inviteTab === 'CONTACTS' ? 'bg-[#C5A059] text-emerald-950 shadow-lg' : 'bg-emerald-950/30 text-emerald-700'}`}
                 >
                   Ledger
                 </button>
                 <button 
                  onClick={() => setInviteTab('DIRECT')} 
                  className={`flex-1 py-3 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all flex items-center justify-center gap-2 ${inviteTab === 'DIRECT' ? 'bg-[#C5A059] text-emerald-950 shadow-lg' : 'bg-emerald-950/30 text-emerald-700'}`}
                 >
                   Direct
                 </button>
              </div>

              <div className="flex-1 overflow-y-auto px-8 py-6 custom-scrollbar space-y-4">
                 {inviteTab === 'DIRECT' ? (
                   <div className="space-y-6 animate-in fade-in duration-300">
                      <div className="relative">
                         <input 
                           type="text" 
                           placeholder="Email or @username" 
                           value={inviteInput}
                           onChange={e => setInviteInput(e.target.value)}
                           className="w-full bg-black/40 border border-emerald-800 rounded-2xl py-5 px-5 text-sm font-bold text-white outline-none focus:border-[#4ADE80] transition-all placeholder:text-emerald-950 shadow-inner"
                         />
                      </div>
                      <div className="p-4 bg-[#4ADE80]/5 rounded-2xl border border-dashed border-[#4ADE80]/20 text-center">
                         <p className="text-[10px] text-emerald-100/60 leading-relaxed font-medium">
                           Manually dispatch a spiritual invite link to any soul.
                         </p>
                      </div>
                      <button 
                        onClick={handleManualDispatch}
                        className="w-full py-5 bg-[#4ADE80] text-[#021F1F] rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-lg flex items-center justify-center gap-2 active:scale-95 transition-all"
                      >
                        Dispatch Invite
                      </button>
                   </div>
                 ) : (
                   <div className="space-y-4 animate-in fade-in duration-300">
                      <div className="relative mb-4">
                        <input 
                          type="text" 
                          placeholder={`Search ${inviteTab.toLowerCase()}...`} 
                          value={searchInviteQuery}
                          onChange={e => setSearchInviteQuery(e.target.value)}
                          className="w-full bg-black/20 border border-emerald-900 rounded-xl py-3 px-4 text-[10px] font-bold text-white outline-none focus:border-[#C5A059] transition-all"
                        />
                      </div>

                      <div className="space-y-2">
                        {inviteTab === 'FRIENDS' ? (
                          DEMO_PROFILES
                            .filter(f => f.name.toLowerCase().includes(searchInviteQuery.toLowerCase()))
                            .slice(0, 10)
                            .map(friend => (
                              <div key={friend.id} className="bg-black/20 p-4 rounded-2xl border border-white/5 flex items-center justify-between group hover:border-[#4ADE80]/30 transition-all">
                                <div className="flex items-center gap-3">
                                   <div className="w-10 h-10 rounded-xl bg-emerald-900 flex items-center justify-center text-[#C5A059] font-black text-xs border border-white/5">
                                      {friend.name[0]}
                                   </div>
                                   <div>
                                      <p className="text-[11px] font-black text-white">{friend.name}</p>
                                      <p className="text-[8px] text-emerald-700 font-black uppercase">{friend.city} • {friend.rank}</p>
                                   </div>
                                </div>
                                <button 
                                  onClick={() => handleDispatchInvite(friend.name, friend.id)}
                                  disabled={invitedIds.has(friend.id)}
                                  className={`p-2.5 rounded-lg transition-all ${invitedIds.has(friend.id) ? 'bg-emerald-500/10 text-emerald-500 border border-emerald-500/20' : 'bg-[#C5A059]/10 text-[#C5A059] border border-[#C5A059]/30 hover:bg-[#C5A059] hover:text-emerald-950 active:scale-90'}`}
                                >
                                  {invitedIds.has(friend.id) ? 'DONE' : 'INVITE'}
                                </button>
                              </div>
                            ))
                        ) : (
                          mockContacts
                            .filter(c => c.name.toLowerCase().includes(searchInviteQuery.toLowerCase()))
                            .map(contact => (
                              <div key={contact.id} className="bg-black/20 p-4 rounded-2xl border border-white/5 flex items-center justify-between group hover:border-[#4ADE80]/30 transition-all">
                                <div className="flex items-center gap-3">
                                   <div className="w-10 h-10 rounded-xl bg-black/40 flex items-center justify-center text-emerald-700 font-black text-xs border border-white/5">
                                      {contact.name[0]}
                                   </div>
                                   <div>
                                      <p className="text-[11px] font-black text-white">{contact.name}</p>
                                      <p className="text-[8px] text-emerald-900 font-bold">{contact.detail}</p>
                                   </div>
                                </div>
                                <button 
                                  onClick={() => handleDispatchInvite(contact.name, contact.id)}
                                  disabled={invitedIds.has(contact.id)}
                                  className={`p-2.5 rounded-lg transition-all ${invitedIds.has(contact.id) ? 'bg-emerald-500/10 text-emerald-500 border border-emerald-500/20' : 'bg-emerald-900 text-[#C5A059] border border-[#C5A059]/30 hover:bg-[#C5A059] hover:text-emerald-950 active:scale-90'}`}
                                >
                                  {invitedIds.has(contact.id) ? 'DONE' : 'INVITE'}
                                </button>
                              </div>
                            ))
                        )}
                      </div>
                   </div>
                 )}
              </div>

              <footer className="p-8 bg-black/20 shrink-0 border-t border-white/5">
                 <div className="flex items-center justify-center gap-2 opacity-30">
                    {/* ShieldCheck removed */}
                    <span className="text-[8px] font-black uppercase tracking-widest text-emerald-400">Secure collective handshake active</span>
                 </div>
              </footer>
           </div>
        </div>
      )}

      <div className="mt-14 p-10 bg-black/20 border border-dashed border-[#0A4242] rounded-[3rem] text-center">
         <h4 className="text-white font-black text-sm uppercase tracking-tight">Ummah Archives</h4>
         <p className="text-[9px] text-[#4D6B6B] font-black uppercase tracking-widest mt-2">View your collective session history</p>
      </div>
    </div>
  );
};

export default CommunityCircles;