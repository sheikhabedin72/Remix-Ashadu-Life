import React, { useMemo } from 'react';
import { Trophy, Flame, ChevronRight, Medal } from 'lucide-react';
import { DEMO_PROFILES } from '../constants';

const LeaderboardView: React.FC = () => {
  const rankingData = useMemo(() => {
    return [...DEMO_PROFILES]
      .sort((a, b) => {
        const rankPriority: Record<string, number> = { 'Elite': 3, 'Gold': 2, 'Silver': 1, 'Bronze': 0 };
        const diff = rankPriority[b.rank] - rankPriority[a.rank];
        if (diff !== 0) return diff;
        return b.streak - a.streak;
      })
      .slice(0, 15)
      .map((user, index) => ({ ...user, rankPos: index + 1 }));
  }, []);

  return (
    <div className="h-full flex flex-col bg-[#022c22] animate-in fade-in duration-700 overflow-hidden relative">
      <div className="absolute inset-0 celestial-grid opacity-10 pointer-events-none" />

      <div className="pt-10 pb-10 flex flex-col items-center bg-black/40 border-b border-[#C5A059]/20 shadow-2xl shrink-0 backdrop-blur-xl">
        <Trophy size={48} className="text-[#C5A059] mb-4 drop-shadow-[0_0_15px_rgba(197,160,89,0.3)]" />
        <h2 className="text-xl font-black text-white uppercase tracking-[0.4em]">Global Standings</h2>
        <p className="text-[9px] font-black text-emerald-500 uppercase mt-2">Ummah Performance Index</p>
      </div>

      <div className="flex-1 overflow-y-auto px-4 pt-6 pb-40 space-y-4 custom-scrollbar relative z-10">
        {rankingData.map((item) => (
          <div 
            key={item.id} 
            className="flex items-center p-5 bg-emerald-900/30 border border-white/5 rounded-2xl shadow-xl active:scale-[0.98] transition-all hover:bg-emerald-900/50"
          >
            <div className="w-10 shrink-0 font-black text-emerald-700 text-lg tracking-tighter">#{item.rankPos}</div>
            
            <div className={`w-12 h-12 rounded-xl flex items-center justify-center border shrink-0
              ${item.rankPos <= 3 ? 'bg-[#C5A059] text-[#022c22] border-[#C5A059]' : 'bg-emerald-950 text-white border-white/10'}`}>
              <span className="font-black text-lg">{item.name.charAt(0)}</span>
            </div>

            <div className="ml-5 flex-1">
              <h4 className="text-white font-black text-sm uppercase tracking-tight">{item.name}</h4>
              <div className="flex items-center gap-1 mt-1">
                <Flame size={10} className="text-[#C5A059]" />
                <span className="text-emerald-600 text-[9px] font-black uppercase tracking-widest">{item.streak} DAY STREAK</span>
              </div>
            </div>

            <div className="text-right">
              <p className="text-white font-black text-sm font-mono tracking-tighter">{item.impact}</p>
              <p className={`text-[8px] font-black uppercase tracking-widest mt-0.5 ${item.rank === 'Elite' ? 'text-[#C5A059]' : 'text-emerald-700'}`}>{item.rank}</p>
            </div>
            
            <ChevronRight size={20} className="text-emerald-950 ml-3" />
          </div>
        ))}
      </div>
    </div>
  );
};

export default LeaderboardView;