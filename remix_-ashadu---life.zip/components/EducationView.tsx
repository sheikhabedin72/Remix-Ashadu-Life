
import React from 'react';
import { BookOpen, ChevronRight, Lock, CheckCircle2, Sparkles, Trophy } from 'lucide-react';
import { Lesson, UserStats } from '../types';
import { INITIAL_LESSONS } from '../constants';

interface EducationViewProps {
  stats: UserStats;
  onCompleteLesson: (lesson: Lesson) => void;
}

const EducationView: React.FC<EducationViewProps> = ({ stats, onCompleteLesson }) => {
  return (
    <div className="flex-1 overflow-y-auto px-6 pb-40 bg-emerald-950 animate-in fade-in duration-700">
      <div className="py-8 mb-4">
        <h2 className="text-3xl font-black text-amber-500 tracking-tight">Path of Knowledge</h2>
        <p className="text-[10px] text-emerald-400 uppercase tracking-[0.3em] mt-1">Step-by-step guidance</p>
      </div>

      <div className="relative space-y-10 pl-2">
        {/* The Path Line */}
        <div className="absolute left-7 top-4 bottom-4 w-1 bg-emerald-900 rounded-full" />

        {INITIAL_LESSONS.map((lesson, idx) => {
          const isCompleted = stats.completedLessonIds.includes(lesson.id);
          const isLocked = lesson.level > (stats.completedLessonIds.length + 1);
          
          return (
            <div key={lesson.id} className={`relative flex items-start gap-8 group ${isLocked ? 'opacity-50' : 'opacity-100'}`}>
              {/* Milestone Indicator */}
              <div className={`w-10 h-10 rounded-full flex items-center justify-center z-10 transition-all duration-500 shadow-xl 
                ${isCompleted ? 'bg-emerald-500 text-white' : isLocked ? 'bg-emerald-900 text-emerald-700' : 'bg-amber-500 text-emerald-950 shadow-amber-500/20'}`}>
                {isCompleted ? <CheckCircle2 size={20} /> : isLocked ? <Lock size={18} /> : <span className="font-black text-sm">{lesson.level}</span>}
              </div>

              {/* Lesson Card */}
              <div className={`flex-1 p-6 rounded-[2.5rem] border transition-all duration-500 relative overflow-hidden
                ${isCompleted ? 'bg-emerald-900/40 border-emerald-500/30' : 
                  isLocked ? 'bg-transparent border-dashed border-emerald-900' : 'bg-white/5 border-amber-500/30 shadow-2xl'}`}>
                
                <div className="flex justify-between items-start mb-2">
                   <div>
                      <h4 className={`font-black text-lg tracking-tight ${isLocked ? 'text-emerald-800' : 'text-white'}`}>{lesson.title}</h4>
                      <p className={`text-[10px] font-bold uppercase tracking-widest mt-1 ${isLocked ? 'text-emerald-900' : 'text-emerald-500'}`}>{lesson.category}</p>
                   </div>
                   {!isLocked && !isCompleted && (
                     <Sparkles size={16} className="text-amber-500 animate-pulse" />
                   )}
                </div>

                <p className={`text-xs leading-relaxed mb-6 ${isLocked ? 'text-emerald-900 italic' : 'text-emerald-200/70'}`}>
                  {isLocked ? "Complete previous level to unlock" : lesson.description}
                </p>

                {!isLocked && (
                  <div className="flex justify-between items-center">
                    <div className="flex items-center gap-2">
                       <Trophy size={14} className="text-amber-500" />
                       <span className="text-[10px] font-black text-amber-500 uppercase tracking-widest">Reward: £{lesson.creditReward.toFixed(2)}</span>
                    </div>
                    {!isCompleted ? (
                      <button 
                        onClick={() => onCompleteLesson(lesson)}
                        className="bg-amber-500 hover:bg-amber-400 text-emerald-950 text-[9px] font-black uppercase px-4 py-2 rounded-xl transition-all flex items-center gap-2 group-hover:gap-3"
                      >
                        Start Lesson <ChevronRight size={12} />
                      </button>
                    ) : (
                      <span className="text-[9px] font-black text-emerald-500 uppercase tracking-widest">Mastered</span>
                    )}
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Revert Support Card */}
      <div className="mt-16 p-8 bg-gradient-to-br from-amber-500/10 to-transparent rounded-[3rem] border border-amber-500/20 text-center">
         <BookOpen size={32} className="text-amber-500 mx-auto mb-4" />
         <h3 className="text-white font-black text-lg mb-2">Knowledge is Noor</h3>
         <p className="text-emerald-400 text-xs leading-relaxed max-w-[240px] mx-auto font-medium">
           Every step you take to understand your faith erases burdens and builds barakah.
         </p>
      </div>
    </div>
  );
};

export default EducationView;
