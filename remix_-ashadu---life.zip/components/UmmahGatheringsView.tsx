
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { MapPin, Clock, Ghost, Shield, User, Landmark, ChevronRight, Calendar } from 'lucide-react';
import { UserProfile } from '../types';

interface Encounter {
  id: string;
  locationName: string;
  locationType: 'Masjid' | 'Center' | 'Library';
  time: string;
  user: {
    name: string;
    avatarColor: string;
    role: string;
  };
  context: string;
}

const MOCK_ENCOUNTERS: Encounter[] = [
  {
    id: '1',
    locationName: 'Al-Noor Islamic Center',
    locationType: 'Masjid',
    time: 'During Asr (2h ago)',
    user: { name: 'Ibrahim', avatarColor: 'bg-emerald-600', role: 'Architect' },
    context: 'You both visited Al-Noor Center during Asr prayer.'
  },
  {
    id: '2',
    locationName: 'Central Library Musalla',
    locationType: 'Library',
    time: 'Today, 12:30 PM',
    user: { name: 'Sara', avatarColor: 'bg-amber-600', role: 'Student' },
    context: 'Crossed paths near the prayer area.'
  },
  {
    id: '3',
    locationName: 'East London Mosque',
    locationType: 'Masjid',
    time: 'Yesterday, Isha',
    user: { name: 'Omar', avatarColor: 'bg-indigo-600', role: 'Volunteer' },
    context: 'Both attended the evening congregation.'
  }
];

interface UmmahGatheringsViewProps {
  user: UserProfile | null;
}

const UmmahGatheringsView: React.FC<UmmahGatheringsViewProps> = ({ user }) => {
  const [isGhostMode, setIsGhostMode] = useState(false);

  return (
    <div className="flex-1 overflow-y-auto px-6 pb-32 pt-6 bg-[#022c22] font-inter">
      <header className="mb-8 flex justify-between items-start">
        <div>
          <h2 className="text-3xl font-black text-white tracking-tighter uppercase leading-none">
            Ummah <span className="text-[#C5A059]">Gatherings</span>
          </h2>
          <p className="text-[10px] text-emerald-500 font-black uppercase tracking-[0.3em] mt-2">Spiritual Proximity Tracking</p>
        </div>
        <button 
          onClick={() => setIsGhostMode(!isGhostMode)}
          className={`p-4 rounded-2xl border transition-all flex flex-col items-center gap-1 ${
            isGhostMode 
              ? 'bg-rose-500/10 border-rose-500/30 text-rose-500' 
              : 'bg-emerald-950 border-emerald-800 text-emerald-600'
          }`}
        >
          <Ghost size={20} />
          <span className="text-[7px] font-black uppercase tracking-widest">{isGhostMode ? 'GHOST ON' : 'GO GHOST'}</span>
        </button>
      </header>

      {isGhostMode && (
        <div className="mb-8 p-6 bg-rose-500/10 border border-rose-500/20 rounded-3xl flex items-center gap-4">
          <Shield className="text-rose-500 shrink-0" size={24} />
          <p className="text-[10px] font-black text-rose-200 uppercase tracking-widest leading-relaxed">
            Ghost Mode Active: Your location is hidden from the timeline. You will not appear in others' proximity lists.
          </p>
        </div>
      )}

      <div className="space-y-6">
        <h3 className="text-[10px] font-black text-emerald-800 uppercase tracking-[0.4em] mb-4">Who was at the Masjid?</h3>
        
        {MOCK_ENCOUNTERS.map((encounter) => (
          <motion.div
            key={encounter.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="relative group"
          >
            <div className="absolute left-5 top-12 bottom-0 w-px bg-emerald-800/30 group-last:hidden" />
            
            <div className="flex gap-6">
              <div className="relative z-10">
                <div className="w-10 h-10 bg-emerald-950 border border-emerald-800 rounded-2xl flex items-center justify-center text-[#C5A059] shadow-lg">
                  <Landmark size={18} />
                </div>
              </div>
              
              <div className="flex-1 bg-emerald-900/10 border border-emerald-800/20 rounded-[2rem] p-6 hover:bg-emerald-900/20 transition-all cursor-pointer">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h4 className="text-sm font-black text-white uppercase tracking-tight">{encounter.locationName}</h4>
                    <div className="flex items-center gap-2 text-[9px] text-emerald-600 font-bold uppercase tracking-widest mt-1">
                      <Clock size={10} />
                      {encounter.time}
                    </div>
                  </div>
                  <ChevronRight size={16} className="text-emerald-800" />
                </div>

                <div className="flex items-center gap-3 p-4 bg-emerald-950/50 rounded-2xl border border-emerald-800/30">
                  <div className={`w-8 h-8 ${encounter.user.avatarColor} rounded-xl flex items-center justify-center text-white font-black text-[10px]`}>
                    {encounter.user.name[0]}
                  </div>
                  <div>
                    <p className="text-[10px] text-emerald-100 font-black uppercase tracking-tight">
                      {encounter.user.name} <span className="text-emerald-600 ml-1">• {encounter.user.role}</span>
                    </p>
                    <p className="text-[9px] text-[#C5A059] font-bold uppercase tracking-widest mt-0.5">
                      {encounter.context}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      <footer className="mt-12 p-8 bg-emerald-900/20 border border-emerald-800/30 rounded-[3rem] text-center">
        <div className="w-12 h-12 bg-emerald-500/10 rounded-full flex items-center justify-center mx-auto mb-4 text-emerald-500">
          <MapPin size={24} />
        </div>
        <h4 className="text-xs font-black text-white uppercase tracking-widest mb-2">Proximity Protocol</h4>
        <p className="text-[9px] text-emerald-600 font-bold uppercase tracking-[0.2em] leading-relaxed">
          We only track encounters within 300m of registered Community Hubs. Your privacy is our Amanah.
        </p>
      </footer>
    </div>
  );
};

export default UmmahGatheringsView;
