import React, { useState, useEffect, useMemo } from 'react';
import { 
  Clock, 
  Check, 
  PlusCircle, 
  List, 
  Zap, 
  Bell, 
  BellOff, 
  ShieldCheck, 
  Info,
  AlertCircle,
  History,
  Target,
  Sparkles,
  Calendar,
  RotateCcw,
  Volume2,
  VolumeX,
  Music,
  Settings2,
  ChevronDown
} from 'lucide-react';

import { fetchPrayerTimes, parseTimeString, formatTime12h } from '../services/prayerService';

interface Prayer {
  name: string;
  time: string;
  hour: number;
  minute: number;
  status: 'completed' | 'missed' | 'pending';
}

interface SalahGuideViewProps {
  onComplete?: (credits: number) => void;
  coords?: { lat: number; lon: number } | null;
}

const getPrayerSchedule = (prayerTimes?: any) => {
  const isFriday = new Date().getDay() === 5;
  
  let schedule: Omit<Prayer, 'status'>[];

  if (prayerTimes) {
    const names = ['Fajr', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'];
    schedule = names.map(name => {
      const timeStr = prayerTimes[name];
      const { hour, minute } = parseTimeString(timeStr);
      return {
        name: name.toUpperCase(),
        time: formatTime12h(hour, minute),
        hour,
        minute
      };
    });
    
    // Add Witr
    schedule.push({ name: 'WITR', time: '04:30 AM', hour: 4, minute: 30 });
  } else {
    schedule = [
      { name: 'FAJR', time: '05:12 AM', hour: 5, minute: 12 },
      { name: 'DHUHR', time: '12:34 PM', hour: 12, minute: 34 },
      { name: 'ASR', time: '03:45 PM', hour: 15, minute: 45 },
      { name: 'MAGHRIB', time: '06:10 PM', hour: 18, minute: 10 },
      { name: 'ISHA', time: '07:30 PM', hour: 19, minute: 30 },
      { name: 'WITR', time: '04:30 AM', hour: 4, minute: 30 },
    ];
  }

  if (isFriday) {
    schedule.push({ name: 'FRIDAY JUMMUAH', time: '01:15 PM', hour: 13, minute: 15 });
  }

  return schedule;
};

const SalahGuideView: React.FC<SalahGuideViewProps> = ({ onComplete, coords }) => {
  const [prayerTimes, setPrayerTimes] = useState<any>(null);

  useEffect(() => {
    const getTimes = async () => {
      if (coords) {
        const times = await fetchPrayerTimes(coords.lat, coords.lon);
        setPrayerTimes(times);
      }
    };
    getTimes();
  }, [coords]);

  // --- NOTIFICATION ENGINE STATE ---
  const [notificationsEnabled, setNotificationsEnabled] = useState(() => {
    const saved = localStorage.getItem('ashadu_notif_enabled');
    return saved ? JSON.parse(saved) : true;
  });
  const [notificationMode, setNotificationMode] = useState<'silent' | 'tone'>(() => {
    return (localStorage.getItem('ashadu_notif_mode') as 'silent' | 'tone') || 'tone';
  });
  const [adhanSource, setAdhanSource] = useState<'MAKKAH' | 'MADINA' | 'DEVICE'>(() => {
    return (localStorage.getItem('ashadu_notif_source') as any) || 'MAKKAH';
  });
  const [selectedDeviceTone, setSelectedDeviceTone] = useState(() => {
    return localStorage.getItem('ashadu_selected_device_tone') || 'Standard Echo';
  });

  const deviceTones = ['Standard Echo', 'Emerald Chime', 'Digital Adhan', 'Soft Aura', 'Prophetic Pulse'];

  // Persistence Sync
  useEffect(() => {
    localStorage.setItem('ashadu_notif_enabled', JSON.stringify(notificationsEnabled));
    localStorage.setItem('ashadu_notif_mode', notificationMode);
    localStorage.setItem('ashadu_notif_source', adhanSource);
    localStorage.setItem('ashadu_selected_device_tone', selectedDeviceTone);
  }, [notificationsEnabled, notificationMode, adhanSource, selectedDeviceTone]);

  const currentSchedule = useMemo(() => getPrayerSchedule(prayerTimes), [prayerTimes]);
  
  const [qadaLog, setQadaLog] = useState(() => {
    const saved = localStorage.getItem('ashadu_qada_log');
    return saved ? JSON.parse(saved) : { Fajr: 0, Dhuhr: 0, Asr: 0, Maghrib: 0, Isha: 0, Witr: 0, 'Friday jummuah': 0 };
  });

  const [dob, setDob] = useState(() => {
    return localStorage.getItem('ashadu_user_dob') || '';
  });

  const [activeQadaTab, setActiveQadaTab] = useState<'manual' | 'dob'>('manual');

  // --- COMPENSATORY SESSION STATE ---
  const [showCompensatory, setShowCompensatory] = useState(false);
  const [compDate, setCompDate] = useState(new Date().toISOString().split('T')[0]);
  const [compSalah, setCompSalah] = useState('Fajr');
  const [compHistory, setCompHistory] = useState<Record<string, Record<string, 'done' | 'missed'>>>(() => {
    const saved = localStorage.getItem('ashadu_comp_history');
    return saved ? JSON.parse(saved) : {};
  });

  const calculatedQada = useMemo(() => {
    if (!dob) return 0;
    const birthDate = new Date(dob);
    const today = new Date();
    const diffTime = Math.abs(today.getTime() - birthDate.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays * 5;
  }, [dob]);

  const totalDone = useMemo(() => {
    let count = 0;
    Object.values(compHistory).forEach(day => {
      Object.values(day).forEach(status => {
        if (status === 'done') count++;
      });
    });
    return count;
  }, [compHistory]);

  const totalQada = useMemo(() => {
    return Object.values(qadaLog).reduce((acc, val) => acc + (val as number), 0);
  }, [qadaLog]);

  const totalMissed = useMemo(() => {
    return calculatedQada + totalQada;
  }, [calculatedQada, totalQada]);

  const outstanding = useMemo(() => {
    return Math.max(0, totalMissed - totalDone);
  }, [totalMissed, totalDone]);

  const [prayers, setPrayers] = useState<Prayer[]>(() => {
    const saved = localStorage.getItem('ashadu_daily_prayers');
    const lastDate = localStorage.getItem('ashadu_last_salah_check_date');
    const todayStr = new Date().toISOString().split('T')[0];
    const isFriday = new Date().getDay() === 5;
    
    if (saved && lastDate === todayStr) {
      const parsed = JSON.parse(saved);
      const hasJummuahInStore = parsed.some((p: Prayer) => p.name === 'FRIDAY JUMMUAH');
      if (isFriday !== hasJummuahInStore) {
        return currentSchedule.map(p => ({ ...p, status: 'pending' as const }));
      }
      return parsed;
    }
    return currentSchedule.map(p => ({ ...p, status: 'pending' as const }));
  });

  // Auto-log missed prayers from previous days
  useEffect(() => {
    const checkDayChange = () => {
      const lastDate = localStorage.getItem('ashadu_last_salah_check_date');
      const todayStr = new Date().toISOString().split('T')[0];
      
      if (lastDate && lastDate !== todayStr) {
        const savedPrayers = localStorage.getItem('ashadu_daily_prayers');
        if (savedPrayers) {
          try {
            const parsed: Prayer[] = JSON.parse(savedPrayers);
            const missedUpdates: Record<string, number> = {};
            parsed.forEach(p => {
              if (p.status === 'pending') {
                const name = p.name.charAt(0) + p.name.slice(1).toLowerCase();
                missedUpdates[name] = (missedUpdates[name] || 0) + 1;
              }
            });
            
            if (Object.keys(missedUpdates).length > 0) {
              setQadaLog(prev => {
                const next = { ...prev };
                Object.keys(missedUpdates).forEach(name => {
                  next[name] = (next[name] || 0) + missedUpdates[name];
                });
                return next;
              });
            }
          } catch (e) {
            console.error("Failed to parse saved prayers", e);
          }
        }
        // Reset prayers for the new day
        setPrayers(currentSchedule.map(p => ({ ...p, status: 'pending' as const })));
      }
      localStorage.setItem('ashadu_last_salah_check_date', todayStr);
    };

    checkDayChange();
    const interval = setInterval(checkDayChange, 60000); // Check every minute
    return () => clearInterval(interval);
  }, [currentSchedule]);

  // Update prayers when schedule changes
  useEffect(() => {
    if (prayerTimes) {
      const updatePrayers = () => {
        setPrayers(prev => {
          return currentSchedule.map(p => {
            const existing = prev.find(ep => ep.name === p.name);
            return { ...p, status: existing ? existing.status : 'pending' as const };
          });
        });
      };
      
      // Use requestAnimationFrame to avoid "synchronous" setState in effect warning
      const frame = requestAnimationFrame(updatePrayers);
      return () => cancelAnimationFrame(frame);
    }
  }, [currentSchedule, prayerTimes]);

  const [countdown, setCountdown] = useState('--:--');
  const [nextPrayerName, setNextPrayerName] = useState('FAJR');
  const [lastNotifiedPrayer, setLastNotifiedPrayer] = useState<string | null>(null);

  useEffect(() => {
    const timer = setInterval(() => {
      const now = new Date();
      const currentHour = now.getHours();
      const currentMinute = now.getMinutes();
      const chronological = [...currentSchedule].sort((a, b) => (a.hour * 60 + a.minute) - (b.hour * 60 + b.minute));
      let next = chronological.find(p => (p.hour > currentHour) || (p.hour === currentHour && p.minute > currentMinute));
      if (!next) next = chronological[0];
      setNextPrayerName(next.name);
      const targetTime = new Date(now.getFullYear(), now.getMonth(), now.getDate(), next.hour, next.minute);
      let diffMs = targetTime.getTime() - now.getTime();
      if (diffMs < 0) diffMs += 24 * 60 * 60 * 1000;
      const h = Math.floor(diffMs / (1000 * 60 * 60));
      const m = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
      setCountdown(`${h.toString().padStart(2, '0')}H ${m.toString().padStart(2, '0')}M`);

      // Notification Trigger
      if (notificationsEnabled) {
        const currentPrayer = chronological.find(p => p.hour === currentHour && p.minute === currentMinute);
        if (currentPrayer && lastNotifiedPrayer !== currentPrayer.name) {
          setLastNotifiedPrayer(currentPrayer.name);
          const audio = new Audio(adhanSource === 'DEVICE' ? '/adhan.mp3' : 'https://www.islamcan.com/audio/adhan/azan1.mp3');
          if (notificationMode === 'tone') {
            audio.play().catch(e => console.log("Audio play blocked", e));
          }
          alert(`AMANAH ALERT: It is time for ${currentPrayer.name} Salah. (MWL Method)`);
        }
      }
    }, 1000);
    return () => clearInterval(timer);
  }, [currentSchedule, notificationsEnabled, notificationMode, adhanSource, lastNotifiedPrayer]);

  useEffect(() => {
    localStorage.setItem('ashadu_qada_log', JSON.stringify(qadaLog));
    localStorage.setItem('ashadu_daily_prayers', JSON.stringify(prayers));
    localStorage.setItem('ashadu_user_dob', dob);
    localStorage.setItem('ashadu_comp_history', JSON.stringify(compHistory));
  }, [qadaLog, prayers, dob, compHistory]);

  const handleMarkDone = (index: number) => {
    const updated = [...prayers];
    updated[index].status = 'completed';
    setPrayers(updated);
    if (updated.filter(p => p.status === 'completed').length === currentSchedule.length && onComplete) {
      onComplete(50);
    }
  };

  const handleMarkMissed = (index: number) => {
    const updated = [...prayers];
    updated[index].status = 'missed';
    setPrayers(updated);
    const rawName = updated[index].name;
    const name = rawName.charAt(0) + rawName.slice(1).toLowerCase();
    setQadaLog(prev => ({ ...prev, [name]: ((prev as any)[name] || 0) + 1 }));
  };

  const handleReset = (index: number) => {
    const updated = [...prayers];
    const oldStatus = updated[index].status;
    const rawName = updated[index].name;
    const name = rawName.charAt(0) + rawName.slice(1).toLowerCase();
    if (oldStatus === 'missed') {
      setQadaLog(prev => ({ ...prev, [name]: Math.max(0, ((prev as any)[name] || 0) - 1) }));
    }
    updated[index].status = 'pending';
    setPrayers(updated);
  };

  const clearQadaSession = () => {
    setShowCompensatory(true);
  };

  const handleCompAction = (status: 'done' | 'missed') => {
    setCompHistory(prev => ({
      ...prev,
      [compDate]: {
        ...(prev[compDate] || {}),
        [compSalah]: status
      }
    }));
    
    // Update manual qada log if missed
    if (status === 'missed') {
      setQadaLog(prev => ({ ...prev, [compSalah]: (prev[compSalah] || 0) + 1 }));
    } else if (status === 'done' && compHistory[compDate]?.[compSalah] === 'missed') {
      // If it was missed before and now marked done, reduce the log
      setQadaLog(prev => ({ ...prev, [compSalah]: Math.max(0, (prev[compSalah] || 0) - 1) }));
    }
  };

  const nextPrayerTime = useMemo(() => {
    return currentSchedule.find(p => p.name === nextPrayerName)?.time || '--:-- --';
  }, [nextPrayerName, currentSchedule]);

  return (
    <div className="h-full bg-[#021F1F] flex flex-col animate-in fade-in duration-700 overflow-hidden font-inter">
      <div className="p-8 pb-4 text-center shrink-0">
        <h2 className="text-white text-2xl font-black tracking-[0.2em] uppercase leading-none">SALAH GUIDE</h2>
        <p className="text-[#4ADE80] text-[10px] font-black uppercase tracking-[0.4em] mt-3 underline decoration-[#C5A059] decoration-2 underline-offset-4">PERFORMANCE & QADA LOG (MWL METHOD)</p>
      </div>

      <div className="flex-1 overflow-y-auto px-6 space-y-8 pb-40 custom-scrollbar">
        
        {/* 1. DYNAMIC NEXT SALAH DISPLAY */}
        <div className="bg-[#053131] p-8 rounded-[2.5rem] border border-[#C5A059] flex flex-col items-center shadow-2xl relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:scale-110 transition-transform">
            {/* Zap removed */}
          </div>
          <span className="text-[#4ADE80] text-[10px] font-black tracking-[0.3em] uppercase mb-4">NEXT SALAH</span>
          <span className="text-[#C5A059] text-2xl font-black font-mono tracking-tighter mb-1">{nextPrayerTime}</span>
          <div className="flex items-center gap-4 mb-4">
            <h1 className="text-white text-4xl font-black tracking-tighter uppercase">{nextPrayerName}</h1>
            <div className="flex items-center gap-2 text-cyan-400 font-black text-[11px] bg-cyan-400/10 px-3 py-1.5 rounded-xl border border-cyan-400/20 shadow-sm">
              <span className="tracking-widest">-{countdown}</span>
            </div>
          </div>
          <div className="h-1.5 w-full bg-[#0A4242] mt-4 rounded-full relative overflow-hidden shadow-inner">
            <div className="absolute inset-y-0 left-0 bg-[#C5A059] w-2/3 shadow-[0_0_15px_#C5A059] animate-pulse" />
          </div>
        </div>

        {/* SPIRITUAL LEDGER SUMMARY */}
        <div className="bg-[#053131] rounded-[2.5rem] p-6 border border-[#C5A059]/30 shadow-2xl space-y-6">
          <div className="flex justify-between items-center">
             <h3 className="text-white text-[10px] font-black uppercase tracking-[0.3em]">Spiritual Ledger</h3>
             <div className="flex gap-2">
                <button 
                  onClick={() => setActiveQadaTab('manual')}
                  className={`px-3 py-1.5 rounded-lg text-[8px] font-black uppercase tracking-widest transition-all ${activeQadaTab === 'manual' ? 'bg-[#C5A059] text-[#021F1F]' : 'bg-[#0A4242] text-stone-400'}`}
                >
                  Manual
                </button>
                <button 
                  onClick={() => setActiveQadaTab('dob')}
                  className={`px-3 py-1.5 rounded-lg text-[8px] font-black uppercase tracking-widest transition-all ${activeQadaTab === 'dob' ? 'bg-[#C5A059] text-[#021F1F]' : 'bg-[#0A4242] text-stone-400'}`}
                >
                  D.O.B
                </button>
             </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div className="bg-black/20 p-4 rounded-2xl border border-white/5 flex flex-col items-center">
              <span className="text-[8px] font-black text-[#4ADE80] uppercase tracking-widest mb-1">SALAH DONE</span>
              <span className="text-xl font-black text-white font-mono">{totalDone}</span>
            </div>
            <div className="bg-black/20 p-4 rounded-2xl border border-white/5 flex flex-col items-center">
              <span className="text-[8px] font-black text-red-400 uppercase tracking-widest mb-1">QADA</span>
              <span className="text-xl font-black text-white font-mono">{totalMissed}</span>
            </div>
            <div className="bg-black/20 p-4 rounded-2xl border border-white/5 flex flex-col items-center">
              <span className="text-[8px] font-black text-[#C5A059] uppercase tracking-widest mb-1">OUTSTANDING</span>
              <span className="text-xl font-black text-white font-mono">{outstanding.toLocaleString()}</span>
            </div>
          </div>

          {activeQadaTab === 'dob' && (
            <div className="space-y-4 animate-in fade-in duration-300">
              <div className="space-y-2">
                <label className="text-[8px] font-black uppercase text-emerald-500 tracking-[0.2em] ml-1">ENTER D.O.B</label>
                <input 
                  type="date" 
                  value={dob}
                  onChange={(e) => setDob(e.target.value)}
                  className="w-full bg-black/40 border border-[#0A4242] rounded-xl p-3 text-white text-xs font-bold outline-none focus:border-[#C5A059] transition-all"
                />
              </div>
            </div>
          )}

          <button onClick={clearQadaSession} className="w-full bg-[#C5A059] hover:bg-[#FFD700] text-[#021F1F] py-4 rounded-2xl font-black text-[10px] uppercase tracking-[0.2em] transition-all active:scale-95 shadow-lg flex items-center justify-center gap-2 border-b-2 border-[#8c713b]">
            START COMPENSATORY SESSION
          </button>
        </div>

        {/* 2. ADHAN NOTIFICATION COMMAND CENTER */}
        <div className="bg-[#053131]/80 backdrop-blur-xl rounded-[2.5rem] p-8 border border-[#0A4242] shadow-2xl space-y-8">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-4">
              <div className={`p-4 rounded-2xl transition-all ${notificationsEnabled ? 'bg-[#4ADE80]/10 text-[#4ADE80]' : 'bg-red-500/10 text-red-500'}`}>
                {notificationsEnabled ? 'ON' : 'OFF'}
              </div>
              <div>
                <h4 className="text-white text-sm font-black uppercase tracking-tight">Adhan Alerts</h4>
                <p className="text-[#C5A059] text-[9px] font-bold uppercase tracking-widest mt-1">Amanah Protocol v4.0</p>
              </div>
            </div>
            <button 
              onClick={() => setNotificationsEnabled(!notificationsEnabled)}
              className={`w-16 h-8 rounded-full transition-all relative p-1.5 ${notificationsEnabled ? 'bg-[#4ADE80]' : 'bg-[#0A4242]'}`}
            >
              <div className={`w-5 h-5 rounded-full transition-all shadow-xl flex items-center justify-center
                ${notificationsEnabled ? 'translate-x-8 bg-[#C5A059]' : 'translate-x-0 bg-white'}`}>
                <div className={`w-1 h-1 rounded-full ${notificationsEnabled ? 'bg-[#021F1F]' : 'bg-stone-300'}`} />
              </div>
            </button>
          </div>

          {notificationsEnabled && (
            <div className="space-y-8 animate-in slide-in-from-top-4 duration-500">
               {/* SILENT VS TONE TOGGLE */}
               <div className="flex items-center justify-between p-4 bg-black/20 rounded-3xl border border-white/5">
                  <div className="flex items-center gap-3">
                     <span className="text-[10px] font-black uppercase text-white tracking-widest">Alert Mode</span>
                  </div>
                  <div className="flex p-1 bg-emerald-950 rounded-2xl border border-white/5 overflow-hidden">
                     <button 
                        onClick={() => setNotificationMode('silent')}
                        className={`px-4 py-2 rounded-xl text-[9px] font-black uppercase transition-all ${notificationMode === 'silent' ? 'bg-stone-700 text-white shadow-lg' : 'text-stone-600'}`}
                     >
                        Silent
                     </button>
                     <button 
                        onClick={() => setNotificationMode('tone')}
                        className={`px-4 py-2 rounded-xl text-[9px] font-black uppercase transition-all ${notificationMode === 'tone' ? 'bg-[#C5A059] text-[#021F1F] shadow-lg' : 'text-[#4D6B6B]'}`}
                     >
                        Tone
                     </button>
                  </div>
               </div>

               {/* TONE CONFIGURATION PANEL */}
               {notificationMode === 'tone' && (
                 <div className="space-y-6 pt-2 animate-in fade-in duration-500">
                    <div className="space-y-3">
                       <label className="text-[9px] font-black uppercase text-emerald-500 tracking-[0.3em] ml-2 flex items-center gap-2">
                          Spiritual Audio Source
                       </label>
                       <div className="grid grid-cols-3 gap-2">
                          <SourceBtn active={adhanSource === 'MAKKAH'} onClick={() => setAdhanSource('MAKKAH')} label="Makkah" />
                          <SourceBtn active={adhanSource === 'MADINA'} onClick={() => setAdhanSource('MADINA')} label="Madina" />
                          <SourceBtn active={adhanSource === 'DEVICE'} onClick={() => setAdhanSource('DEVICE')} label="Device" />
                       </div>
                    </div>

                    <div className="bg-black/30 p-6 rounded-[2rem] border border-white/5">
                       <div className="flex justify-between items-center mb-4">
                          <span className="text-[9px] font-black uppercase text-[#C5A059] tracking-widest">Select Notification Sound</span>
                       </div>
                       
                       <div className="space-y-2">
                          {adhanSource === 'DEVICE' ? (
                             <div className="grid grid-cols-1 gap-2">
                                {deviceTones.map(tone => (
                                   <button 
                                      key={tone} 
                                      onClick={() => setSelectedDeviceTone(tone)}
                                      className={`w-full p-4 rounded-2xl flex justify-between items-center transition-all border ${selectedDeviceTone === tone ? 'bg-[#C5A059]/10 border-[#C5A059]/40 text-white' : 'bg-black/20 border-white/5 text-stone-500 hover:text-white'}`}
                                   >
                                      <span className="text-xs font-bold">{tone}</span>
                                      {selectedDeviceTone === tone && <span className="text-[#C5A059] font-black">✓</span>}
                                   </button>
                                ))}
                             </div>
                          ) : (
                             <div className="p-6 bg-emerald-950/50 rounded-[2rem] border border-dashed border-[#C5A059]/30 text-center group">
                                <p className="text-[10px] text-[#C5A059] font-black uppercase tracking-widest leading-relaxed">
                                   Streaming {adhanSource} Al-Sharif Adhan
                                </p>
                             </div>
                          )}
                       </div>
                    </div>
                 </div>
               )}
            </div>
          )}
        </div>

        {/* 3. DAILY INTERACTIVE LIST */}
        <div className="space-y-4">
          <h3 className="text-[#4ADE80] text-[11px] font-black uppercase tracking-[0.3em] ml-2 flex items-center gap-2">
            TODAY'S AMANAH
          </h3>
          <div className="space-y-3">
            {prayers.map((salah, index) => (
              <div 
                key={salah.name} 
                className={`bg-[#053131] p-5 rounded-2xl flex justify-between items-center border transition-all group shadow-lg
                  ${salah.name === 'FRIDAY JUMMUAH' ? 'border-[#C5A059] bg-[#0A4242]/40 ring-2 ring-[#C5A059]/10' : ''}
                  ${salah.status === 'completed' ? 'border-[#4ADE80]/30 opacity-60' : 'border-[#0A4242] hover:border-[#4ADE80]/30'}`}
              >
                <div className="flex items-center gap-4">
                  <div className="flex flex-col">
                    <span className={`text-sm font-black tracking-tight ${salah.status === 'completed' ? 'text-[#4ADE80]' : 'text-white'}`}>{salah.name}</span>
                    <span className="text-[#4ADE80] text-[10px] font-black opacity-40">{salah.time}</span>
                  </div>
                </div>
                <div className="flex gap-2">
                  {salah.status === 'completed' ? (
                    <div className="flex items-center gap-2 bg-[#0A4242]/40 px-4 py-2 rounded-xl border border-[#4ADE80]/40">
                      <span className="text-[#4ADE80] text-[9px] font-black uppercase">DONE</span>
                    </div>
                  ) : salah.status === 'missed' ? (
                    <div className="flex items-center gap-2 bg-[#300808] px-4 py-2 rounded-xl border border-[#F87171]/40">
                      <span className="text-[#F87171] text-[9px] font-black uppercase">MISSED</span>
                    </div>
                  ) : (
                    <>
                      <button onClick={() => handleMarkDone(index)} className="flex items-center gap-2 bg-[#0A4242] px-3 py-2 rounded-xl border border-[#4ADE80] text-[#4ADE80] hover:bg-[#4ADE80] hover:text-[#021F1F] transition-all active:scale-95 shadow-md">
                        <span className="text-[9px] font-black uppercase">DONE</span>
                      </button>
                      <button onClick={() => handleMarkMissed(index)} className="flex items-center gap-2 bg-[#300808] px-3 py-2 rounded-xl border border-[#F87171] text-[#F87171] hover:bg-[#F87171] hover:text-white transition-all active:scale-95 shadow-md">
                        <span className="text-[9px] font-black uppercase">MISS</span>
                      </button>
                    </>
                  )}
                  <button onClick={() => handleReset(index)} className={`flex items-center gap-2 px-3 py-2 rounded-xl border transition-all active:scale-95 shadow-md ${salah.status === 'pending' ? 'bg-stone-800 border-stone-700 text-stone-500 hover:text-white' : 'bg-stone-800 border-stone-600 text-stone-300'}`}>
                    <span className="text-[9px] font-black uppercase">RESET</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 4. THE QADA LOG REMOVED FROM HERE AND MOVED UP */}
      </div>

      <div className="p-8 text-center bg-gradient-to-t from-black/60 to-transparent shrink-0">
        <div className="flex items-center justify-center gap-3 opacity-30">
          <p className="text-[10px] font-black text-[#4ADE80] uppercase tracking-[0.6em]">ASHADU SPIRITUAL GUARD v2.5.2-GOLD</p>
        </div>
      </div>

      {/* COMPENSATORY SESSION MODAL */}
      {showCompensatory && (
        <div className="fixed inset-0 z-[1000] bg-black/90 backdrop-blur-xl flex items-center justify-center p-6 animate-in fade-in duration-300">
          <div className="w-full max-w-md bg-[#053131] border border-[#C5A059]/50 rounded-[3rem] p-8 shadow-[0_0_50px_rgba(197,160,89,0.2)] relative overflow-hidden">
            <div className="absolute top-0 right-0 p-6">
              <button onClick={() => setShowCompensatory(false)} className="text-stone-500 hover:text-white transition-colors font-black">X</button>
            </div>

            <div className="text-center mb-8">
              <h3 className="text-white text-xl font-black uppercase tracking-widest">Compensatory Session</h3>
              <p className="text-[#C5A059] text-[9px] font-bold uppercase tracking-[0.3em] mt-2">Amanah Reconciliation Protocol</p>
            </div>

            <div className="space-y-6">
              {/* DATE TAB */}
              <div className="space-y-3">
                <label className="text-[9px] font-black uppercase text-emerald-500 tracking-[0.3em] ml-2 flex items-center gap-2">
                  SESSION DATE
                </label>
                <input 
                  type="date" 
                  value={compDate}
                  onChange={(e) => setCompDate(e.target.value)}
                  className="w-full bg-black/40 border border-[#0A4242] rounded-2xl p-4 text-white font-bold outline-none focus:border-[#C5A059] transition-all"
                />
              </div>

              {/* SALAH TAB */}
              <div className="space-y-3">
                <label className="text-[9px] font-black uppercase text-emerald-500 tracking-[0.3em] ml-2 flex items-center gap-2">
                  SELECT SALAH
                </label>
                <div className="relative">
                  <select 
                    value={compSalah}
                    onChange={(e) => setCompSalah(e.target.value)}
                    className="w-full bg-black/40 border border-[#0A4242] rounded-2xl p-4 text-white font-bold outline-none focus:border-[#C5A059] appearance-none transition-all"
                  >
                    {['Fajr', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'].map(s => (
                      <option key={s} value={s} className="bg-[#053131]">{s}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* STATUS DISPLAY */}
              {compHistory[compDate]?.[compSalah] && (
                <div className={`p-4 rounded-2xl text-center border animate-in zoom-in duration-300 ${compHistory[compDate][compSalah] === 'done' ? 'bg-[#4ADE80]/10 border-[#4ADE80]/30 text-[#4ADE80]' : 'bg-red-500/10 border-red-500/30 text-red-500'}`}>
                  <span className="text-[10px] font-black uppercase tracking-widest">
                    Status: {compHistory[compDate][compSalah].toUpperCase()}
                  </span>
                </div>
              )}

              {/* ACTION BUTTONS */}
              <div className="grid grid-cols-2 gap-4 pt-4">
                <button 
                  onClick={() => handleCompAction('done')}
                  className={`py-5 rounded-2xl font-black uppercase tracking-widest text-[10px] transition-all flex items-center justify-center gap-2 shadow-xl
                    ${compHistory[compDate]?.[compSalah] === 'done' ? 'bg-[#4ADE80] text-[#021F1F]' : 'bg-[#0A4242] text-[#4ADE80] border border-[#4ADE80]/30 hover:bg-[#4ADE80]/20'}`}
                >
                  DONE
                </button>
                <button 
                  onClick={() => handleCompAction('missed')}
                  className={`py-5 rounded-2xl font-black uppercase tracking-widest text-[10px] transition-all flex items-center justify-center gap-2 shadow-xl
                    ${compHistory[compDate]?.[compSalah] === 'missed' ? 'bg-red-500 text-white' : 'bg-[#300808] text-red-500 border border-red-500/30 hover:bg-red-500/20'}`}
                >
                  MISSED
                </button>
              </div>
            </div>

            <div className="mt-10 text-center">
              <p className="text-[8px] text-stone-500 uppercase font-bold tracking-[0.4em]">Spiritual Ledger Update Active</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const SourceBtn = ({ active, onClick, label }: any) => (
   <button 
      onClick={onClick}
      className={`py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all border ${active ? 'bg-[#C5A059] text-[#021F1F] border-[#C5A059] shadow-lg' : 'bg-emerald-950 border-white/5 text-[#4D6B6B] hover:text-white'}`}
   >
      {label}
   </button>
);

export default SalahGuideView;