import React from 'react';
import { Target, Users, Heart, Zap, Coins, ShieldCheck, User, Settings, Radio } from 'lucide-react';
import { DonationEvent } from '../types';

interface FundraisingDashboardProps {
  currentGroupCount: number;
  groupTarget: number;
  personalRaised: number;
  totalGroupRaised: number;
  joinedUsers: number;
  recentDonations: DonationEvent[];
  isAdmin?: boolean;
  onOpenSettings: () => void;
}

const FundraisingDashboard: React.FC<FundraisingDashboardProps> = ({
  currentGroupCount, groupTarget, personalRaised, totalGroupRaised, joinedUsers, recentDonations, isAdmin, onOpenSettings
}) => {
  const progress = Math.min(100, (currentGroupCount / groupTarget) * 100);

  return (
    <div className="flex flex-col gap-8 animate-in fade-in slide-in-from-bottom-4 duration-700 font-inter">
      <div className="bg-black/20 rounded-[3rem] p-10 shadow-2xl relative overflow-hidden group border border-[#C5A059]/20 backdrop-blur-xl">
        <Target size={240} className="absolute -top-10 -right-10 text-white opacity-[0.02] group-hover:scale-110 transition-transform" />
        <div className="relative z-10">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-[11px] font-black uppercase tracking-[0.4em] text-emerald-500">Mission Status</h3>
            <span className="text-3xl font-black font-mono text-white">{progress.toFixed(1)}%</span>
          </div>
          <div className="w-full h-4 bg-black/40 rounded-full border border-white/5 overflow-hidden">
            <div className="h-full bg-[#C5A059] shadow-[0_0_15px_rgba(197,160,89,0.4)] transition-all duration-1000" style={{ width: `${progress}%` }} />
          </div>
          <div className="flex justify-between mt-8">
            <div className="text-left"><p className="text-[9px] font-black text-emerald-800 uppercase tracking-widest mb-1">Gap</p><p className="text-lg font-black font-mono text-white">{(groupTarget - currentGroupCount).toLocaleString()}</p></div>
            <div className="text-right"><p className="text-[9px] font-black text-emerald-800 uppercase tracking-widest mb-1">Quota</p><p className="text-lg font-black font-mono text-white">{groupTarget.toLocaleString()}</p></div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <ImpactBox value={`£${personalRaised.toFixed(2)}`} label="My Sadaqah" icon={<User size={16}/>} active />
        <ImpactBox value={`£${totalGroupRaised.toFixed(0)}`} label="Circle Total" icon={<Heart size={16}/>} highlight />
        <ImpactBox value={joinedUsers.toString()} label="Souls" icon={<Users size={16}/>} />
      </div>

      <div className="bg-emerald-900/10 border border-white/5 rounded-[2.5rem] p-8 space-y-6">
        <div className="flex justify-between items-center px-2">
          <h3 className="text-[10px] font-black uppercase text-emerald-600 tracking-[0.3em]">Alms Live Feed</h3>
          <Radio size={14} className="text-[#C5A059] animate-pulse" />
        </div>
        <div className="space-y-4 max-h-64 overflow-y-auto pr-2 no-scrollbar">
          {recentDonations.length === 0 ? (
             <div className="py-10 text-center opacity-20"><p className="text-[10px] font-black uppercase tracking-widest">Listening for contributions...</p></div>
          ) : recentDonations.map(d => (
            <div key={d.id} className="bg-black/20 p-5 rounded-2xl border border-white/5 flex justify-between items-center group transition-all">
               <div className="flex items-center gap-4"><div className="w-10 h-10 rounded-xl bg-emerald-950 flex items-center justify-center text-[#C5A059]"><Coins size={18}/></div><div><p className="text-xs font-black text-white">{d.name}</p><p className="text-[8px] text-emerald-700 uppercase tracking-widest font-bold">{d.optionType}</p></div></div>
               <p className="text-sm font-black text-[#C5A059] font-mono">+£{d.amount.toFixed(2)}</p>
            </div>
          ))}
        </div>
      </div>

      {isAdmin && (
        <button onClick={onOpenSettings} className="w-full bg-emerald-900 border border-[#C5A059]/30 text-[#C5A059] py-7 rounded-2xl shadow-xl flex items-center justify-center gap-3 uppercase tracking-widest text-[11px] font-black active:scale-95">
          <Settings size={18} /> Mission Configuration
        </button>
      )}

      <div className="flex items-center justify-center gap-3 opacity-30 text-emerald-600"><ShieldCheck size={14} /><span className="text-[8px] font-black uppercase tracking-[0.4em]">Prophetic Ethics Shield Active</span></div>
    </div>
  );
};

const ImpactBox = ({ value, label, icon, highlight, active }: any) => (
  <div className={`p-6 rounded-3xl border transition-all flex flex-col items-center justify-center text-center ${highlight ? 'bg-[#C5A059] border-[#C5A059] text-[#022c22] shadow-xl shadow-amber-500/10' : active ? 'bg-emerald-900 border-[#C5A059]/30 text-white' : 'bg-black/20 border-white/5 text-emerald-700'}`}>
    <div className="mb-3">{icon}</div>
    <p className={`text-[8px] font-black uppercase tracking-widest mb-1 ${highlight ? 'opacity-60' : 'opacity-40'}`}>{label}</p>
    <p className="text-sm font-black font-mono leading-none">{value}</p>
  </div>
);

export default FundraisingDashboard;