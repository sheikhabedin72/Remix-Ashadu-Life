
export interface PrayerTimes {
  Fajr: string;
  Sunrise: string;
  Dhuhr: string;
  Asr: string;
  Maghrib: string;
  Isha: string;
  Imsak: string;
  Midnight: string;
}

export const fetchPrayerTimes = async (lat: number, lon: number): Promise<PrayerTimes> => {
  try {
    const timestamp = Math.floor(Date.now() / 1000);
    // Method 3 is Muslim World League (MWL)
    const response = await fetch(
      `https://api.aladhan.com/v1/timings/${timestamp}?latitude=${lat}&longitude=${lon}&method=3`
    );
    
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    
    const data = await response.json();
    if (data.code === 200 && data.data && data.data.timings) {
      return data.data.timings;
    }
    throw new Error("Invalid API response format");
  } catch (error) {
    console.error("Failed to fetch prayer times:", error);
    // Fallback to mock times if API fails
    return {
      Fajr: "05:12",
      Sunrise: "06:45",
      Dhuhr: "12:34",
      Asr: "15:45",
      Maghrib: "18:10",
      Isha: "19:30",
      Imsak: "05:02",
      Midnight: "00:00"
    };
  }
};

export const parseTimeString = (timeStr: string): { hour: number; minute: number } => {
  const [hour, minute] = timeStr.split(':').map(Number);
  return { hour, minute };
};

export const formatTime12h = (hour: number, minute: number): string => {
  const period = hour >= 12 ? 'PM' : 'AM';
  const h = hour % 12 || 12;
  return `${h.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')} ${period}`;
};
