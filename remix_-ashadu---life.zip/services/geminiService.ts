import { GoogleGenAI, Type } from "@google/genai";

export const getSpiritualInsight = async (phrase: string) => {
  try {
    // Create a new GoogleGenAI instance right before making an API call to ensure it always uses the most up-to-date API key.
    const apiKey = process.env.GEMINI_API_KEY || process.env.API_KEY;
    if (!apiKey) {
      console.warn("Gemini API key is missing. Spiritual insights will be unavailable.");
      return null;
    }
    const ai = new GoogleGenAI({ apiKey });
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Provide a meditative and deep spiritual insight for the zikr phrase: "${phrase}". 
      Include: 1. A short title for this insight. 2. Its deeper metaphysical meaning. 3. Practical spiritual benefits.
      Keep it poetic, serene, and grounded in Islamic tradition. Respond in JSON.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            meaning: { type: Type.STRING },
            benefit: { type: Type.STRING },
            reflection: { type: Type.STRING }
          },
          required: ["title", "meaning", "benefit"]
        }
      }
    });

    // Access the .text property directly (not as a function call)
    const jsonStr = response.text?.trim();
    if (!jsonStr) return null;
    
    return JSON.parse(jsonStr);
  } catch (error) {
    console.error("Gemini Error:", error);
    return null;
  }
};