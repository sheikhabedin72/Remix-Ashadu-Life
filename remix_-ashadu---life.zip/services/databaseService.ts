import { UserStats, UserProfile, DBMetadata, ZakatRecord } from '../types';

/**
 * ASHADU AMANAH DATABASE ENGINE v3.9 (Celestial Emerald Edition)
 * Mimics SQL Schema:
 * 1. PROFILES (profiles table)
 * 2. ZIKR_LEDGER (zikr_ledger table with is_synced column)
 * 3. ZAKAT_RECORDS (zakat_records table for private financial data)
 */

const KEYS = {
  LOCAL_SQLITE_BUFFER: 'ashadu_local_sqlite_v3',
  CLOUD_POSTGRES_DUMP: 'ashadu_cloud_postgres_v3',
  ZIKR_LEDGER: 'ashadu_zikr_ledger_v3',
  ZAKAT_LEDGER: 'ashadu_zakat_ledger_v3',
  METADATA: 'ashadu_db_metadata',
};

export interface ZikrLedgerEntry {
  id: string;
  zikr_type: string;
  count_amount: number;
  session_date: string;
  is_synced: boolean;
}

class DatabaseService {
  private isAuth: boolean = false;
  private currentUserId: string | null = null;

  constructor() {
    this.initialize();
  }

  private initialize() {
    const profile = localStorage.getItem('ashadu_user_profile');
    if (profile) {
      const p = JSON.parse(profile);
      this.isAuth = p.isRegistered;
      this.currentUserId = p.email;
    }
  }

  public refreshAuth() {
    this.initialize();
  }

  public async getLocalStats(): Promise<UserStats | null> {
    const data = localStorage.getItem(KEYS.LOCAL_SQLITE_BUFFER);
    return data ? JSON.parse(data) : null;
  }

  public async addZikrToLedger(zikrType: string, count: number): Promise<void> {
    const ledgerData = localStorage.getItem(KEYS.ZIKR_LEDGER);
    const ledger: ZikrLedgerEntry[] = ledgerData ? JSON.parse(ledgerData) : [];
    
    const newEntry: ZikrLedgerEntry = {
      id: `led-${Date.now()}`,
      zikr_type: zikrType,
      count_amount: count,
      session_date: new Date().toISOString(),
      is_synced: false
    };

    ledger.push(newEntry);
    localStorage.setItem(KEYS.ZIKR_LEDGER, JSON.stringify(ledger));
  }

  public async upsertZakatRecord(record: ZakatRecord): Promise<void> {
    const ledgerData = localStorage.getItem(KEYS.ZAKAT_LEDGER);
    const ledger: ZakatRecord[] = ledgerData ? JSON.parse(ledgerData) : [];
    
    const index = ledger.findIndex(r => r.id === record.id);
    if (index > -1) {
      ledger[index] = record;
    } else {
      ledger.push(record);
    }
    
    localStorage.setItem(KEYS.ZAKAT_LEDGER, JSON.stringify(ledger));
    console.log("DB_ENGINE: Zakat UPSERT executed. Sync pending...");
  }

  public async getZakatRecords(): Promise<ZakatRecord[]> {
    const data = localStorage.getItem(KEYS.ZAKAT_LEDGER);
    return data ? JSON.parse(data) : [];
  }

  public async localAutosave(stats: UserStats): Promise<void> {
    localStorage.setItem(KEYS.LOCAL_SQLITE_BUFFER, JSON.stringify({
      ...stats,
      lastUpdated: Date.now()
    }));
  }

  public async getUnsyncedRows(): Promise<ZikrLedgerEntry[]> {
    const ledgerData = localStorage.getItem(KEYS.ZIKR_LEDGER);
    const ledger: ZikrLedgerEntry[] = ledgerData ? JSON.parse(ledgerData) : [];
    return ledger.filter(row => !row.is_synced);
  }

  public async markRowsAsSynced(ids: string[]): Promise<void> {
    const ledgerData = localStorage.getItem(KEYS.ZIKR_LEDGER);
    const ledger: ZikrLedgerEntry[] = ledgerData ? JSON.parse(ledgerData) : [];
    const updatedLedger = ledger.map(row => 
      ids.includes(row.id) ? { ...row, is_synced: true } : row
    );
    localStorage.setItem(KEYS.ZIKR_LEDGER, JSON.stringify(updatedLedger));
  }

  public async migrateGuestToPermanent(guestStats: UserStats, profile: UserProfile): Promise<UserStats> {
    // Clear all local storage keys to ensure a fresh start
    const keysToClear = [
      KEYS.LOCAL_SQLITE_BUFFER,
      KEYS.ZIKR_LEDGER,
      KEYS.ZAKAT_LEDGER,
      'ashadu_qada_log',
      'ashadu_daily_prayers',
      'ashadu_comp_history',
      'ashadu_custom_phrases',
      'ashadu_legacy_projects',
      'ashadu_marketplace_products',
      'demo_friends',
      'mock_ledger'
    ];
    keysToClear.forEach(k => localStorage.removeItem(k));

    const permanentStats: UserStats = {
      totalCount: 0,
      dailyLogs: [],
      streak: 0,
      shield: null,
      missedFastsCount: 0, 
      missedPrayersCount: 0,
      kaffarahOwed: 0,
      impactPoints: 50, // Welcome blessing
      sabrPoints: 0,
      recitationSuccessCount: 0,
      educationCredits: 0,
      completedLessonIds: [],
      totalProjectDonations: 0,
      gardenPlants: [],
      fastingLog: {},
      silenceGroupAlerts: false,
      zikrHistory: [],
      syncStatus: {
        lastSyncedAt: new Date().toLocaleTimeString(),
        pendingCounts: 0,
        isOnline: true,
        dbTier: 'HYBRID_SYNCED'
      }
    };

    localStorage.setItem(KEYS.CLOUD_POSTGRES_DUMP, JSON.stringify(permanentStats));
    localStorage.setItem(KEYS.LOCAL_SQLITE_BUFFER, JSON.stringify(permanentStats));
    await this.addZikrToLedger('Account Created', 0);
    return permanentStats;
  }

  public async performSyncHandshake(localStats: UserStats): Promise<UserStats> {
    const cloudData = localStorage.getItem(KEYS.CLOUD_POSTGRES_DUMP);
    const cloudStats: UserStats | null = cloudData ? JSON.parse(cloudData) : null;

    const syncedStats: UserStats = {
      ...localStats,
      totalCount: Math.max(localStats.totalCount, cloudStats?.totalCount || 0),
      syncStatus: {
        lastSyncedAt: new Date().toLocaleTimeString(),
        pendingCounts: 0,
        isOnline: true,
        dbTier: 'HYBRID_SYNCED'
      }
    };

    localStorage.setItem(KEYS.CLOUD_POSTGRES_DUMP, JSON.stringify(syncedStats));
    return syncedStats;
  }
}

export const db = new DatabaseService();