import { createBrowserClient } from '@supabase/ssr';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

const isSupabaseConfigured = !!supabaseUrl && !!supabaseAnonKey && !supabaseUrl.includes('placeholder');

if (!isSupabaseConfigured) {
  console.warn("Supabase environment variables are missing or invalid. Cloud sync will be disabled.");
}

export const supabase = createBrowserClient(
  supabaseUrl || 'https://placeholder.supabase.co',
  supabaseAnonKey || 'placeholder'
);

/**
 * Handles saving user data to the 'user_data' table in Supabase.
 * Uses auth.uid() for security.
 */
export async function saveUserData(data: any) {
  if (!isSupabaseConfigured) return { success: false, error: "Cloud sync disabled" };
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error("Authentication required to save data.");

    const { error } = await supabase
      .from('user_data')
      .upsert({ 
        user_id: user.id,
        email: user.email,
        ...data,
        updated_at: new Date().toISOString()
      }, { onConflict: 'user_id' });

    if (error) throw error;
    
    console.log("Data saved successfully to Supabase");
    return { success: true };
  } catch (error: any) {
    console.error("Supabase Save Error:", error.message);
    return { success: false, error: error.message };
  }
}

export async function signUp(email: string, pin: string, metadata: any) {
  if (!isSupabaseConfigured) throw new Error("Cloud authentication is currently unavailable.");
  const { data, error } = await supabase.auth.signUp({
    email,
    password: pin, // Using pin as password for simplicity in this context
    options: {
      data: metadata
    }
  });
  if (error) throw error;
  return data;
}

export async function signIn(email: string, pin: string) {
  if (!isSupabaseConfigured) throw new Error("Cloud authentication is currently unavailable.");
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password: pin
  });
  if (error) throw error;
  return data;
}

export async function signOut() {
  try {
    const { error } = await supabase.auth.signOut();
    if (error) throw error;
  } catch (e) {
    console.warn("Supabase SignOut Error:", e);
  }
}

export async function getCurrentUser() {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    return user;
  } catch (e) {
    return null;
  }
}

/**
 * Inserts user data into the 'user_data' table.
 * Uses auth.uid() for security.
 */
export async function insertUserData(data: { full_name: string; email: string; bio: string; website_url: string }) {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) throw new Error("Authentication required.");

  const { error } = await supabase
    .from('user_data')
    .insert([{
      ...data,
      user_id: user.id
    }]);
  
  if (error) throw error;
  return { success: true };
}

/**
 * Fetches the latest user data entry for the logged-in user.
 */
export async function fetchLatestUserData() {
  if (!isSupabaseConfigured) return null;
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return null;

  const { data, error } = await supabase
    .from('user_data')
    .select('*')
    .eq('user_id', user.id)
    .order('updated_at', { ascending: false })
    .limit(1)
    .single();
  
  if (error && error.code !== 'PGRST116') { // PGRST116 is "no rows returned"
    throw error;
  }
  
  return data;
}

/**
 * Checks the connectivity to Supabase by fetching a single row.
 */
export async function checkSystemStatus(): Promise<'Operational' | 'Offline'> {
  if (!isSupabaseConfigured) return 'Offline';
  try {
    const { error } = await supabase
      .from('user_data')
      .select('id')
      .limit(1);
    
    if (error && error.code !== 'PGRST116') return 'Offline';
    return 'Operational';
  } catch {
    return 'Offline';
  }
}
