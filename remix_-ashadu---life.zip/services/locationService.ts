
export interface GeoResult {
  city: string;
  zipcode: string;
}

export const fetchCurrentLocation = (): Promise<GeolocationPosition> => {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error("Geolocation is not supported by your browser"));
    } else {
      navigator.geolocation.getCurrentPosition(resolve, reject);
    }
  });
};

export const reverseGeocode = async (lat: number, lon: number): Promise<GeoResult> => {
  try {
    const response = await fetch(
      `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lon}&zoom=18&addressdetails=1`,
      {
        headers: {
          'Accept-Language': 'en',
          'User-Agent': 'ASHADU-Spiritual-Ecosystem-App'
        },
        // Add a timeout or other options if needed
      }
    ).catch(err => {
      console.warn("Network error during geocoding:", err);
      return null;
    });
    
    if (!response || !response.ok) {
      return { city: "London", zipcode: "E1" }; // Fallback
    }
    
    const data = await response.json();
    
    if (!data || !data.address) {
      return { city: "Unknown", zipcode: "" };
    }
    
    const city = data.address.city || data.address.town || data.address.village || data.address.suburb || data.address.county || "Unknown";
    const zipcode = data.address.postcode || "";
    
    return { city, zipcode };
  } catch (error) {
    console.warn("Reverse geocoding failed, using fallback:", error);
    // Return a graceful fallback instead of throwing to prevent app crashes
    return { city: "London", zipcode: "E1" }; 
  }
};

/**
 * ASHADU Geo-Logic: Haversine Formula for pinpoint accuracy
 */
export const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
  const R = 6371; // Earth's radius in km
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  
  const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
            Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
            Math.sin(dLon/2) * Math.sin(dLon/2);
  
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c; // Distance in km
};
